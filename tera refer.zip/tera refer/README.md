# Terabox Refer Bot 🤖

Temp mail se automatic Terabox accounts banana via referral link.

## Setup

```bash
pip install -r requirements.txt
playwright install chromium
```

## Test Run (1 account)

```bash
python test_flow.py
```

## Flow

```
1. Temp Email Create  →  API se address + token milta hai
2. Terabox Share URL  →  Browser kholega (visible window)
3. Email fill + Send Code
4. Inbox Poll         →  Har 5 sec mein check karta hai
5. OTP extract        →  Regex se 4-6 digit code
6. Password set       →  Random strong password
7. Account Created ✅
```

## Debug Screenshots

Test run ke baad ye files milenge:
- `debug_step1_share.png`   - Share page
- `debug_step2_login.png`   - Login modal
- `debug_step3_signup.png`  - Sign up form
- `debug_step4_sendcode.png`- After send code
- `debug_step5_otp.png`     - OTP filled
- `debug_step6_password.png`- Password filled
- `debug_step7_final.png`   - Final result

## Logs

Results save hote hain `logs/results.jsonl` mein.
