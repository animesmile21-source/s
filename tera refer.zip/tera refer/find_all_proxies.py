"""
find_all_proxies.py - Test remaining proxies (31-89)
"""
import requests, sys
from concurrent.futures import ThreadPoolExecutor, as_completed
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

def load_proxies(filepath):
    proxies = []
    seen = set()
    with open(filepath, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line: continue
            parts = line.split(":")
            if len(parts) >= 4:
                key = f"{parts[0]}:{parts[2]}"
                if key not in seen:
                    seen.add(key)
                    proxies.append({"host": parts[0], "port": parts[1], "user": parts[2], "pwd": parts[3]})
    return proxies

def test_proxy(proxy):
    url = f"http://{proxy['user']}:{proxy['pwd']}@{proxy['host']}:{proxy['port']}"
    try:
        r = requests.get("https://httpbin.org/ip", proxies={"http": url, "https": url}, timeout=10)
        if r.status_code == 200:
            ip = r.json().get("origin", "?")
            ms = int(r.elapsed.total_seconds() * 1000)
            return {"ok": True, "proxy": proxy, "url": url, "ip": ip, "ms": ms}
    except: pass
    return {"ok": False, "proxy": proxy}

proxies = load_proxies("working_proxies.txt")
print(f"Testing all {len(proxies)} proxies...\n")

working = []
with ThreadPoolExecutor(max_workers=20) as ex:
    futures = {ex.submit(test_proxy, p): p for p in proxies}
    for i, fut in enumerate(as_completed(futures), 1):
        res = fut.result()
        p = res["proxy"]
        if res["ok"]:
            working.append(res)
            print(f"  OK  [{i:2d}] {p['host'][:35]} → {res['ip']} | {res['ms']}ms")
        else:
            print(f"  FAIL[{i:2d}] {p['host'][:35]}")

print(f"\n{'='*50}")
print(f"RESULT: {len(working)}/{len(proxies)} working")

if working:
    working.sort(key=lambda x: x["ms"])
    with open("good_proxies.txt", "w") as f:
        for r in working:
            p = r["proxy"]
            f.write(f"{p['host']}:{p['port']}:{p['user']}:{p['pwd']}  # {r['ip']} {r['ms']}ms\n")
    print(f"Saved {len(working)} good proxies → good_proxies.txt")
    print("\nTop 5 fastest:")
    for r in working[:5]:
        p = r["proxy"]
        print(f"  {p['host']} → {r['ip']} | {r['ms']}ms")
