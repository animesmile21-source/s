"""
test_flow.py - Full end-to-end test of Terabox Webmaster refer system
Mobile flow: Pixel 9 Android → Webmaster join → $1.2 per signup
Run: python -X utf8 test_flow.py
"""

import asyncio
import sys
import json
import time
import os
import random
from datetime import datetime

if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    os.environ["PYTHONIOENCODING"] = "utf-8"

class C:
    RESET  = "\033[0m"; GREEN = "\033[92m"; RED = "\033[91m"
    YELLOW = "\033[93m"; CYAN  = "\033[96m"; BLUE = "\033[94m"
    BOLD   = "\033[1m";  WHITE = "\033[97m"

def log(level: str, msg: str):
    ts = datetime.now().strftime("%H:%M:%S")
    colors = {"INFO": C.CYAN, "SUCCESS": C.GREEN, "ERROR": C.RED,
              "WARN": C.YELLOW, "STEP": C.BLUE + C.BOLD, "MAIL": C.WHITE}
    color = colors.get(level, C.RESET)
    print(f"{C.BOLD}[{ts}]{C.RESET} {color}[{level}]{C.RESET} {msg}")


def load_proxies(filepath="good_proxies.txt"):
    proxies = []
    if not os.path.exists(filepath):
        return proxies
    with open(filepath, encoding='utf-8') as f:
        for line in f:
            line = line.split("#")[0].strip()
            if not line: continue
            parts = line.split(":")
            if len(parts) >= 4:
                host, port, user, pwd = parts[0], parts[1], parts[2], parts[3]
                proxies.append({
                    "server": f"http://{host}:{port}",
                    "username": user,
                    "password": pwd,
                    "_display": f"{host}"
                })
    return proxies


async def run_test():
    print(f"""
{C.CYAN}{C.BOLD}
+======================================================+
|   TERABOX WEBMASTER BOT - MOBILE FLOW v2.0          |
|   Webmaster: dm.1024terabox.com/referral/81364624626373 |
|   Device: Android Pixel 9 | clienttype=5            |
+======================================================+
{C.RESET}""")

    from bot.tempmail import create_email, get_inbox
    from bot.terabox import register_terabox

    # Load proxy (set NO_PROXY=1 to disable)
    use_proxy = os.getenv("NO_PROXY", "") != "1"
    proxies = load_proxies("good_proxies.txt") if use_proxy else []
    if proxies:
        proxy = random.choice(proxies)
        log("INFO", f"Proxy: {proxy['_display']}")
    else:
        proxy = None
        log("WARN", "Running WITHOUT proxy (direct connection)")

    # STEP 1: Temp Email
    log("STEP", "━━━ STEP 1: Creating Temp Email ━━━")
    try:
        mail_data = create_email()
        email_addr = mail_data["address"]
        mail_token = mail_data["token"]
        log("SUCCESS", f"Email: {C.BOLD}{email_addr}{C.RESET}")
        log("MAIL", f"Token: {mail_token[:40]}...")
    except Exception as e:
        log("ERROR", f"TempMail fail: {e}")
        log("WARN", "TempMail API may have expired. Check API key!")
        return

    # OTP Callback
    async def otp_callback():
        log("STEP", "━━━ STEP 3: Polling Inbox for OTP ━━━")
        import re
        start = time.time()
        timeout = 120
        seen_ids = set()
        while time.time() - start < timeout:
            try:
                emails = get_inbox(mail_token)
                log("MAIL", f"Inbox: {len(emails)} email(s)")
                for em in emails:
                    eid = em.get("@id", "") or str(em.get("id", ""))
                    if eid in seen_ids: continue
                    seen_ids.add(eid)
                    subject = em.get("subject", "")
                    body = em.get("text", "") or em.get("html", "") or em.get("intro", "")
                    log("MAIL", f"Email: {subject}")
                    m = re.search(r'\b(\d{4,6})\b', subject + " " + body)
                    if m:
                        log("SUCCESS", f"OTP: {C.GREEN}{m.group(1)}{C.RESET}")
                        return m.group(1)
            except Exception as e:
                log("WARN", f"Inbox error: {e}")
            await asyncio.sleep(5)
        log("ERROR", "OTP timeout!")
        return None

    # STEP 2: Register
    log("STEP", "━━━ STEP 2: Mobile Webmaster Registration ━━━")
    log("INFO", f"Email: {email_addr}")

    result = await register_terabox(
        email=email_addr,
        otp_callback=otp_callback,
        headless=False,
        proxy=proxy
    )

    # Results
    print(f"\n{C.BOLD}{'='*55}{C.RESET}")
    log("STEP", "━━━ RESULTS ━━━")

    if result["success"]:
        log("SUCCESS", f"✅ WEBMASTER ACCOUNT CREATED!")
        log("SUCCESS", f"Email:    {result['email']}")
        log("SUCCESS", f"Password: {result['password']}")
        if result.get("plan_joined"):
            log("SUCCESS", "Webmaster New Users Plan: JOINED ✅")
    else:
        log("ERROR", f"Failed: {result.get('error', 'Unknown')}")

    result["timestamp"] = datetime.now().isoformat()
    result["proxy_used"] = proxy["_display"] if proxy else "none"

    os.makedirs("logs", exist_ok=True)
    with open("logs/results.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(result) + "\n")
    log("INFO", "Saved → logs/results.jsonl")


if __name__ == "__main__":
    os.makedirs("logs", exist_ok=True)
    os.makedirs("screenshots", exist_ok=True)
    if not os.path.exists("bot/__init__.py"):
        open("bot/__init__.py", "w").close()
    asyncio.run(run_test())
