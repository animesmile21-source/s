"""
test_proxy_and_webmaster.py
1. PureVPN proxies test karo (working_proxies.txt)
2. Working proxy se webmaster link inspect karo
3. Mobile flow ka dry run karo
"""
import requests, sys, re, json
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

WEBMASTER_REFERER_UK = "81364624626373"
WEBMASTER_LINK = f"https://dm.1024terabox.com/referral/{WEBMASTER_REFERER_UK}"

# Mobile Android headers (from your curl requests)
MOBILE_UA = "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36"
MOBILE_HEADERS = {
    "User-Agent": MOBILE_UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "sec-ch-ua": '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
    "sec-ch-ua-mobile": "?1",
    "sec-ch-ua-platform": '"Android"',
}

def load_proxies(filepath):
    proxies = []
    with open(filepath, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line: continue
            parts = line.split(":")
            if len(parts) >= 4:
                proxies.append({
                    "raw": line,
                    "host": parts[0], "port": parts[1],
                    "user": parts[2], "pwd": parts[3]
                })
    # Deduplicate
    seen = set()
    unique = []
    for p in proxies:
        key = f"{p['host']}:{p['port']}:{p['user']}"
        if key not in seen:
            seen.add(key)
            unique.append(p)
    return unique

def test_proxy(proxy):
    host, port, user, pwd = proxy["host"], proxy["port"], proxy["user"], proxy["pwd"]
    for proto in ["http", "socks5"]:
        url = f"{proto}://{user}:{pwd}@{host}:{port}"
        try:
            r = requests.get("https://httpbin.org/ip",
                proxies={"http": url, "https": url},
                timeout=10)
            if r.status_code == 200:
                ip = r.json().get("origin", "?")
                ms = int(r.elapsed.total_seconds() * 1000)
                return {"ok": True, "proxy": proxy, "proto": proto, "url": url, "ip": ip, "ms": ms}
        except: continue
    return {"ok": False, "proxy": proxy}

def inspect_webmaster_via_proxy(proxy_url):
    print(f"\n{'='*60}")
    print(f"  INSPECTING WEBMASTER LINK via proxy")
    print(f"  {WEBMASTER_LINK}")
    print(f"{'='*60}")
    
    try:
        r = requests.get(WEBMASTER_LINK,
            headers=MOBILE_HEADERS,
            proxies={"http": proxy_url, "https": proxy_url},
            timeout=20, allow_redirects=True)
        print(f"  Status: {r.status_code}")
        print(f"  Final URL: {r.url}")
        text = re.sub(r'<[^>]+>', ' ', r.text)
        text = re.sub(r'\s+', ' ', text).strip()
        
        checks = {
            "Get Started button": "get started" in text.lower(),
            "New Users plan":     "$1.2" in text or "new user" in text.lower(),
            "Webmaster invite":   "webmaster" in text.lower(),
            "Error/Invalid":      "404" in text or "invalid" in text.lower(),
        }
        for k, v in checks.items():
            print(f"  {'✅' if v else '❌'} {k}")
        print(f"\n  Preview: {text[:300]}")
        return True
    except Exception as e:
        print(f"  ERROR: {e}")
        return False

def analyze_curl_flow():
    """Curl requests se extracted key insights"""
    print(f"\n{'='*60}")
    print("  CURL REQUEST ANALYSIS")
    print(f"{'='*60}")
    
    insights = [
        ("clienttype", "5", "MOBILE Android (not web=0)"),
        ("clientfrom", "h5", "HTML5 mobile page"),
        ("referer_uk", WEBMASTER_REFERER_UK, "Your webmaster ID (tracks referral)"),
        ("redirectUrl", f"/webmaster?referer_uk={WEBMASTER_REFERER_UK}", "After register → webmaster page"),
        ("User-Agent", "Pixel 9 Android 15", "Mobile device fingerprint"),
        ("Referer for sendcode", f"emailRegister?redirectUrl=.../webmaster?referer_uk={WEBMASTER_REFERER_UK}", "Critical for tracking"),
        ("OTP endpoint", "/passport/register_v4/sendcode", "Same as web"),
        ("Verify endpoint", "/passport/register_v4/verify", "Same as web"),
        ("Post-register URL", f"/wap/webmaster?referer_uk={WEBMASTER_REFERER_UK}&isClickLogin=true", "Webmaster join page"),
    ]
    
    for key, value, note in insights:
        print(f"  [{key}] = {value}")
        print(f"    → {note}")
    
    print(f"\n  COMPLETE FLOW:")
    flow = [
        f"1. Open: https://www.1024terabox.com/wap/referral/{WEBMASTER_REFERER_UK}",
        f"2. Click 'Get Started'",
        f"3. Redirect to: /wap/outlogin/emailRegister?redirectUrl=.../webmaster?referer_uk={WEBMASTER_REFERER_UK}",
        f"4. Fill email → POST /sendcode (clienttype=5, mobile)",
        f"5. Get OTP → POST /verify",
        f"6. Set password → POST /finish",
        f"7. Redirect to: /wap/webmaster?referer_uk={WEBMASTER_REFERER_UK}&isClickLogin=true",
        f"8. Auto-join webmaster plan (planId=201 = New Users plan)",
        f"9. ✅ $1.2 credited to your account!",
    ]
    for step in flow:
        print(f"  {step}")

def main():
    print("="*60)
    print("  PROXY TEST + WEBMASTER FLOW ANALYZER")
    print("="*60)
    
    # Step 1: Analyze curl flow
    analyze_curl_flow()
    
    # Step 2: Test proxies
    print(f"\n{'='*60}")
    print("  TESTING PureVPN PROXIES (working_proxies.txt)")
    print(f"{'='*60}")
    
    proxies = load_proxies("working_proxies.txt")
    print(f"  Loaded {len(proxies)} unique proxies\n")
    
    working = []
    with ThreadPoolExecutor(max_workers=15) as ex:
        futures = {ex.submit(test_proxy, p): p for p in proxies[:30]}  # test first 30
        for i, fut in enumerate(as_completed(futures), 1):
            res = fut.result()
            p = res["proxy"]
            if res["ok"]:
                working.append(res)
                print(f"  ✅ [{i:2d}] {p['host'][:30]} [{res['proto']}] → {res['ip']} | {res['ms']}ms")
            else:
                print(f"  ❌ [{i:2d}] {p['host'][:30]} → FAILED")
    
    print(f"\n  Working: {len(working)}/{min(30, len(proxies))} tested")
    
    if working:
        working.sort(key=lambda x: x["ms"])
        best = working[0]
        print(f"\n  🏆 Best: {best['proxy']['host']} via {best['proto']} ({best['ms']}ms)")
        print(f"  Visible IP: {best['ip']}")
        
        # Save best proxy
        with open("best_proxy.txt", "w") as f:
            f.write(f"{best['proto']}://{best['proxy']['user']}:{best['proxy']['pwd']}@{best['proxy']['host']}:{best['proxy']['port']}\n")
        print(f"  Saved to: best_proxy.txt")
        
        # Inspect webmaster link
        inspect_webmaster_via_proxy(best["url"])
    else:
        print("\n  No proxies working - testing without proxy...")
        inspect_webmaster_via_proxy(None)

if __name__ == "__main__":
    main()
