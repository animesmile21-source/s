"""
main.py - Terabox Refer Bot - Multi Account Creator
Run: python -X utf8 main.py
"""

import asyncio
import json
import os
import random
import re
import time
from datetime import datetime
from pathlib import Path

# ── Load Config ──
def load_env(path="config.env"):
    env = {}
    try:
        for line in open(path, encoding="utf-8"):
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()
    except: pass
    return env

CFG = load_env()

ACCOUNTS_TO_CREATE = int(CFG.get("ACCOUNTS_TO_CREATE", 5))
DELAY_BETWEEN      = int(CFG.get("DELAY_BETWEEN_ACCOUNTS", 20))
HEADLESS           = CFG.get("HEADLESS", "false").lower() == "true"
USE_PROXY          = CFG.get("USE_PROXY", "true").lower() == "true"
PROXY_FILE         = CFG.get("PROXY_FILE", "good_proxies.txt")
LOG_FILE           = "logs/accounts.jsonl"

Path("logs").mkdir(exist_ok=True)


# ── Colors ──
class C:
    G = "\033[92m"  # green
    R = "\033[91m"  # red
    Y = "\033[93m"  # yellow
    B = "\033[94m"  # blue
    W = "\033[97m"  # white
    E = "\033[0m"   # reset
    BOLD = "\033[1m"


def log(tag, msg):
    now = datetime.now().strftime("%H:%M:%S")
    colors = {"INFO": C.B, "SUCCESS": C.G, "ERROR": C.R, "WARN": C.Y, "STEP": C.W + C.BOLD}
    c = colors.get(tag, C.W)
    print(f"[{now}] {c}[{tag}]{C.E} {msg}")


def load_proxies(path):
    proxies = []
    if not os.path.exists(path):
        return proxies
    for line in open(path, encoding="utf-8"):
        # Strip comments
        line = line.split("#")[0].strip()
        if not line:
            continue
        try:
            parts = line.split(":")
            if len(parts) == 4:
                # Format: host:port:user:pass
                host, port, user, pw = parts
                proxies.append({
                    "server": f"http://{host.strip()}:{port.strip()}",
                    "username": user.strip(),
                    "password": pw.strip(),
                    "_display": f"{host.strip()}:{port.strip()}"
                })
            elif "://" in line and "@" in line:
                # Format: protocol://user:pass@host:port
                proto, rest = line.split("://", 1)
                creds, host_port = rest.rsplit("@", 1)
                user, pw = creds.split(":", 1)
                proxies.append({
                    "server": f"{proto}://{host_port}",
                    "username": user,
                    "password": pw,
                    "_display": host_port
                })
            elif "://" in line:
                proxies.append({"server": line, "_display": line})
        except Exception as e:
            continue
    return proxies



async def run_account(n: int, total: int, proxy=None) -> dict:
    from bot.tempmail import create_email, get_inbox
    from bot.terabox import register_terabox

    log("STEP", f"━━━ Account {n}/{total} ━━━")
    prefix = f"debug_acc{n}_"

    # Create email
    log("INFO", "Creating temp email...")
    try:
        mail_data = create_email()
        email = mail_data["address"]
        token = mail_data["token"]
        log("SUCCESS", f"Email: {email}")
    except Exception as e:
        log("ERROR", f"Email create failed: {e}")
        return {"success": False, "error": f"email: {e}"}

    # OTP callback
    async def get_otp():
        import re as _re
        start = time.time()
        timeout = int(CFG.get("OTP_TIMEOUT", 120))
        log("STEP", "━━━ Polling Inbox for OTP ━━━")
        seen = set()
        while time.time() - start < timeout:
            emails = get_inbox(token)
            log("INFO", f"Inbox: {len(emails)} email(s)")
            for em in emails:
                eid = em.get("@id", "")
                if eid in seen:
                    continue
                seen.add(eid)
                subject = em.get("subject", "")
                text = em.get("text", "") + em.get("intro", "")
                log("INFO", f"Email: {subject}")
                m = _re.search(r'\b(\d{4,6})\b', subject + " " + text)
                if m:
                    otp = m.group(1)
                    log("SUCCESS", f"OTP: {otp}")
                    return otp
            await asyncio.sleep(5)
        log("ERROR", "OTP timeout!")
        return None

    # Register
    proxy_arg = proxy if proxy else None
    result = await register_terabox(
        email=email,
        otp_callback=get_otp,
        headless=HEADLESS,
        screenshot_prefix=prefix,
        proxy=proxy_arg
    )
    result["account_num"] = n
    result["timestamp"] = datetime.now().isoformat()

    # Save to log
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(result, ensure_ascii=False) + "\n")

    if result.get("success"):
        log("SUCCESS", f"✅ Account {n} DONE!")
        log("SUCCESS", f"   Email:    {result['email']}")
        log("SUCCESS", f"   Password: {result['password']}")
        log("SUCCESS", f"   Plan:     {'Joined ✓' if result.get('plan_joined') else 'Not joined ⚠️'}")
    else:
        log("ERROR", f"❌ Account {n} FAILED: {result.get('error', '?')}")

    return result


async def main():
    print(f"""
{C.B}{C.BOLD}
╔══════════════════════════════════════════════════════╗
║     TERABOX REFER BOT - Multi Account Creator        ║
║     Target: dm.1024terabox.com/referral/81364624626373║
╚══════════════════════════════════════════════════════╝
{C.E}""")

    # Load proxies
    proxies = []
    if USE_PROXY and PROXY_FILE:
        proxies = load_proxies(PROXY_FILE)
        if proxies:
            log("INFO", f"Loaded {len(proxies)} proxies from {PROXY_FILE}")
        else:
            log("WARN", "No proxies loaded - running direct")
    else:
        log("WARN", "Proxy disabled - running direct")

    log("INFO", f"Creating {ACCOUNTS_TO_CREATE} accounts | Headless: {HEADLESS}")
    log("INFO", f"Delay between accounts: {DELAY_BETWEEN}s")
    print()

    stats = {"success": 0, "failed": 0, "plan_joined": 0}

    for i in range(1, ACCOUNTS_TO_CREATE + 1):
        # Pick proxy
        proxy = random.choice(proxies) if proxies else None
        if proxy:
            log("INFO", f"Proxy: {proxy['_display']}")
        else:
            log("WARN", "No proxy (direct)")

        result = await run_account(i, ACCOUNTS_TO_CREATE, proxy)

        if result.get("success"):
            stats["success"] += 1
            if result.get("plan_joined"):
                stats["plan_joined"] += 1
        else:
            stats["failed"] += 1

        # Summary so far
        print(f"\n  Progress: {stats['success']} ✅ | {stats['failed']} ❌ | Plan joined: {stats['plan_joined']}\n")

        # Delay between accounts
        if i < ACCOUNTS_TO_CREATE:
            delay = DELAY_BETWEEN + random.randint(0, 10)
            log("INFO", f"Waiting {delay}s before next account...")
            await asyncio.sleep(delay)

    # Final summary
    print(f"""
{C.G}{C.BOLD}
╔══════════════════════════════════════╗
║          FINAL RESULTS               ║
╠══════════════════════════════════════╣
║  ✅ Success:     {stats['success']:<4}                  ║
║  ❌ Failed:      {stats['failed']:<4}                  ║
║  💰 Plan joined: {stats['plan_joined']:<4}                  ║
╚══════════════════════════════════════╝
{C.E}
Logs: {LOG_FILE}
""")


if __name__ == "__main__":
    asyncio.run(main())
