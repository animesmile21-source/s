"""
database.py - SQLite Database for Terabox Bot
Tables: accounts, proxies, links, sessions, settings
"""

import sqlite3
import json
from datetime import datetime, timedelta
from pathlib import Path

DB_PATH = "data/bot.db"
Path("data").mkdir(exist_ok=True)

# ── Default share links (hardcoded, always in DB) ──
DEFAULT_SHARE_LINKS = [
    "https://1024terabox.com/s/1tnhU0ZjV-v4E1ptjxvaqMw",
    "https://1024terabox.com/s/15WvQ66l9Zzwqm4nrVJp-Yw",
    "https://1024terabox.com/s/1WPiXw7hcM-h-dxZul61JLQ",
    "https://1024terabox.com/s/1HE71Nw9_TjvDVEHWMvtSDw",
    "https://1024terabox.com/s/1Giuw_A1y29WcwbUZ3QPirA",
]


def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.executescript("""
    CREATE TABLE IF NOT EXISTS accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE,
        password TEXT,
        proxy_host TEXT,
        created_at TEXT,
        active_until TEXT,
        status TEXT DEFAULT 'active',
        plan_joined INTEGER DEFAULT 0,
        last_activity TEXT,
        activity_count INTEGER DEFAULT 0,
        cookies TEXT
    );

    CREATE TABLE IF NOT EXISTS proxies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        host TEXT,
        port TEXT,
        username TEXT,
        password TEXT,
        protocol TEXT DEFAULT 'http',
        working INTEGER DEFAULT 0,
        speed_ms INTEGER DEFAULT 0,
        used_by_account INTEGER DEFAULT NULL,
        last_tested TEXT,
        source TEXT DEFAULT 'github'
    );

    CREATE TABLE IF NOT EXISTS links (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        url TEXT UNIQUE,
        added_at TEXT,
        active INTEGER DEFAULT 1,
        visit_count INTEGER DEFAULT 0,
        link_type TEXT DEFAULT 'share'
    );

    CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        account_id INTEGER,
        started_at TEXT,
        last_ping TEXT,
        status TEXT DEFAULT 'running',
        screenshot_path TEXT,
        FOREIGN KEY(account_id) REFERENCES accounts(id)
    );

    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    );
    """)
    conn.commit()

    # Migration: add link_type if missing
    try:
        conn.execute("ALTER TABLE links ADD COLUMN link_type TEXT DEFAULT 'share'")
        conn.commit()
        print("[DB] Migrated: added link_type column")
    except:
        pass  # Column already exists

    conn.close()

    # Seed default share links
    init_default_links()
    print("[DB] Database initialized")




def init_default_links():
    """Seed the 5 hardcoded share links into DB (don't overwrite if exists)"""
    conn = get_conn()
    for url in DEFAULT_SHARE_LINKS:
        conn.execute(
            "INSERT OR IGNORE INTO links (url, added_at, link_type) VALUES (?, ?, 'share')",
            (url, datetime.now().isoformat())
        )
    conn.commit()
    conn.close()


def update_webmaster_link(new_link: str) -> bool:
    """
    Replace the current webmaster referral link.
    Removes old webmaster link, adds new one.
    Also updates WEBMASTER_REFERER_UK in settings.
    """
    import re
    conn = get_conn()
    # Delete old webmaster link
    conn.execute("DELETE FROM links WHERE link_type = 'webmaster'")
    # Add new one
    conn.execute(
        "INSERT OR REPLACE INTO links (url, added_at, link_type) VALUES (?, ?, 'webmaster')",
        (new_link, datetime.now().isoformat())
    )
    conn.commit()
    conn.close()

    # Extract referer_uk from URL
    m = re.search(r'referral/(\d+)', new_link) or re.search(r'referer_uk=(\d+)', new_link)
    if m:
        set_setting("webmaster_referer_uk", m.group(1))
        set_setting("webmaster_link", new_link)
        return True
    set_setting("webmaster_link", new_link)
    return True


def get_webmaster_link() -> str:
    return get_setting("webmaster_link", "https://www.1024terabox.com/referral/81364624626373")


def get_share_links() -> list:
    """Get all active share links (for video views)"""
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM links WHERE active=1 AND link_type='share'"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]





# ── Accounts ──

def save_account(email, password, proxy_host=None, plan_joined=False, cookies=None):
    conn = get_conn()
    active_until = (datetime.now() + timedelta(days=2)).isoformat()
    try:
        conn.execute("""
            INSERT OR REPLACE INTO accounts
            (email, password, proxy_host, created_at, active_until, plan_joined, cookies)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (email, password, proxy_host,
              datetime.now().isoformat(), active_until,
              1 if plan_joined else 0,
              json.dumps(cookies) if cookies else None))
        conn.commit()
        return True
    except Exception as e:
        print(f"[DB] save_account error: {e}")
        return False
    finally:
        conn.close()


def get_active_accounts():
    conn = get_conn()
    now = datetime.now().isoformat()
    rows = conn.execute("""
        SELECT * FROM accounts
        WHERE status = 'active' AND active_until > ?
        ORDER BY created_at DESC
    """, (now,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_all_accounts(limit=20):
    conn = get_conn()
    rows = conn.execute("""
        SELECT * FROM accounts ORDER BY created_at DESC LIMIT ?
    """, (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_account_activity(account_id, screenshot_path=None):
    conn = get_conn()
    conn.execute("""
        UPDATE accounts SET
            last_activity = ?,
            activity_count = activity_count + 1
        WHERE id = ?
    """, (datetime.now().isoformat(), account_id))
    conn.commit()
    conn.close()


def expire_old_accounts():
    conn = get_conn()
    now = datetime.now().isoformat()
    conn.execute("""
        UPDATE accounts SET status = 'expired'
        WHERE active_until < ? AND status = 'active'
    """, (now,))
    count = conn.execute("SELECT changes()").fetchone()[0]
    conn.commit()
    conn.close()
    return count


def get_account_stats():
    conn = get_conn()
    total = conn.execute("SELECT COUNT(*) FROM accounts").fetchone()[0]
    active = conn.execute(
        "SELECT COUNT(*) FROM accounts WHERE status='active' AND active_until > ?",
        (datetime.now().isoformat(),)
    ).fetchone()[0]
    expired = conn.execute("SELECT COUNT(*) FROM accounts WHERE status='expired'").fetchone()[0]
    plan_joined = conn.execute("SELECT COUNT(*) FROM accounts WHERE plan_joined=1").fetchone()[0]
    conn.close()
    return {"total": total, "active": active, "expired": expired, "plan_joined": plan_joined}


# ── Proxies ──

def clear_proxies():
    conn = get_conn()
    conn.execute("DELETE FROM proxies WHERE used_by_account IS NULL")
    conn.commit()
    conn.close()


def bulk_save_proxies(proxy_list):
    """proxy_list: list of {host, port, username, password, protocol}"""
    conn = get_conn()
    conn.executemany("""
        INSERT OR IGNORE INTO proxies (host, port, username, password, protocol, last_tested)
        VALUES (:host, :port, :username, :password, :protocol, :last_tested)
    """, [{**p, "last_tested": datetime.now().isoformat()} for p in proxy_list])
    conn.commit()
    count = conn.execute("SELECT COUNT(*) FROM proxies WHERE used_by_account IS NULL").fetchone()[0]
    conn.close()
    return count


def save_working_proxy(proxy_data, speed_ms):
    conn = get_conn()
    conn.execute("""
        UPDATE proxies SET working=1, speed_ms=?, last_tested=?
        WHERE host=? AND port=?
    """, (speed_ms, datetime.now().isoformat(), proxy_data["host"], proxy_data["port"]))
    conn.commit()
    conn.close()


def get_available_proxies(n):
    """Get n unused working proxies, mark them as taken"""
    conn = get_conn()
    rows = conn.execute("""
        SELECT * FROM proxies
        WHERE working=1 AND used_by_account IS NULL
        ORDER BY speed_ms ASC
        LIMIT ?
    """, (n,)).fetchall()
    proxies = [dict(r) for r in rows]
    for p in proxies:
        conn.execute("UPDATE proxies SET used_by_account = -1 WHERE id = ?", (p["id"],))
    conn.commit()
    conn.close()
    return proxies


def assign_proxy_to_account(proxy_id, account_id):
    conn = get_conn()
    conn.execute("UPDATE proxies SET used_by_account=? WHERE id=?", (account_id, proxy_id))
    conn.commit()
    conn.close()


def get_proxy_stats():
    conn = get_conn()
    total = conn.execute("SELECT COUNT(*) FROM proxies").fetchone()[0]
    working = conn.execute("SELECT COUNT(*) FROM proxies WHERE working=1").fetchone()[0]
    free = conn.execute(
        "SELECT COUNT(*) FROM proxies WHERE working=1 AND used_by_account IS NULL"
    ).fetchone()[0]
    conn.close()
    return {"total": total, "working": working, "free": free}


# ── Links ──

def add_link(url):
    conn = get_conn()
    try:
        conn.execute(
            "INSERT OR IGNORE INTO links (url, added_at) VALUES (?, ?)",
            (url, datetime.now().isoformat())
        )
        conn.commit()
        return True
    except:
        return False
    finally:
        conn.close()


def get_active_links():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM links WHERE active=1").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def increment_link_visits(link_id):
    conn = get_conn()
    conn.execute("UPDATE links SET visit_count = visit_count + 1 WHERE id = ?", (link_id,))
    conn.commit()
    conn.close()


# ── Settings ──

def get_setting(key, default=None):
    conn = get_conn()
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    conn.close()
    return row[0] if row else default


def set_setting(key, value):
    conn = get_conn()
    conn.execute(
        "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
        (key, str(value))
    )
    conn.commit()
    conn.close()


if __name__ == "__main__":
    init_db()
    print("[DB] All tables created")
