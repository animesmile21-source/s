import database
database.init_db()
links = database.get_share_links()
print("Share links:", len(links))
for l in links:
    print(" -", l["url"])
wm = database.get_webmaster_link()
print("Webmaster:", wm[:60])
import bot.viewer
print("Viewer: OK")
import telegram_bot
print("Telegram bot: OK")
print("ALL SYSTEMS GO!")
