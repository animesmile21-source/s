"""
bot/viewer.py - Video Views Generator
Uses free GitHub proxies to generate views on Terabox share links
No login needed - public links, just visit + simulate watch time
"""

import asyncio
import aiohttp
import random
import time
from datetime import datetime
from playwright.async_api import async_playwright

# ── Default hardcoded share links ──
DEFAULT_SHARE_LINKS = [
    "https://1024terabox.com/s/1tnhU0ZjV-v4E1ptjxvaqMw",
    "https://1024terabox.com/s/15WvQ66l9Zzwqm4nrVJp-Yw",
    "https://1024terabox.com/s/1WPiXw7hcM-h-dxZul61JLQ",
    "https://1024terabox.com/s/1HE71Nw9_TjvDVEHWMvtSDw",
    "https://1024terabox.com/s/1Giuw_A1y29WcwbUZ3QPirA",
]

DESKTOP_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
)

# Mobile UAs for variety
MOBILE_UAS = [
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Version/17.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 12; Samsung SM-G991B) AppleWebKit/537.36 Chrome/119.0.0.0 Mobile Safari/537.36",
]

ALL_UAS = [DESKTOP_UA] * 3 + MOBILE_UAS


async def visit_link_with_proxy(proxy: dict, url: str, watch_seconds: int = 30) -> bool:
    """
    Visit a share link using a proxy and simulate video watch.
    Returns True if view was counted.
    """
    proxy_server = f"{proxy.get('protocol','http')}://{proxy['host']}:{proxy['port']}"
    proxy_auth = None
    if proxy.get("username"):
        proxy_auth = {"username": proxy["username"], "password": proxy.get("password", "")}

    ua = random.choice(ALL_UAS)

    async with async_playwright() as p:
        launch_args = {
            "headless": True,
            "args": [
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-blink-features=AutomationControlled",
                "--autoplay-policy=no-user-gesture-required",
                "--mute-audio",
            ],
            "proxy": {
                "server": proxy_server,
                **({"username": proxy_auth["username"], "password": proxy_auth["password"]}
                   if proxy_auth else {})
            }
        }

        try:
            browser = await p.chromium.launch(**launch_args)
            context = await browser.new_context(
                user_agent=ua,
                viewport={"width": random.randint(800, 1440), "height": random.randint(600, 900)},
                locale=random.choice(["en-US", "en-GB", "en-IN"]),
            )
            page = await context.new_page()

            # Visit the share link
            await page.goto(url, wait_until="domcontentloaded", timeout=20000)
            await page.wait_for_timeout(random.randint(2000, 4000))

            # Try to play video
            video_played = False
            for sel in [
                "video",
                ".play-icon",
                "[class*='play-btn']",
                "[class*='video-play']",
                ".vjs-big-play-button",
                "button[title*='Play']",
            ]:
                try:
                    el = page.locator(sel).first
                    if await el.count() > 0:
                        await el.click(force=True)
                        video_played = True
                        print(f"    [VIEW] Video play clicked: {sel}")
                        break
                except:
                    continue

            # Simulate watch time
            watch_ms = watch_seconds * 1000 + random.randint(0, 10000)
            elapsed = 0
            while elapsed < watch_ms:
                chunk = random.randint(3000, 8000)
                await page.wait_for_timeout(chunk)
                elapsed += chunk

                # Occasional scroll/mouse move
                if random.random() < 0.3:
                    try:
                        await page.mouse.move(
                            random.randint(100, 800),
                            random.randint(100, 500)
                        )
                    except:
                        pass

            await browser.close()
            return True

        except Exception as e:
            print(f"    [VIEW] Error: {str(e)[:60]}")
            try:
                await browser.close()
            except:
                pass
            return False


async def generate_views_fast(proxy: dict, url: str) -> bool:
    """
    Faster view generation using requests (no browser) - for speed.
    Just makes HTTP request to the share URL with proxy.
    """
    proxy_url = f"{proxy.get('protocol','http')}://"
    if proxy.get("username"):
        proxy_url += f"{proxy['username']}:{proxy.get('password','')}@"
    proxy_url += f"{proxy['host']}:{proxy['port']}"

    ua = random.choice(ALL_UAS)
    headers = {
        "User-Agent": ua,
        "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://www.google.com/",
        "DNT": "1",
    }

    try:
        timeout = aiohttp.ClientTimeout(total=15)
        connector = aiohttp.TCPConnector(ssl=False)
        async with aiohttp.ClientSession(
            headers=headers,
            connector=connector,
            timeout=timeout
        ) as session:
            async with session.get(url, proxy=proxy_url, allow_redirects=True) as resp:
                content = await resp.read()
                # Wait a bit to simulate read time
                await asyncio.sleep(random.uniform(5, 15))
                return resp.status == 200
    except:
        return False


async def run_views_batch(
    proxies: list[dict],
    links: list[str],
    use_browser: bool = True,
    concurrency: int = 10,
    notify_cb=None
) -> dict:

    """
    Run views generation for all proxies across all links.
    Each proxy visits a random link from the list.
    
    proxies: list of proxy dicts
    links: list of URLs to visit
    use_browser: True = Playwright (slower but more realistic), False = requests (faster)
    concurrency: max parallel workers
    """
    if not proxies or not links:
        return {"total": 0, "success": 0, "failed": 0}

    print(f"[VIEWS] Starting {len(proxies)} views across {len(links)} links...")
    if notify_cb:
        await notify_cb(f"🎬 Generating views: {len(proxies)} proxies → {len(links)} links")

    semaphore = asyncio.Semaphore(concurrency)
    stats = {"total": len(proxies), "success": 0, "failed": 0}

    async def one_view(proxy, url, idx):
        async with semaphore:
            if use_browser:
                ok = await visit_link_with_proxy(proxy, url, watch_seconds=25)
            else:
                ok = await generate_views_fast(proxy, url)

            if ok:
                stats["success"] += 1
                print(f"  [VIEW] ✅ {idx}/{len(proxies)} | {url[-20:]}")
            else:
                stats["failed"] += 1
                print(f"  [VIEW] ❌ {idx}/{len(proxies)} | proxy: {proxy['host']}")

            # Progress update every 50
            if (stats["success"] + stats["failed"]) % 50 == 0 and notify_cb:
                done = stats["success"] + stats["failed"]
                await notify_cb(
                    f"🎬 Views progress: {done}/{stats['total']} "
                    f"(✅{stats['success']} ❌{stats['failed']})"
                )

    tasks = []
    for idx, proxy in enumerate(proxies, 1):
        url = links[(idx - 1) % len(links)]  # rotate through links
        tasks.append(one_view(proxy, url, idx))

    await asyncio.gather(*tasks)

    summary = (
        f"🎬 Views Done!\n"
        f"✅ Success: {stats['success']}\n"
        f"❌ Failed: {stats['failed']}\n"
        f"📊 Total attempted: {stats['total']}"
    )
    print(f"[VIEWS] {summary}")
    if notify_cb:
        await notify_cb(summary)

    # Save to DB
    from database import increment_link_visits, get_active_links
    active_links_db = get_active_links()
    for l in active_links_db:
        increment_link_visits(l["id"])

    return stats


async def fetch_github_proxies_for_views(n: int) -> list[dict]:
    """
    Fetch fresh proxies from GitHub specifically for views generation.
    These are FREE proxies, many won't work but we test them fast.
    """
    from bot.proxy_manager import fetch_proxy_list, test_proxies, parse_proxy_line
    import aiohttp

    print(f"[VIEWS] Fetching proxies from GitHub for {n} views...")

    proxies = await fetch_proxy_list()
    random.shuffle(proxies)  # randomize

    # Quick-test with higher concurrency for speed
    semaphore = asyncio.Semaphore(150)
    working = []
    tested = 0

    async def quick_test(proxy):
        nonlocal tested
        proxy_url = f"{proxy.get('protocol','http')}://"
        if proxy.get("username"):
            proxy_url += f"{proxy['username']}:{proxy.get('password','')}@"
        proxy_url += f"{proxy['host']}:{proxy['port']}"

        try:
            async with semaphore:
                async with aiohttp.ClientSession() as sess:
                    async with sess.get(
                        "http://httpbin.org/ip",
                        proxy=proxy_url,
                        timeout=aiohttp.ClientTimeout(total=6),
                        ssl=False
                    ) as resp:
                        if resp.status == 200:
                            return proxy
        except:
            pass
        return None

    # Test until we have n working proxies (or tested max 600)
    batch_size = 150
    for i in range(0, min(len(proxies), 600), batch_size):
        if len(working) >= n:
            break
        batch = proxies[i:i + batch_size]
        results = await asyncio.gather(*[quick_test(p) for p in batch])
        new = [r for r in results if r]
        working.extend(new)
        tested += len(batch)
        print(f"[VIEWS] Tested {tested} | Found {len(working)} working")

    print(f"[VIEWS] Proxy fetch done: {len(working)} ready for views")
    return working[:n]


if __name__ == "__main__":
    async def test():
        links = DEFAULT_SHARE_LINKS
        proxies = await fetch_github_proxies_for_views(50)
        stats = await run_views_batch(proxies, links, use_browser=False, concurrency=30)
        print(stats)
    asyncio.run(test())
