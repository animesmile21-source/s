"""
terabox.py - Terabox Registration Bot (Desktop + Stealth)
Uses playwright-stealth to bypass verify_v2 bot detection
Flow: referral → Get Started → Login page → ↓ expand → Email → OTP → Password
"""

import asyncio
import random
import string
import re

from playwright.async_api import async_playwright
try:
    from playwright_stealth import Stealth
    _STEALTH = Stealth(
        navigator_webdriver=True,
        navigator_languages=True,
        navigator_plugins=True,
        chrome_runtime=True,
        webgl_vendor=True,
        navigator_platform=True,
    )
    HAS_STEALTH = True
except ImportError:
    HAS_STEALTH = False
    print("[WARN] playwright-stealth not installed")

from database import get_webmaster_link

# Desktop Windows Chrome (matches user's working curl)
DESKTOP_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
)



def gen_password(length=12) -> str:
    chars = string.ascii_letters + string.digits + "!@#$"
    pwd = (
        random.choice(string.ascii_uppercase) +
        random.choice(string.ascii_lowercase) +
        random.choice(string.digits) +
        ''.join(random.choices(chars, k=length - 3))
    )
    return ''.join(random.sample(pwd, len(pwd)))


async def _safe_screenshot(page, path):
    try:
        await page.screenshot(path=path, timeout=60000)
    except:
        pass


async def _fill_input(page, selectors, value, delay=60):
    """Fill input using Locator API (required for press_sequentially)"""
    for sel in selectors:
        try:
            loc = page.locator(sel).first
            if await loc.count() > 0:
                await loc.click()
                await page.wait_for_timeout(300)
                await loc.fill("")
                await loc.press_sequentially(value, delay=delay)
                await page.wait_for_timeout(500)
                await loc.dispatch_event("input")
                await loc.dispatch_event("change")
                await loc.dispatch_event("keyup")
                val = await loc.input_value()
                if val == value:
                    return True, sel
        except Exception as e:
            continue
    return False, None


async def register_terabox(
    email: str,
    otp_callback,
    headless: bool = False,
    screenshot_prefix: str = "debug_",
    proxy: dict = None
) -> dict:
    """
    Register Terabox account via browser automation.
    otp_callback: async function() → OTP string or None
    Returns: {"success": bool, "email": str, "password": str, "error": str}
    """
    referral_url = get_webmaster_link()
    uk_match = re.search(r'referral/(\d+)', referral_url) or re.search(r'referer_uk=(\d+)', referral_url)
    referer_uk = uk_match.group(1) if uk_match else "81364624626373"

    print(f"  [BOT] Target Referral: {referral_url} (UK: {referer_uk})")

    async with async_playwright() as p:
        launch_args = {
            "headless": headless,
            "args": [
                "--no-sandbox",
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
                "--disable-web-security",
                "--allow-running-insecure-content",
                "--disable-features=IsolateOrigins,site-per-process",
            ]
        }
        if proxy:
            launch_args["proxy"] = proxy

        browser = await p.chromium.launch(**launch_args)

        context = await browser.new_context(
            user_agent=DESKTOP_UA,
            viewport={"width": 1366, "height": 768},
            locale="en-US",
            timezone_id="Asia/Kolkata",
            extra_http_headers={
                "sec-ch-ua": '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": '"Windows"',
                "Accept-Language": "en-US,en;q=0.9",
            }
        )
        page = await context.new_page()

        # ── Apply stealth patches ──
        if HAS_STEALTH:
            await _STEALTH.apply_stealth_async(page)
            print(f"  [BOT] Stealth mode: ON ✓ (playwright-stealth v2)")
        else:
            # Manual anti-detection
            await page.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
                Object.defineProperty(navigator, 'plugins', {get: () => [1,2,3,4,5]});
                Object.defineProperty(navigator, 'languages', {get: () => ['en-US','en']});
                window.chrome = {runtime: {app: {}, csi: ()=>{}, loadTimes: ()=>{}}};
            """)

        # ── API Response logger ──
        api_log = {}
        async def on_response(response):
            url = response.url
            for keyword in ["sendcode", "verify", "finish", "getpubkey"]:
                if keyword in url:
                    try:
                        body = await response.text()
                        api_log[keyword] = {"url": url, "status": response.status, "body": body}
                        print(f"  [API] {keyword} [{response.status}]: {body[:250]}")
                    except: pass
                    break
        page.on("response", on_response)

        # ── jsToken store & Route injector ──
        token_box = {"jsToken": None, "pcfToken": None}

        async def inject_token(route, request):
            url = request.url
            t = token_box["jsToken"]
            if t and "jsToken" not in url:
                sep = "&" if "?" in url else "?"
                await route.continue_(url=f"{url}{sep}jsToken={t}")
                print(f"  [ROUTE] +jsToken → {url.split('/')[-1].split('?')[0]}")
            else:
                await route.continue_()

        await page.route("**/passport/**", inject_token)

        try:
            # ═══ STEP 1: Load referral page ═══
            print(f"  [BOT] → Referral: {referral_url}")
            await page.goto(referral_url, wait_until="networkidle", timeout=45000)
            await page.wait_for_timeout(3000)
            await _safe_screenshot(page, f"{screenshot_prefix}step1_referral.png")
            print(f"  [BOT] URL: {page.url} | Title: {await page.title()}")


            # Extract jsToken (length=192 hex chars)
            js_token = None

            # Method 1: window variables
            js_token = await page.evaluate("""
                () => {
                    const sources = [
                        window.jsToken, window.__jsToken,
                        window.templateData?.jsToken,
                        window.__INITIAL_STATE__?.jsToken,
                        document.querySelector('meta[name="jsToken"]')?.content
                    ];
                    return sources.find(v => v && v.length > 30) || null;
                }
            """)

            # Method 2: HTML source regex
            if not js_token:
                content = await page.content()
                m = re.search(r'"jsToken"\s*:\s*"([A-Fa-f0-9]{40,})"', content)
                if m:
                    js_token = m.group(1)
                    print(f"  [BOT] jsToken from HTML")

            if js_token:
                token_box["jsToken"] = js_token
                print(f"  [BOT] jsToken: {js_token[:60]}... len={len(js_token)}")
            else:
                print(f"  [BOT] jsToken NOT found (will try without)")

            # ═══ STEP 2: Click "Get Started" ═══
            print(f"  [BOT] Clicking Get Started...")
            for sel in ["text=Get Started", "button:has-text('Get Started')", ".btn-start", "[class*='start']"]:
                try:
                    loc = page.locator(sel).first
                    if await loc.count() > 0:
                        await loc.click()
                        print(f"  [BOT] Get Started clicked: {sel}")
                        break
                except: continue

            await page.wait_for_timeout(3000)
            await _safe_screenshot(page, f"{screenshot_prefix}step2_after_getstarted.png")
            print(f"  [BOT] URL: {page.url}")

            # ═══ STEP 3: Navigate through Login page to Email Register ═══
            current_url = page.url

            # If on login page (shows Google/Facebook) → expand more options
            if "login" in current_url or "outlogin" in current_url:
                print(f"  [BOT] On login page - looking for email option...")

                # Try clicking the ↓ (chevron/arrow) to expand more options
                for sel in [
                    "[class*='chevron']", "[class*='arrow']", "[class*='more']",
                    "svg[class*='arrow']", ".icon-arrow-down", "text=More",
                    "[class*='expand']", "text=More options",
                ]:
                    try:
                        loc = page.locator(sel).first
                        if await loc.count() > 0:
                            await loc.click()
                            print(f"  [BOT] Expanded options: {sel}")
                            await page.wait_for_timeout(1500)
                            break
                    except: continue

                # Look for email/create account link
                for sel in [
                    "text=Sign up with Email",
                    "text=Email",
                    "text=Create account",
                    "text=Register",
                    "a[href*='emailRegister']",
                    "a[href*='register']",
                    "[class*='email']",
                ]:
                    try:
                        loc = page.locator(sel).first
                        if await loc.count() > 0:
                            await loc.click()
                            print(f"  [BOT] Clicked email option: {sel}")
                            await page.wait_for_timeout(2000)
                            break
                    except: continue

            # If still not on email register, navigate directly
            if "emailRegister" not in page.url:
                register_url = (
                    f"https://www.1024terabox.com/wap/outlogin/emailRegister"
                    f"?redirectUrl=https%3A%2F%2Fwww.1024terabox.com%2Fwebmaster"
                    f"%3Freferer_uk%3D{referer_uk}%26isClickLogin%3Dtrue&tab=2"
                )

                print(f"  [BOT] Direct nav → emailRegister")
                await page.goto(register_url, wait_until="domcontentloaded", timeout=30000)
                await page.wait_for_timeout(3000)

            await _safe_screenshot(page, f"{screenshot_prefix}step3_email_form.png")
            print(f"  [BOT] Email form URL: {page.url}")

            # ═══ STEP 4: Fill Email ═══
            print(f"  [BOT] Filling: {email}")
            await page.wait_for_timeout(1500)

            # Wait for email input
            try:
                await page.wait_for_selector("input", timeout=12000)
            except:
                print(f"  [BOT] WARNING: No input visible")

            # Debug inputs
            inputs = await page.evaluate("""
                () => [...document.querySelectorAll('input')].map(i =>
                    ({id:i.id, type:i.type, placeholder:i.placeholder, visible:i.offsetParent!==null}))
            """)
            print(f"  [BOT] Inputs: {inputs}")

            ok, used_sel = await _fill_input(page, [
                "input#email-input",
                "input[placeholder='Enter your email']",
                "input[placeholder*='email' i]",
                "input[type='email']",
                "input[type='text']",
            ], email)

            if not ok:
                raise Exception(f"Cannot fill email. DOM inputs: {inputs}")
            print(f"  [BOT] Email filled [{used_sel}]")
            await _safe_screenshot(page, f"{screenshot_prefix}step4_email_filled.png")

            # ═══ STEP 5: Click Continue ═══
            print(f"  [BOT] Waiting for button enabled...")
            try:
                await page.wait_for_function("""
                    () => {
                        const b = document.querySelector('.btn-class-register');
                        return b && !b.className.includes('disabled') && !b.disabled;
                    }
                """, timeout=6000)
                print(f"  [BOT] Button ENABLED ✓")
            except:
                print(f"  [BOT] Button check timeout - clicking anyway")

            # Get button state
            btn = await page.evaluate("""
                () => {
                    const b = document.querySelector('.btn-class-register, button');
                    return b ? {class: b.className.substring(0,60), text: b.textContent.trim()} : null;
                }
            """)
            print(f"  [BOT] Button: {btn}")

            for sel in [".btn-class-register", "button:has-text('Continue')", "button[type='submit']"]:
                try:
                    loc = page.locator(sel).first
                    if await loc.count() > 0:
                        await loc.click(force=True)
                        print(f"  [BOT] Continue clicked [{sel}]")
                        break
                except: continue

            # Wait for sendcode response
            print(f"  [BOT] Waiting for sendcode...")
            try:
                await page.wait_for_function("""
                    () => document.querySelector(
                        '.new-card-verify-input, .verify-input, input[maxlength="1"]'
                    ) || window.location.href.includes('verify') ||
                    window.location.href.includes('Verfify')
                """, timeout=15000)
                print(f"  [BOT] OTP form appeared! ✓")
            except:
                print(f"  [BOT] OTP form not detected in 15s")

            await page.wait_for_timeout(2000)
            await _safe_screenshot(page, f"{screenshot_prefix}step5_after_continue.png")
            print(f"  [BOT] URL: {page.url}")

            # Check sendcode result
            if "sendcode" in api_log:
                sc = api_log["sendcode"]
                body = sc.get("body", "")
                if '"errno":0' in body or '"errno": 0' in body:
                    print(f"  [BOT] sendcode SUCCESS ✓")
                elif "400090" in body:
                    print(f"  [BOT] sendcode BLOCKED (verify_v2) - stealth may not have helped")
                else:
                    print(f"  [BOT] sendcode response: {body[:100]}")

            # ═══ STEP 6: Get OTP ═══
            print(f"  [BOT] Polling inbox...")
            otp = await otp_callback()
            if not otp:
                result["error"] = "OTP timeout - email not received"
                return result
            print(f"  [BOT] OTP: {otp} ✓")

            # ═══ STEP 7: Fill OTP ═══
            await page.wait_for_timeout(2000)
            await _safe_screenshot(page, f"{screenshot_prefix}step6_otp_page.png")

            otp_filled = False
            # Individual digit inputs
            for sel in ["input[maxlength='1']", ".new-card-verify-input input", ".verify-input input"]:
                try:
                    digit_inputs = await page.locator(sel).all()
                    if len(digit_inputs) >= len(otp):
                        for i, ch in enumerate(otp):
                            await digit_inputs[i].click()
                            await digit_inputs[i].fill(ch)
                            await digit_inputs[i].dispatch_event("input")
                            await digit_inputs[i].dispatch_event("keyup")
                            await page.wait_for_timeout(80)
                        print(f"  [BOT] OTP digits filled")
                        otp_filled = True
                        break
                except: continue

            if not otp_filled:
                ok2, _ = await _fill_input(page, ["input[type='text']", "input[type='number']"], otp, delay=100)
                if ok2:
                    print(f"  [BOT] OTP single field filled")
                    otp_filled = True

            await page.wait_for_timeout(2000)
            await _safe_screenshot(page, f"{screenshot_prefix}step7_otp_filled.png")

            # Click Verify/Next if needed
            for sel in ["text=Verify", "text=Confirm", "text=Submit", "button[type='submit']"]:
                try:
                    loc = page.locator(sel).first
                    if await loc.count() > 0:
                        await loc.click(force=True)
                        print(f"  [BOT] OTP submitted [{sel}]")
                        break
                except: continue

            # ═══ STEP 8: Fill Password ═══
            await page.wait_for_timeout(3000)
            await _safe_screenshot(page, f"{screenshot_prefix}step8_password.png")
            print(f"  [BOT] Setting password...")

            pw_inputs = await page.locator("input[type='password']").all()
            for pw_inp in pw_inputs[:2]:
                try:
                    await pw_inp.click()
                    await pw_inp.fill(password)
                    await pw_inp.dispatch_event("input")
                except: continue
            if pw_inputs:
                print(f"  [BOT] Password set ({len(pw_inputs[:2])} fields)")

            # Click submit
            for sel in ["text=Sign up", "text=Create account", "text=Done", "button[type='submit']", ".btn-submit", ".btn-class-register"]:
                try:
                    loc = page.locator(sel).first
                    if await loc.count() > 0:
                        await loc.click(force=True)
                        print(f"  [BOT] Submitted [{sel}]")
                        break
                except: continue

            await page.wait_for_timeout(5000)
            await _safe_screenshot(page, f"{screenshot_prefix}step9_submitted.png")
            print(f"  [BOT] URL after submit: {page.url}")

            # ═══ STEP 9: Join Webmaster Plan ═══
            webmaster_url = (
                f"https://dm.1024terabox.com/webmaster/join-us"
                f"?referer_uk={referer_uk}&isClickLogin=true"
            )

            print(f"  [BOT] → Webmaster plan join page")
            await page.goto(webmaster_url, wait_until="domcontentloaded", timeout=30000)
            await page.wait_for_timeout(4000)
            await _safe_screenshot(page, f"{screenshot_prefix}step10_webmaster.png")
            print(f"  [BOT] Webmaster page: {page.url}")

            # Click "New Users" plan card (recommended)
            for sel in ["text=New Users", "[class*='recommend']", ".plan-card:first-child"]:
                try:
                    loc = page.locator(sel).first
                    if await loc.count() > 0:
                        await loc.click()
                        print(f"  [BOT] Selected New Users plan [{sel}]")
                        await page.wait_for_timeout(1000)
                        break
                except: continue

            # Check Terms of Service checkbox
            for sel in ["input[type='checkbox']", "[class*='checkbox']", "[class*='agree']"]:
                try:
                    loc = page.locator(sel).first
                    if await loc.count() > 0:
                        await loc.click(force=True)
                        print(f"  [BOT] Terms checkbox checked [{sel}]")
                        await page.wait_for_timeout(500)
                        break
                except: continue

            # Click "Join this plan" button
            plan_joined = False
            for sel in [
                "text=Join this plan",
                "text=Join Now",
                "text=Join Plan",
                "button:has-text('Join')",
                ".join-btn",
                "[class*='join']",
            ]:
                try:
                    loc = page.locator(sel).first
                    if await loc.count() > 0:
                        await loc.click(force=True)
                        print(f"  [BOT] Plan JOIN clicked [{sel}] ✓")
                        plan_joined = True
                        await page.wait_for_timeout(3000)
                        break
                except: continue

            result["plan_joined"] = plan_joined
            await _safe_screenshot(page, f"{screenshot_prefix}step11_plan_joined.png")
            print(f"  [BOT] Plan join URL: {page.url}")



            # ═══ SUCCESS CHECK ═══
            final_url = page.url
            final_text = await page.evaluate("() => document.body.innerText")
            print(f"  [BOT] Final URL: {final_url}")

            not_on_login = "login" not in final_text.lower()[:200]
            on_webmaster = "webmaster" in final_url or "revenue" in final_text.lower()

            if on_webmaster or not_on_login:
                result["success"] = True
                print(f"  [BOT] ✅ SUCCESS! {email} | pwd: {password}")
            else:
                result["error"] = "Ended on login page - registration may have failed"
                print(f"  [BOT] ⚠️ Uncertain result")

        except Exception as e:
            result["error"] = str(e)
            print(f"  [BOT] ❌ Error: {e}")
            try:
                await page.screenshot(path=f"{screenshot_prefix}error.png", timeout=30000)
            except: pass
        finally:
            await browser.close()

    return result
