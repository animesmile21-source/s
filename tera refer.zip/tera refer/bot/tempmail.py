"""
bot/tempmail.py - Temp Mail using mail.tm API (no API key needed!)
Fallback: guerrilla mail
"""

import requests
import random
import string
import time

# ── mail.tm API (completely free, no key needed) ──
MAILTM_BASE = "https://api.mail.tm"

def _random_string(length=10):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))


def create_email() -> dict:
    """
    mail.tm se ek temp email address banao.
    Returns: {"address": str, "token": str, "password": str}
    """
    # Step 1: Get available domains
    try:
        r = requests.get(f"{MAILTM_BASE}/domains", timeout=15)
        domains = r.json().get("hydra:member", [])
        if not domains:
            raise Exception("No domains available from mail.tm")
        domain = random.choice(domains)["domain"]
    except Exception as e:
        raise Exception(f"mail.tm domain fetch failed: {e}")

    # Step 2: Create account
    username = _random_string(10)
    email_addr = f"{username}@{domain}"
    password = _random_string(12)

    try:
        r = requests.post(
            f"{MAILTM_BASE}/accounts",
            json={"address": email_addr, "password": password},
            timeout=15
        )
        if r.status_code not in (200, 201):
            raise Exception(f"Account create failed: {r.status_code} {r.text[:100]}")
    except Exception as e:
        raise Exception(f"mail.tm account create failed: {e}")

    # Step 3: Get auth token
    try:
        r = requests.post(
            f"{MAILTM_BASE}/token",
            json={"address": email_addr, "password": password},
            timeout=15
        )
        if r.status_code != 200:
            raise Exception(f"Token fetch failed: {r.status_code} {r.text[:100]}")
        token = r.json()["token"]
    except Exception as e:
        raise Exception(f"mail.tm token failed: {e}")

    return {
        "address": email_addr,
        "password": password,
        "token": token,
        "provider": "mail.tm"
    }


def get_inbox(token: str) -> list:
    """
    Inbox check karo - returns list of email objects
    token: JWT token from create_email()
    """
    try:
        r = requests.get(
            f"{MAILTM_BASE}/messages",
            headers={"Authorization": f"Bearer {token}"},
            timeout=15
        )
        if r.status_code == 200:
            messages = r.json().get("hydra:member", [])
            # Get full content for each message
            result = []
            for msg in messages:
                msg_id = msg.get("id", "")
                try:
                    detail = requests.get(
                        f"{MAILTM_BASE}/messages/{msg_id}",
                        headers={"Authorization": f"Bearer {token}"},
                        timeout=10
                    )
                    if detail.status_code == 200:
                        full = detail.json()
                        result.append({
                            "@id": msg_id,
                            "subject": full.get("subject", ""),
                            "text": full.get("text", ""),
                            "html": str(full.get("html", "")),
                            "intro": full.get("intro", ""),
                            "from": full.get("from", {}).get("address", ""),
                        })
                except:
                    result.append(msg)
            return result
        return []
    except Exception as e:
        print(f"  [MAIL] Inbox error: {e}")
        return []


# ── Legacy function (backward compat) ──
def wait_for_otp(token: str, timeout: int = 120) -> str | None:
    """Blocking OTP wait (for non-async code)"""
    import re
    start = time.time()
    seen = set()
    while time.time() - start < timeout:
        emails = get_inbox(token)
        for em in emails:
            eid = em.get("@id", "")
            if eid in seen: continue
            seen.add(eid)
            text = em.get("subject", "") + " " + em.get("text", "") + " " + em.get("intro", "")
            m = re.search(r'\b(\d{4,6})\b', text)
            if m:
                return m.group(1)
        time.sleep(5)
    return None


if __name__ == "__main__":
    print("Testing mail.tm...")
    data = create_email()
    print(f"Email: {data['address']}")
    print(f"Pass:  {data['password']}")
    print(f"Token: {data['token'][:40]}...")
    print("\nInbox (empty, just created):")
    msgs = get_inbox(data["token"])
    print(f"Messages: {len(msgs)}")
    print("mail.tm working!")
