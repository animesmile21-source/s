"""
bot/activity.py - 2-Day Account Activity Simulation
Keeps accounts active by browsing Terabox links, playing videos etc.
"""

import asyncio
import random
import os
from datetime import datetime
from playwright.async_api import async_playwright
from playwright_stealth import Stealth
from database import get_active_accounts, get_active_links, update_account_activity, increment_link_visits

_STEALTH = Stealth(navigator_webdriver=True, navigator_plugins=True, chrome_runtime=True)

DESKTOP_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
)

TERABOX_LINKS = [
    # fallback links if user hasn't added any
    "https://www.1024terabox.com/",
    "https://dm.1024terabox.com/webmaster",
]


async def simulate_activity(account: dict, links: list, proxy: dict = None) -> dict:
    """
    Simulates real user activity for one account.
    Returns: {"success": bool, "screenshot": path, "message": str}
    """
    email = account["email"]
    password = account["password"]
    acc_id = account["id"]

    result = {"success": False, "screenshot": None, "message": ""}

    if not links:
        links = [{"url": l, "id": None} for l in TERABOX_LINKS]

    link = random.choice(links)
    target_url = link["url"] if isinstance(link, dict) else link

    print(f"  [ACTIVITY] Account: {email} | URL: {target_url[:50]}")

    async with async_playwright() as p:
        launch_args = {
            "headless": True,
            "args": [
                "--no-sandbox",
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
                "--autoplay-policy=no-user-gesture-required",
            ]
        }
        if proxy:
            launch_args["proxy"] = proxy

        browser = await p.chromium.launch(**launch_args)
        context = await browser.new_context(
            user_agent=DESKTOP_UA,
            viewport={"width": 1366, "height": 768},
            locale="en-US",
        )
        page = await context.new_page()
        await _STEALTH.apply_stealth_async(page)

        try:
            # ── Login first ──
            login_url = "https://www.1024terabox.com/wap/outlogin/login"
            await page.goto(login_url, wait_until="domcontentloaded", timeout=30000)
            await page.wait_for_timeout(2000)

            # Look for email login option
            for sel in ["text=Email", "text=Log in with email", "a[href*='emailLogin']"]:
                try:
                    loc = page.locator(sel).first
                    if await loc.count() > 0:
                        await loc.click()
                        await page.wait_for_timeout(1500)
                        break
                except: continue

            # Fill email
            for sel in ["input[type='email']", "input[type='text']", "#email-input"]:
                try:
                    loc = page.locator(sel).first
                    if await loc.count() > 0:
                        await loc.fill(email)
                        await loc.dispatch_event("input")
                        break
                except: continue

            # Fill password
            for sel in ["input[type='password']"]:
                try:
                    loc = page.locator(sel).first
                    if await loc.count() > 0:
                        await loc.fill(password)
                        await loc.dispatch_event("input")
                        break
                except: continue

            # Submit login
            for sel in ["button[type='submit']", "text=Log in", "text=Login", ".btn-login"]:
                try:
                    loc = page.locator(sel).first
                    if await loc.count() > 0:
                        await loc.click(force=True)
                        await page.wait_for_timeout(3000)
                        break
                except: continue

            # ── Visit the target link ──
            print(f"  [ACTIVITY] Visiting: {target_url[:60]}")
            await page.goto(target_url, wait_until="domcontentloaded", timeout=30000)
            await page.wait_for_timeout(random.randint(3000, 6000))

            # ── Simulate real behavior ──
            actions = [
                # Scroll down slowly
                lambda: page.evaluate("""
                    () => new Promise(resolve => {
                        let y = 0;
                        const step = () => {
                            window.scrollBy(0, 80);
                            y += 80;
                            if (y < document.body.scrollHeight * 0.7)
                                setTimeout(step, 100 + Math.random()*200);
                            else resolve();
                        };
                        step();
                    })
                """),
                # Random mouse move
                lambda: page.mouse.move(
                    random.randint(200, 1000),
                    random.randint(100, 600)
                ),
                # Wait (reading behavior)
                lambda: page.wait_for_timeout(random.randint(2000, 5000)),
                # Scroll back up
                lambda: page.evaluate("() => window.scrollTo({top:0, behavior:'smooth'})"),
            ]

            for action in random.sample(actions, min(3, len(actions))):
                try:
                    await action()
                    await page.wait_for_timeout(random.randint(500, 1500))
                except: pass

            # Try to play video if present
            try:
                video = page.locator("video, .play-btn, [class*='play']").first
                if await video.count() > 0:
                    await video.click(force=True)
                    print(f"  [ACTIVITY] Video play clicked")
                    await page.wait_for_timeout(random.randint(5000, 15000))
            except: pass

            # ── Take screenshot ──
            os.makedirs("screenshots", exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            ss_path = f"screenshots/activity_{acc_id}_{ts}.png"
            try:
                await page.screenshot(path=ss_path, timeout=30000)
                result["screenshot"] = ss_path
            except: pass

            # Update DB
            update_account_activity(acc_id, ss_path)
            if isinstance(link, dict) and link.get("id"):
                increment_link_visits(link["id"])

            result["success"] = True
            result["message"] = f"Visited {target_url[:50]}"
            print(f"  [ACTIVITY] ✅ Done: {email}")

        except Exception as e:
            result["message"] = str(e)[:100]
            print(f"  [ACTIVITY] ❌ Error for {email}: {e}")
        finally:
            await browser.close()

    return result


async def run_activity_cycle(notify_cb=None) -> dict:
    """
    Run activity for ALL currently active accounts.
    Called every 4-6 hours by scheduler.
    """
    from database import get_active_accounts, get_active_links, expire_old_accounts

    # First expire any accounts past 48h
    expired = expire_old_accounts()
    if expired > 0:
        print(f"[ACTIVITY] {expired} accounts expired (48h done)")

    accounts = get_active_accounts()
    links = get_active_links()

    if not accounts:
        print("[ACTIVITY] No active accounts to simulate")
        return {"active": 0, "success": 0, "failed": 0}

    print(f"[ACTIVITY] Simulating {len(accounts)} accounts...")

    if notify_cb:
        await notify_cb(f"🔄 Simulating activity for {len(accounts)} accounts...")

    stats = {"active": len(accounts), "success": 0, "failed": 0, "screenshots": []}

    # Run with limited concurrency (max 3 at a time)
    semaphore = asyncio.Semaphore(3)

    async def run_one(account):
        async with semaphore:
            # Get proxy if account has one assigned
            proxy = None
            if account.get("proxy_host"):
                from database import get_conn
                conn = get_conn()
                row = conn.execute(
                    "SELECT * FROM proxies WHERE host=? AND used_by_account IS NOT NULL LIMIT 1",
                    (account["proxy_host"],)
                ).fetchone()
                conn.close()
                if row:
                    from bot.proxy_manager import proxy_to_playwright
                    proxy = proxy_to_playwright(dict(row))

            result = await simulate_activity(account, links, proxy)
            if result["success"]:
                stats["success"] += 1
                if result.get("screenshot"):
                    stats["screenshots"].append(result["screenshot"])
            else:
                stats["failed"] += 1

    await asyncio.gather(*[run_one(a) for a in accounts])

    summary = (
        f"🔄 Activity done: {stats['success']}/{stats['active']} accounts active\n"
        f"📊 Failed: {stats['failed']}"
    )
    print(f"[ACTIVITY] {summary}")

    if notify_cb:
        # Send summary + one screenshot (not spam)
        await notify_cb(summary)
        if stats["screenshots"]:
            stats["best_screenshot"] = stats["screenshots"][0]

    return stats
