"""
inspect_otp.py - OTP box exact HTML structure dhundho
"""
import asyncio
from playwright.async_api import async_playwright
import sys, os
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

TEMPMAIL_BASE = "https://key-blossom-hub.lovable.app/api/v1/tempmail"
TEMPMAIL_API_KEY = "ah_99e8274761c84bb49941f18b14c5a21f"

import requests

async def inspect():
    # Create temp email
    r = requests.get(TEMPMAIL_BASE, params={"action": "create", "api_key": TEMPMAIL_API_KEY}, timeout=15)
    mail = r.json()
    email = mail["address"]
    print(f"[*] Email: {email}")

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        ctx = await browser.new_context(
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
            viewport={"width": 1280, "height": 720}
        )
        page = await ctx.new_page()
        await page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined});")

        # Navigate to share page
        await page.goto('https://1024terabox.com/s/1pzrtghbxHWwZ5xr6048k8A', wait_until='domcontentloaded', timeout=30000)
        await page.wait_for_timeout(3000)

        # Login -> Sign up -> Email icon -> Fill email -> Continue
        await page.click('text=Login', timeout=5000)
        await page.wait_for_timeout(2000)
        await page.click('text=Sign up', timeout=5000)
        await page.wait_for_timeout(1500)
        await page.mouse.click(630, 401)
        await page.wait_for_timeout(2000)

        # Fill email
        await page.fill("input[placeholder*='email' i]", email, timeout=5000)
        await page.wait_for_timeout(500)
        await page.click("text=Continue", timeout=5000)
        print(f"[*] Continue clicked! Waiting for OTP form...")
        await page.wait_for_timeout(4000)

        # Now inspect the OTP form
        await page.screenshot(path="inspect_otp_form.png")

        # Get ALL inputs
        all_inputs = await page.evaluate("""
            () => {
                const inputs = document.querySelectorAll('input');
                return Array.from(inputs).map(inp => ({
                    type: inp.type,
                    name: inp.name,
                    id: inp.id,
                    className: inp.className,
                    placeholder: inp.placeholder,
                    maxLength: inp.maxLength,
                    value: inp.value,
                    outerHTML: inp.outerHTML.substring(0, 200)
                }));
            }
        """)
        print(f"\n=== ALL INPUTS ({len(all_inputs)}) ===")
        for inp in all_inputs:
            print(f"  type='{inp['type']}' name='{inp['name']}' maxlen={inp['maxLength']} class='{inp['className'][:60]}' placeholder='{inp['placeholder']}'")
            print(f"    HTML: {inp['outerHTML'][:150]}")

        # Get the OTP box container HTML
        otp_container = await page.evaluate("""
            () => {
                // Find the verification code section
                const headings = document.querySelectorAll('*');
                for (const el of headings) {
                    if (el.innerText && el.innerText.includes('verification code') && el.children.length < 5) {
                        return el.parentElement ? el.parentElement.outerHTML.substring(0, 3000) : el.outerHTML.substring(0, 3000);
                    }
                }
                return 'Not found';
            }
        """)
        print(f"\n=== OTP SECTION HTML ===")
        print(otp_container[:3000])

        # Also look for div-based OTP boxes
        div_boxes = await page.evaluate("""
            () => {
                const allDivs = document.querySelectorAll('div[class*="code"], div[class*="otp"], div[class*="verify"], div[class*="input"]');
                return Array.from(allDivs).map(d => ({
                    className: d.className,
                    text: d.innerText.substring(0, 30),
                    html: d.outerHTML.substring(0, 200)
                }));
            }
        """)
        print(f"\n=== DIV-BASED CODE BOXES ({len(div_boxes)}) ===")
        for d in div_boxes:
            print(f"  class='{d['className'][:60]}' text='{d['text']}' => {d['html'][:150]}")

        print("\n[*] Inspect done - check inspect_otp_form.png")
        await page.wait_for_timeout(3000)
        await browser.close()

asyncio.run(inspect())
