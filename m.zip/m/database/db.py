import json
import os
import asyncio
from datetime import datetime
from config import settings

# Lock to prevent race conditions during file write
db_lock = asyncio.Lock()

def _load_data_sync() -> dict:
    if not os.path.exists(settings.JSON_DB_PATH):
        # Initialize default structure
        default_data = {"users": {}, "orders": []}
        with open(settings.JSON_DB_PATH, "w", encoding="utf-8") as f:
            json.dump(default_data, f, indent=4)
        return default_data
    
    try:
        with open(settings.JSON_DB_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        # If corrupted, reset
        default_data = {"users": {}, "orders": []}
        with open(settings.JSON_DB_PATH, "w", encoding="utf-8") as f:
            json.dump(default_data, f, indent=4)
        return default_data

def _save_data_sync(data: dict):
    with open(settings.JSON_DB_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

async def init_db():
    async with db_lock:
        # Runs the sync check inside the executor or directly since it is small
        _load_data_sync()

async def get_user(tg_id: int) -> dict | None:
    async with db_lock:
        data = _load_data_sync()
        user_key = str(tg_id)
        if user_key in data["users"]:
            return data["users"][user_key]
        return None

async def save_user(tg_id: int, username: str | None, cookies_json: str, logged_in: int = 1) -> dict:
    async with db_lock:
        data = _load_data_sync()
        user_key = str(tg_id)
        
        user_data = {
            "tg_id": tg_id,
            "username": username,
            "cookies_json": cookies_json,
            "logged_in": logged_in,
            "joined_at": data["users"].get(user_key, {}).get("joined_at", datetime.now().isoformat()),
            "saved_target_username": data["users"].get(user_key, {}).get("saved_target_username")
        }
        
        data["users"][user_key] = user_data
        _save_data_sync(data)
        return user_data

async def save_target_username(tg_id: int, target_username: str) -> bool:
    async with db_lock:
        data = _load_data_sync()
        user_key = str(tg_id)
        if user_key in data["users"]:
            data["users"][user_key]["saved_target_username"] = target_username
            _save_data_sync(data)
            return True
        return False

async def logout_user(tg_id: int) -> bool:
    async with db_lock:
        data = _load_data_sync()
        user_key = str(tg_id)
        if user_key in data["users"]:
            data["users"][user_key]["cookies_json"] = ""
            data["users"][user_key]["logged_in"] = 0
            _save_data_sync(data)
            return True
        return False

async def log_order(tg_id: int, api_order_id: str, product_name: str, price: float, status: str) -> dict:
    async with db_lock:
        data = _load_data_sync()
        order_data = {
            "order_id": len(data["orders"]) + 1,
            "tg_id": tg_id,
            "api_order_id": api_order_id,
            "product_name": product_name,
            "price": price,
            "status": status,
            "created_at": datetime.now().isoformat()
        }
        data["orders"].append(order_data)
        _save_data_sync(data)
        return order_data
