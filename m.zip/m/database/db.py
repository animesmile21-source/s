"""
Unified Database Layer
Handles: users, proxies, accounts, access_keys, orders, rate_limiting
"""
import json
import os
import asyncio
import secrets
import string
from datetime import datetime, timezone
from config import settings

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data.json")
db_lock = asyncio.Lock()

# ─────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────
def _default_data() -> dict:
    return {
        "proxies": {},
        "accounts": {},
        "access_keys": {},
        "users": {},
        "orders": [],
        "rate_limits": {}
    }

def _load() -> dict:
    if not os.path.exists(DB_PATH):
        data = _default_data()
        with open(DB_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return data
    try:
        with open(DB_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Ensure all top-level keys exist (migration safety)
        for key in _default_data():
            if key not in data:
                data[key] = _default_data()[key]
        return data
    except json.JSONDecodeError:
        data = _default_data()
        with open(DB_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return data

def _save(data: dict):
    with open(DB_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def _now_ts() -> int:
    return int(datetime.now(timezone.utc).timestamp())

# ─────────────────────────────────────────────────────────
# DB init
# ─────────────────────────────────────────────────────────
async def init_db():
    async with db_lock:
        _load()

# ─────────────────────────────────────────────────────────
# Proxy operations
# ─────────────────────────────────────────────────────────
async def add_proxy(host: str, port: str, username: str, password: str,
                    protocol: str = "http", label: str = "") -> dict:
    async with db_lock:
        data = _load()
        # Generate unique proxy ID
        pid = f"proxy_{secrets.token_hex(4)}"
        url = f"{protocol}://{username}:{password}@{host}:{port}"
        proxy = {
            "id": pid,
            "label": label or f"{host}:{port}",
            "host": host,
            "port": port,
            "username": username,
            "password": password,
            "protocol": protocol,
            "url": url,
            "active": True,
            "account_slots": [],       # max 2 account IDs
            "added_at": _now_iso()
        }
        data["proxies"][pid] = proxy
        _save(data)
        return proxy

async def get_proxy(proxy_id: str) -> dict | None:
    async with db_lock:
        data = _load()
        return data["proxies"].get(proxy_id)

async def list_proxies() -> list:
    async with db_lock:
        data = _load()
        return list(data["proxies"].values())

async def remove_proxy(proxy_id: str) -> bool:
    async with db_lock:
        data = _load()
        if proxy_id in data["proxies"]:
            del data["proxies"][proxy_id]
            _save(data)
            return True
        return False

async def toggle_proxy(proxy_id: str) -> bool | None:
    async with db_lock:
        data = _load()
        if proxy_id in data["proxies"]:
            data["proxies"][proxy_id]["active"] = not data["proxies"][proxy_id]["active"]
            _save(data)
            return data["proxies"][proxy_id]["active"]
        return None

async def get_available_proxy() -> dict | None:
    """Return first active proxy with fewer than 2 accounts."""
    async with db_lock:
        data = _load()
        for p in data["proxies"].values():
            if p.get("active") and len(p.get("account_slots", [])) < 2:
                return p
        return None

# ─────────────────────────────────────────────────────────
# Account operations
# ─────────────────────────────────────────────────────────
async def add_account(proxy_id: str, email: str, cookies_json: str,
                      access_token_exp: int = 0) -> dict | None:
    async with db_lock:
        data = _load()
        if proxy_id not in data["proxies"]:
            return None
        proxy = data["proxies"][proxy_id]

        # Re-sync account_slots: remove any stale IDs that no longer exist in accounts
        valid_slots = [aid for aid in proxy["account_slots"] if aid in data["accounts"]]
        data["proxies"][proxy_id]["account_slots"] = valid_slots
        proxy = data["proxies"][proxy_id]

        if len(valid_slots) >= 2:
            return None   # proxy is full

        # Assign slot number: find which of 1/2 is free
        used_slots = {data["accounts"][aid]["slot"] for aid in valid_slots if aid in data["accounts"]}
        slot = 1 if 1 not in used_slots else 2

        aid = f"acc_{secrets.token_hex(4)}"
        account = {
            "id": aid,
            "email": email,
            "proxy_id": proxy_id,
            "cookies_json": cookies_json,
            "access_token_exp": access_token_exp,
            "cookie_added_at": _now_ts(),
            "slot": slot,
            "added_at": _now_iso(),
            "last_refreshed": _now_iso()
        }
        data["accounts"][aid] = account
        data["proxies"][proxy_id]["account_slots"].append(aid)
        _save(data)
        return account

async def refresh_account_cookies(account_id: str, cookies_json: str,
                                   access_token_exp: int = 0, email: str = "") -> bool:
    async with db_lock:
        data = _load()
        if account_id not in data["accounts"]:
            return False
        data["accounts"][account_id]["cookies_json"] = cookies_json
        data["accounts"][account_id]["last_refreshed"] = _now_iso()
        data["accounts"][account_id]["cookie_added_at"] = _now_ts()  # Reset timer on each refresh
        data["accounts"][account_id]["access_token_exp"] = access_token_exp
        if email:
            data["accounts"][account_id]["email"] = email
        _save(data)
        return True

async def get_account(account_id: str) -> dict | None:
    async with db_lock:
        data = _load()
        return data["accounts"].get(account_id)

async def list_accounts(proxy_id: str = None) -> list:
    async with db_lock:
        data = _load()
        accs = list(data["accounts"].values())
        if proxy_id:
            accs = [a for a in accs if a.get("proxy_id") == proxy_id]
        return accs

async def remove_account(account_id: str) -> bool:
    async with db_lock:
        data = _load()
        if account_id not in data["accounts"]:
            return False
        proxy_id = data["accounts"][account_id].get("proxy_id")
        del data["accounts"][account_id]
        if proxy_id and proxy_id in data["proxies"]:
            slots = data["proxies"][proxy_id]["account_slots"]
            if account_id in slots:
                slots.remove(account_id)
        _save(data)
        return True

async def get_accounts_for_proxy(proxy_id: str) -> list:
    async with db_lock:
        data = _load()
        proxy = data["proxies"].get(proxy_id, {})
        slots = proxy.get("account_slots", [])
        return [data["accounts"][aid] for aid in slots if aid in data["accounts"]]

async def list_all_accounts() -> list:
    async with db_lock:
        data = _load()
        return list(data["accounts"].values())

# ─────────────────────────────────────────────────────────
# Access Key operations
# ─────────────────────────────────────────────────────────
def _generate_key_string() -> str:
    chars = string.ascii_uppercase + string.digits
    return "KEY-" + "".join(secrets.choice(chars) for _ in range(4)) + "-" + \
           "".join(secrets.choice(chars) for _ in range(4)) + "-" + \
           "".join(secrets.choice(chars) for _ in range(4))

async def generate_access_key(proxy_id: str, duration_days: int = 0,
                               note: str = "") -> dict:
    """duration_days=0 means lifetime."""
    async with db_lock:
        data = _load()
        key_str = _generate_key_string()
        # ensure uniqueness
        while key_str in data["access_keys"]:
            key_str = _generate_key_string()

        expires_at = None
        if duration_days > 0:
            from datetime import timedelta
            expires_at = (datetime.now(timezone.utc) + timedelta(days=duration_days)).isoformat()

        key_obj = {
            "key": key_str,
            "proxy_id": proxy_id,
            "note": note,
            "duration_days": duration_days,
            "created_at": _now_iso(),
            "expires_at": expires_at,
            "used_by_tg_id": None,
            "used_at": None,
            "active": True
        }
        data["access_keys"][key_str] = key_obj
        _save(data)
        return key_obj

async def validate_access_key(key_str: str) -> dict | None:
    """Returns key obj if valid and unused, else None."""
    async with db_lock:
        data = _load()
        key = data["access_keys"].get(key_str)
        if not key:
            return None
        if not key.get("active"):
            return None
        if key.get("used_by_tg_id"):
            return None  # already claimed
        # Check expiry
        if key.get("expires_at"):
            exp = datetime.fromisoformat(key["expires_at"])
            if datetime.now(timezone.utc) > exp:
                return None
        return key

async def claim_access_key(key_str: str, tg_id: int) -> bool:
    async with db_lock:
        data = _load()
        key = data["access_keys"].get(key_str)
        if not key or not key.get("active") or key.get("used_by_tg_id"):
            return False
        key["used_by_tg_id"] = tg_id
        key["used_at"] = _now_iso()
        _save(data)
        return True

async def revoke_access_key(key_str: str) -> bool:
    async with db_lock:
        data = _load()
        if key_str in data["access_keys"]:
            data["access_keys"][key_str]["active"] = False
            _save(data)
            return True
        return False

async def list_access_keys() -> list:
    async with db_lock:
        data = _load()
        return list(data["access_keys"].values())

# ─────────────────────────────────────────────────────────
# User operations
# ─────────────────────────────────────────────────────────
async def save_user(tg_id: int, username: str | None,
                    access_key: str = "", proxy_id: str = "",
                    active: bool = True) -> dict:
    async with db_lock:
        data = _load()
        uid = str(tg_id)
        existing = data["users"].get(uid, {})
        user_obj = {
            "tg_id": tg_id,
            "username": username,
            "access_key": access_key or existing.get("access_key", ""),
            "proxy_id": proxy_id or existing.get("proxy_id", ""),
            "joined_at": existing.get("joined_at", _now_iso()),
            "active": active,
            # Custom cookies per slot (user can update their own 2 slots)
            "custom_cookies": existing.get("custom_cookies", {
                "slot1": None,
                "slot2": None
            }),
            "custom_emails": existing.get("custom_emails", {
                "slot1": None,
                "slot2": None
            })
        }
        data["users"][uid] = user_obj
        _save(data)
        return user_obj

async def get_user(tg_id: int) -> dict | None:
    async with db_lock:
        data = _load()
        return data["users"].get(str(tg_id))

async def list_users() -> list:
    async with db_lock:
        data = _load()
        return list(data["users"].values())

async def block_user(tg_id: int) -> bool:
    async with db_lock:
        data = _load()
        uid = str(tg_id)
        if uid in data["users"]:
            data["users"][uid]["active"] = False
            _save(data)
            return True
        return False

async def unblock_user(tg_id: int) -> bool:
    async with db_lock:
        data = _load()
        uid = str(tg_id)
        if uid in data["users"]:
            data["users"][uid]["active"] = True
            _save(data)
            return True
        return False

async def update_user_custom_cookies(tg_id: int, slot: int,
                                      cookies_json: str, email: str = "") -> bool:
    """User can override cookies for slot 1 or 2 on their assigned proxy."""
    async with db_lock:
        data = _load()
        uid = str(tg_id)
        if uid not in data["users"]:
            return False
        slot_key = f"slot{slot}"
        data["users"][uid]["custom_cookies"][slot_key] = cookies_json
        if email:
            data["users"][uid]["custom_emails"][slot_key] = email
        _save(data)
        return True

async def save_target_username(tg_id: int, target: str) -> bool:
    async with db_lock:
        data = _load()
        uid = str(tg_id)
        if uid in data["users"]:
            data["users"][uid]["saved_target_username"] = target
            _save(data)
            return True
        return False

# ─────────────────────────────────────────────────────────
# Rate Limiting (10 CC per 2hr per user, 5 per account slot)
# Owner (OWNER_ID) has NO rate limits.
# ─────────────────────────────────────────────────────────
COOLDOWN_SECS = 2 * 3600   # 2 hours
MAX_CHECKS_TOTAL = 10
MAX_CHECKS_PER_SLOT = 5

async def get_rate_limit(tg_id: int) -> dict:
    async with db_lock:
        data = _load()
        uid = str(tg_id)
        rl = data["rate_limits"].get(uid, {
            "window_start": 0,
            "slot1_used": 0,
            "slot2_used": 0,
            "total_used": 0
        })
        now = _now_ts()
        # Reset if window expired
        if now - rl.get("window_start", 0) >= COOLDOWN_SECS:
            rl = {"window_start": now, "slot1_used": 0, "slot2_used": 0, "total_used": 0}
            data["rate_limits"][uid] = rl
            _save(data)
        return rl

async def can_check_cc(tg_id: int) -> tuple[bool, int, str]:
    """
    Returns (allowed, cooldown_remaining_secs, which_slot)
    slot = "slot1" or "slot2"
    Owner always gets slot1 with no restrictions.
    """
    # Owner has unlimited CC checks — no rate limit
    if tg_id == settings.OWNER_ID:
        return True, 0, "slot1"

    rl = await get_rate_limit(tg_id)
    now = _now_ts()
    total = rl.get("total_used", 0)

    if total >= MAX_CHECKS_TOTAL:
        window_start = rl.get("window_start", now)
        remaining = COOLDOWN_SECS - (now - window_start)
        return False, max(0, remaining), ""

    # Decide which slot to use
    slot1 = rl.get("slot1_used", 0)
    slot2 = rl.get("slot2_used", 0)
    if slot1 < MAX_CHECKS_PER_SLOT:
        return True, 0, "slot1"
    elif slot2 < MAX_CHECKS_PER_SLOT:
        return True, 0, "slot2"
    else:
        window_start = rl.get("window_start", now)
        remaining = COOLDOWN_SECS - (now - window_start)
        return False, max(0, remaining), ""

async def increment_cc_check(tg_id: int, slot: str):
    # Owner checks are never counted against any limit
    if tg_id == settings.OWNER_ID:
        return

    async with db_lock:
        data = _load()
        uid = str(tg_id)
        now = _now_ts()
        rl = data["rate_limits"].get(uid, {
            "window_start": now, "slot1_used": 0, "slot2_used": 0, "total_used": 0
        })
        if now - rl.get("window_start", 0) >= COOLDOWN_SECS:
            rl = {"window_start": now, "slot1_used": 0, "slot2_used": 0, "total_used": 0}

        slot_key = f"{slot}_used"
        rl[slot_key] = rl.get(slot_key, 0) + 1
        rl["total_used"] = rl.get("total_used", 0) + 1
        data["rate_limits"][uid] = rl
        _save(data)


# ─────────────────────────────────────────────────────────
# Per-Account Check Tracking (Owner circular rotation)
# Each owner account allows 5 checks per 2h window.
# When full → rotate to next account → wrap around circularly.
# ─────────────────────────────────────────────────────────
ACCOUNT_MAX_CHECKS = 5
ACCOUNT_COOLDOWN_SECS = 2 * 3600

async def get_account_used_checks(account_id: str) -> int:
    """Returns number of checks used on this account in current 2h window."""
    async with db_lock:
        data = _load()
        rl = data.get("account_checks", {}).get(account_id, {})
        now = _now_ts()
        if now - rl.get("window_start", 0) >= ACCOUNT_COOLDOWN_SECS:
            return 0   # Window expired, reset
        return rl.get("used", 0)

async def increment_account_check(account_id: str):
    """Increments check count for this account in the 2h window."""
    async with db_lock:
        data = _load()
        if "account_checks" not in data:
            data["account_checks"] = {}
        rl = data["account_checks"].get(account_id, {})
        now = _now_ts()
        if now - rl.get("window_start", 0) >= ACCOUNT_COOLDOWN_SECS:
            rl = {"window_start": now, "used": 0}
        rl["used"] = rl.get("used", 0) + 1
        data["account_checks"][account_id] = rl
        _save(data)

# ─────────────────────────────────────────────────────────
# Orders
# ─────────────────────────────────────────────────────────
async def log_order(tg_id: int, api_order_id: str, product_name: str,
                    price: float, status: str,
                    card_last4: str = "", proxy_id: str = "") -> dict:
    async with db_lock:
        data = _load()
        order = {
            "id": len(data["orders"]) + 1,
            "tg_id": tg_id,
            "api_order_id": api_order_id,
            "product_name": product_name,
            "price": price,
            "status": status,
            "card_last4": card_last4,
            "proxy_id": proxy_id,
            "created_at": _now_iso()
        }
        data["orders"].append(order)
        _save(data)
        return order

async def list_orders(tg_id: int = None) -> list:
    async with db_lock:
        data = _load()
        orders = data.get("orders", [])
        if tg_id:
            orders = [o for o in orders if o.get("tg_id") == tg_id]
        return orders

# ─────────────────────────────────────────────────────────
# Helpers for cookie monitor (kept for backward compat)
# ─────────────────────────────────────────────────────────
def _load_data_sync() -> dict:
    return _load()


# ─────────────────────────────────────────────────────────
# Account-level Rate Limiting
# ─────────────────────────────────────────────────────────
async def can_check_account(account_id: str) -> bool:
    """Returns True if the account has checked fewer than 5 cards in the current 2-hour window."""
    async with db_lock:
        data = _load()
        now = _now_ts()
        if "account_rate_limits" not in data:
            data["account_rate_limits"] = {}
        
        limit_data = data["account_rate_limits"].get(account_id, {
            "window_start": 0,
            "used": 0
        })
        
        # Reset window if expired
        if now - limit_data.get("window_start", 0) >= COOLDOWN_SECS:
            limit_data = {"window_start": now, "used": 0}
            data["account_rate_limits"][account_id] = limit_data
            _save(data)
            
        return limit_data.get("used", 0) < MAX_CHECKS_PER_SLOT


async def increment_account_check(account_id: str):
    async with db_lock:
        data = _load()
        now = _now_ts()
        if "account_rate_limits" not in data:
            data["account_rate_limits"] = {}
            
        limit_data = data["account_rate_limits"].get(account_id, {
            "window_start": now, "used": 0
        })
        
        # Reset if window expired
        if now - limit_data.get("window_start", 0) >= COOLDOWN_SECS:
            limit_data = {"window_start": now, "used": 0}
            
        limit_data["used"] = limit_data.get("used", 0) + 1
        data["account_rate_limits"][account_id] = limit_data
        _save(data)


async def get_account_used_checks(account_id: str) -> int:
    """Returns the number of used card checks for the account in the current 2-hour window."""
    async with db_lock:
        data = _load()
        now = _now_ts()
        if "account_rate_limits" not in data:
            return 0
        limit_data = data["account_rate_limits"].get(account_id, {})
        # Reset if window expired
        if now - limit_data.get("window_start", 0) >= COOLDOWN_SECS:
            return 0
        return limit_data.get("used", 0)


