from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.fsm.context import FSMContext
from database import db
from services.u47_api import U7BuyApiClient
from keyboards.inline import (
    get_categories_keyboard,
    get_products_keyboard,
    get_confirmation_keyboard,
    get_use_saved_username_keyboard
)
from states.states import OrderStates
import re
import io

def parse_one_line_card(text: str) -> dict | None:
    # Split by |, /, space, or dash
    parts = re.split(r'[\|\/\s\-]+', text.strip())
    parts = [p.strip() for p in parts if p.strip()]
    
    if len(parts) == 4:
        card_num = parts[0]
        month = parts[1]
        year = parts[2]
        cvv = parts[3]
        
        # Basic digit validations
        if not re.fullmatch(r'\d{13,19}', card_num):
            return None
        if not re.fullmatch(r'\d{1,2}', month):
            return None
        if not re.fullmatch(r'\d{2}|\d{4}', year):
            return None
        if not re.fullmatch(r'\d{3,4}', cvv):
            return None
            
        return {
            "card_number": card_num,
            "exp_month": month.zfill(2),
            "exp_year": year[-2:], # 2-digit year
            "card_cvc": cvv
        }
    return None

router = Router()

# ────────────────────────────────────────────────
# Browse Products Entry
# ────────────────────────────────────────────────
@router.message(F.text == "🛍️ Browse Products")
async def browse_products_handler(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "🏷️ **Select Product Category:**\n\n"
        "Niche diye gaye options me se category choose karein:",
        reply_markup=get_categories_keyboard(),
        parse_mode="Markdown"
    )

@router.callback_query(F.data == "back_to_categories")
async def back_to_categories_handler(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text(
        "🏷️ **Select Product Category:**\n\n"
        "Niche diye gaye options me se category choose karein:",
        reply_markup=get_categories_keyboard(),
        parse_mode="Markdown"
    )
    await callback.answer()

# ────────────────────────────────────────────────
# Category Selection → Load Products
# ────────────────────────────────────────────────
@router.callback_query(F.data.startswith("cat_"))
async def process_category(callback: CallbackQuery, state: FSMContext):
    category = callback.data.split("_", 1)[1]
    user_record = await db.get_user(callback.from_user.id)

    if not user_record or not user_record.get("logged_in") or not user_record.get("cookies_json"):
        await callback.answer("🔒 Please login first using /login!", show_alert=True)
        return

    await callback.message.edit_text("⏳ **Fetching prices from U7BUY...**", parse_mode="Markdown")

    client = U7BuyApiClient(user_record["cookies_json"])

    if category == "google_play":
        products = await client.get_google_play_products()
        if not products:
            await callback.message.edit_text(
                "❌ Product list fetch nahi ho saki.\n"
                "Aapki cookies expire ho chuki hain. Please `/login` se refresh karein."
            )
            return
        await state.update_data(products_list=products, category="google_play")
        await callback.message.edit_text(
            "🎮 **Select Google Play Card (India):**",
            reply_markup=get_products_keyboard(products, "google_play"),
            parse_mode="Markdown"
        )

    elif category == "telegram_stars":
        products = await client.get_telegram_stars_products()
        if not products:
            await callback.message.edit_text(
                "❌ Stars packages fetch nahi ho sake.\n"
                "Aapki cookies expire ho chuki hain. Please `/login` se refresh karein."
            )
            return
        await state.update_data(products_list=products, category="telegram_stars")
        await callback.message.edit_text(
            "⭐ **Select Telegram Stars / Premium Package:**",
            reply_markup=get_products_keyboard(products, "telegram_stars"),
            parse_mode="Markdown"
        )
    else:
        await callback.message.edit_text("❌ Unknown category. Please try again.")
    await callback.answer()

# ────────────────────────────────────────────────
# Google Play Product Selected
# ────────────────────────────────────────────────
@router.callback_query(F.data.startswith("buy_gp_"))
async def process_gp_selection(callback: CallbackQuery, state: FSMContext):
    product_id = callback.data.replace("buy_gp_", "")
    state_data = await state.get_data()
    products_list = state_data.get("products_list", [])

    selected_prod = next((p for p in products_list if str(p.get("skuId")) == product_id), None)
    if not selected_prod:
        await callback.answer("Product not found. Please refresh list.", show_alert=True)
        return

    sku_name = selected_prod.get("skuName", "Google Play Card")
    price = selected_prod.get("skuPrice", "N/A")
    sku_url = selected_prod.get("skuUrl", "")

    await state.update_data(
        selected_product_id=product_id,
        selected_product_name=sku_name,
        selected_product_price=price,
        selected_sku_url=sku_url,
        purchase_type="google_play",
        target_username=None
    )

    # Show order summary then ask for cards
    await callback.message.edit_text(
        f"🛒 **Order Details:**\n\n"
        f"📦 **Product:** {sku_name}\n"
        f"💵 **Price:** ₹{price}\n"
        f"⚙️ **Delivery:** Instant (Redeem Key)\n\n"
        f"💳 **Card Details Required**\n"
        f"Ek ya zyada cards bhejein, **ek line me ek card** (format):\n"
        f"`NUMBER|MM|YY|CVV|NAME`\n"
        f"e.g. `4111111111111111|12|28|123|JOHN DOE`\n\n"
        f"Multiple cards ke liye:\n"
        f"`4111111111111111|12|28|123|JOHN DOE`\n"
        f"`5500005555555559|06|27|321|JANE SMITH`",
        parse_mode="Markdown"
    )
    await state.set_state(OrderStates.waiting_for_card_number)
    await callback.answer()

# ────────────────────────────────────────────────
# Telegram Stars Product Selected
# ────────────────────────────────────────────────
@router.callback_query(F.data.startswith("buy_ts_"))
async def process_ts_selection(callback: CallbackQuery, state: FSMContext):
    product_id = callback.data.replace("buy_ts_", "")
    state_data = await state.get_data()
    products_list = state_data.get("products_list", [])

    selected_prod = next((p for p in products_list if str(p.get("skuId")) == product_id), None)
    if not selected_prod:
        await callback.answer("Product not found. Please refresh list.", show_alert=True)
        return

    sku_name = selected_prod.get("skuName", "Stars/Premium")
    price = selected_prod.get("skuPrice", "N/A")

    await state.update_data(
        selected_product_id=product_id,
        selected_offer_id=selected_prod.get("offerId", product_id),  # offerId = productId for save/cashier/info
        selected_product_name=sku_name,
        selected_product_price=price,
        selected_sku_url="telegram-stars",
        purchase_type="telegram_stars"
    )

    # Check for saved target username in DB
    user_record = await db.get_user(callback.from_user.id)
    saved_target = user_record.get("saved_target_username") if user_record else None
    
    keyboard = None
    if saved_target:
        keyboard = get_use_saved_username_keyboard(saved_target)

    await callback.message.edit_text(
        f"⭐ **{sku_name} - ₹{price}**\n\n"
        f"👤 Pehle **Telegram Username ya ID** bhejein\n"
        f"(Jis account me top-up karna hai, e.g. `@username` ya `123456789`):",
        reply_markup=keyboard,
        parse_mode="Markdown"
    )
    await state.set_state(OrderStates.waiting_for_username)
    await callback.answer()

# ────────────────────────────────────────────────
# Saved Username Callbacks
# ────────────────────────────────────────────────
@router.callback_query(F.data.startswith("use_saved_tg_"))
async def process_use_saved_username(callback: CallbackQuery, state: FSMContext):
    username = callback.data.replace("use_saved_tg_", "")
    state_data = await state.get_data()
    sku_name = state_data.get("selected_product_name")
    price = state_data.get("selected_product_price")

    await state.update_data(target_username=username)

    await callback.message.edit_text(
        f"✅ Target (Saved): **{username}**\n\n"
        f"📦 **{sku_name} - ₹{price}**\n\n"
        f"💳 **Card Details Required**\n"
        f"Ek ya zyada cards bhejein, **ek line me ek card** (format):\n"
        f"`NUMBER|MM|YY|CVV|NAME`\n"
        f"e.g. `4111111111111111|12|28|123|JOHN DOE`\n\n"
        f"Multiple cards ke liye har card naye line par:\n"
        f"`4111111111111111|12|28|123|JOHN DOE`\n"
        f"`5500005555555559|06|27|321|JANE SMITH`",
        parse_mode="Markdown"
    )
    await state.set_state(OrderStates.waiting_for_card_number)
    await callback.answer()

@router.callback_query(F.data == "cancel_saved_tg")
async def process_cancel_saved_username(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text(
        "👤 Pehle **Telegram Username ya ID** bhejein\n"
        "(Jis account me top-up karna hai, e.g. `@username` ya `123456789`):",
        parse_mode="Markdown"
    )
    await callback.answer()

# ────────────────────────────────────────────────
# Telegram Stars: TG Username → Then Card
# ────────────────────────────────────────────────
@router.message(OrderStates.waiting_for_username)
async def process_stars_username(message: Message, state: FSMContext):
    username = message.text.strip()
    if not username.startswith("@") and not username.lstrip("-").isdigit():
        username = "@" + username

    await state.update_data(target_username=username)
    state_data = await state.get_data()
    sku_name = state_data.get("selected_product_name")
    price = state_data.get("selected_product_price")

    # Validate TG account with U7BUY before proceeding
    user_record = await db.get_user(message.from_user.id)
    if user_record and user_record.get("cookies_json"):
        checking_msg = await message.answer("🔍 Telegram account validate kar raha hun...")
        client = U7BuyApiClient(user_record["cookies_json"])
        check_result = await client.check_account(username)
        try:
            await checking_msg.delete()
        except Exception:
            pass
        if not check_result.get("valid"):
            raw_err = check_result.get('message', 'Invalid Telegram account')
            safe_err = str(raw_err).replace("[", "(").replace("]", ")").replace("_", " ").replace("*", "")
            await message.answer(
                f"❌ **Invalid Telegram Account**\n\n"
                f"Username `{username}` U7BUY par validate nahi hua.\n"
                f"Reason: {safe_err}\n\n"
                f"Sahi username enter karein:",
                parse_mode="Markdown"
            )
            return
        
        # Save validated username to DB for future quick usage
        await db.save_target_username(message.from_user.id, username)

    # Delete user message for privacy
    try:
        await message.delete()
    except Exception:
        pass

    await message.answer(
        f"✅ Target: **{username}**\n\n"
        f"📦 **{sku_name} - ₹{price}**\n\n"
        f"💳 **Card Details Required (Batch Accepted)**\n"
        f"Format: `NUMBER|MM|YY|CVV|NAME` (ek line me ek card)\n"
        f"e.g. `4111111111111111|12|28|123|JOHN DOE`",
        parse_mode="Markdown"
    )
    await state.set_state(OrderStates.waiting_for_card_number)

# ────────────────────────────────────────────────
# Card Number / Multi-card Batch Input
# ────────────────────────────────────────────────
@router.message(OrderStates.waiting_for_card_number)
async def process_card_number(message: Message, state: FSMContext):
    text = message.text.strip()

    # Delete user message for security
    try:
        await message.delete()
    except Exception:
        pass

    lines = [l.strip() for l in text.splitlines() if l.strip()]

    # ── Multi-card batch: detect if ANY line has 5 fields (NUMBER|MM|YY|CVV|NAME) ──
    def parse_five_field(line: str) -> dict | None:
        parts = re.split(r'[\|\,]+', line.strip())
        parts = [p.strip() for p in parts if p.strip()]
        if len(parts) >= 5:
            card_num = parts[0].replace(" ", "").replace("-", "")
            if not re.fullmatch(r'\d{13,19}', card_num):
                return None
            if not re.fullmatch(r'\d{1,2}', parts[1]):
                return None
            year = parts[2]
            if not re.fullmatch(r'\d{2,4}', year):
                return None
            if len(year) == 4:
                year = year[2:]
            cvc = parts[3]
            if not re.fullmatch(r'\d{3,4}', cvc):
                return None
            name = ' '.join(parts[4:]).upper().strip()
            if not name:
                return None
            return {
                "card_number": card_num,
                "exp_month": parts[1].zfill(2),
                "exp_year": year,
                "card_cvc": cvc,
                "card_holder_name": name
            }
        return None

    # Try to parse all lines as 5-field cards
    if len(lines) >= 1:
        parsed_cards = [parse_five_field(l) for l in lines]
        valid_cards = [c for c in parsed_cards if c is not None]

        if valid_cards:
            # ── MULTI-CARD BATCH PATH ──
            if len(valid_cards) == 1:
                c = valid_cards[0]
                masked = f"**** **** **** {c['card_number'][-4:]}"
                await message.answer(
                    f"✅ **1 Card Parsed:**\n"
                    f"Card: `{masked}`  Expiry: `{c['exp_month']}/{c['exp_year']}`  Name: `{c['card_holder_name']}`\n\n"
                    f"⚠️ Confirm karke payment process hoga.",
                    reply_markup=get_confirmation_keyboard(),
                    parse_mode="Markdown"
                )
            else:
                preview_lines = []
                for i, c in enumerate(valid_cards, 1):
                    preview_lines.append(f"{i}. `**** **** **** {c['card_number'][-4:]}` | `{c['exp_month']}/{c['exp_year']}` | `{c['card_holder_name']}`")
                preview = '\n'.join(preview_lines)
                await message.answer(
                    f"✅ **{len(valid_cards)} Cards Parsed:**\n\n"
                    f"{preview}\n\n"
                    f"Bot inhe **ek ek karke try karega** jab tak payment succeed na ho jaye.\n\n"
                    f"⚠️ Confirm karke payment process hoga.",
                    reply_markup=get_confirmation_keyboard(),
                    parse_mode="Markdown"
                )
            await state.update_data(cards_batch=valid_cards)
            await state.set_state(OrderStates.confirm_purchase)
            return

    # ── SINGLE CARD LEGACY PATH (NUMBER|MM|YY|CVV — 4 fields) ──
    card_info = parse_one_line_card(text)
    if card_info:
        await state.update_data(
            card_number=card_info["card_number"],
            exp_month=card_info["exp_month"],
            exp_year=card_info["exp_year"],
            card_cvc=card_info["card_cvc"]
        )
        await message.answer(
            f"✅ **Card Details Parsed:**\n"
            f"Card: `**** **** **** {card_info['card_number'][-4:]}`\n"
            f"Expiry: `{card_info['exp_month']}/{card_info['exp_year']}`\n\n"
            f"👤 Ab **Cardholder Name** bhejein\n"
            f"(Wahi naam jo card ke upar likha hai, e.g. `SHIV KUMAR`):",
            parse_mode="Markdown"
        )
        await state.set_state(OrderStates.waiting_for_card_name)
        return

    # Fallback to single card number input
    card_raw = text.replace(" ", "").replace("-", "")
    if not re.fullmatch(r"\d{13,19}", card_raw):
        await message.answer(
            "❌ Invalid format. Please enter either 13–19 digit card number or one-line format:\n"
            "`NUMBER|MM|YY|CVV`"
        )
        return

    await state.update_data(card_number=card_raw)
    await message.answer(
        "✅ Card number saved.\n\n"
        "📅 Ab apni **Expiry Date** bhejein\n"
        "Format: `MM/YY` (e.g. `01/27`):",
        parse_mode="Markdown"
    )
    await state.set_state(OrderStates.waiting_for_card_expiry)

# ────────────────────────────────────────────────
# TXT File Upload → Parse Cards (waiting_for_card_number)
# ────────────────────────────────────────────────
@router.message(OrderStates.waiting_for_card_number, F.document)
async def process_card_txt_upload(message: Message, state: FSMContext):
    doc = message.document
    # Only accept plain text files
    if doc.mime_type not in ("text/plain",) and not (doc.file_name or "").lower().endswith(".txt"):
        await message.answer(
            "❌ Sirf `.txt` files accept ki jaati hain.\n"
            "File me ek line me ek card hona chahiye:\\n"
            "`NUMBER|MM|YY|CVV|NAME`",
            parse_mode="Markdown"
        )
        return

    # Download the file into memory
    parsing_msg = await message.answer("📂 File parse kar raha hun...")
    try:
        file_bytes = io.BytesIO()
        await message.bot.download(doc, destination=file_bytes)
        file_bytes.seek(0)
        raw_text = file_bytes.read().decode("utf-8", errors="ignore")
    except Exception as e:
        await parsing_msg.edit_text(f"❌ File download error: {e}")
        return

    lines = [l.strip() for l in raw_text.splitlines() if l.strip()]
    total_lines = len(lines)

    if total_lines == 0:
        await parsing_msg.edit_text("❌ File empty hai ya koi valid line nahi mili.")
        return

    await parsing_msg.edit_text(f"⏳ {total_lines} lines parse ho rahi hain...")

    # Reuse the same 5-field parser
    def parse_five_field(line: str):
        parts = re.split(r'[\|\,]+', line.strip())
        parts = [p.strip() for p in parts if p.strip()]
        if len(parts) >= 5:
            card_num = parts[0].replace(" ", "").replace("-", "")
            if not re.fullmatch(r'\d{13,19}', card_num):
                return None
            if not re.fullmatch(r'\d{1,2}', parts[1]):
                return None
            year = parts[2]
            if not re.fullmatch(r'\d{2,4}', year):
                return None
            if len(year) == 4:
                year = year[2:]
            cvc = parts[3]
            if not re.fullmatch(r'\d{3,4}', cvc):
                return None
            name = ' '.join(parts[4:]).upper().strip()
            if not name:
                return None
            return {
                "card_number": card_num,
                "exp_month": parts[1].zfill(2),
                "exp_year": year,
                "card_cvc": cvc,
                "card_holder_name": name
            }
        return None

    valid_cards = [c for c in (parse_five_field(l) for l in lines) if c is not None]
    invalid_count = total_lines - len(valid_cards)

    if not valid_cards:
        await parsing_msg.edit_text(
            f"❌ Koi valid card nahi mila ({total_lines} lines parse ki, sabh invalid).\n\n"
            "Required format per line:\n"
            "`NUMBER|MM|YY|CVV|NAME`",
            parse_mode="Markdown"
        )
        return

    # Delete user message for security
    try:
        await message.delete()
    except Exception:
        pass

    # Show preview (max 5 cards)
    preview_lines = []
    for i, c in enumerate(valid_cards[:5], 1):
        preview_lines.append(
            f"{i}. `**** **** **** {c['card_number'][-4:]}` | `{c['exp_month']}/{c['exp_year']}` | `{c['card_holder_name']}`"
        )
    if len(valid_cards) > 5:
        preview_lines.append(f"_...aur {len(valid_cards) - 5} cards_")

    preview = '\n'.join(preview_lines)
    invalid_note = f"\n\n⚠️ {invalid_count} line(s) invalid format me thi, skip kar di." if invalid_count else ""

    await parsing_msg.edit_text(
        f"✅ **{len(valid_cards)} Cards Parsed** (from `{doc.file_name}`):\n\n"
        f"{preview}{invalid_note}\n\n"
        f"Bot inhe **ek ek karke try karega** jab tak payment succeed na ho jaye.\n\n"
        f"⚠️ Confirm karke payment process hoga.",
        reply_markup=get_confirmation_keyboard(),
        parse_mode="Markdown"
    )

    await state.update_data(cards_batch=valid_cards)
    await state.set_state(OrderStates.confirm_purchase)

# ────────────────────────────────────────────────
# Card Expiry

# ────────────────────────────────────────────────
@router.message(OrderStates.waiting_for_card_expiry)
async def process_card_expiry(message: Message, state: FSMContext):
    expiry = message.text.strip()

    try:
        await message.delete()
    except Exception:
        pass

    # Accept MM/YY or MM/YYYY
    match = re.fullmatch(r"(\d{2})[/\-](\d{2,4})", expiry)
    if not match:
        await message.answer("❌ Invalid format. Please enter expiry as `MM/YY` (e.g. `01/27`):", parse_mode="Markdown")
        return

    exp_month = match.group(1)
    exp_year = match.group(2)
    # Normalize to 2-digit year
    if len(exp_year) == 4:
        exp_year = exp_year[2:]

    await state.update_data(exp_month=exp_month, exp_year=exp_year)
    await message.answer(
        "✅ Expiry saved.\n\n"
        "🔒 Ab apna **CVV/CVC** bhejein (3 ya 4 digits):",
        parse_mode="Markdown"
    )
    await state.set_state(OrderStates.waiting_for_card_cvc)

# ────────────────────────────────────────────────
# Card CVC
# ────────────────────────────────────────────────
@router.message(OrderStates.waiting_for_card_cvc)
async def process_card_cvc(message: Message, state: FSMContext):
    cvc = message.text.strip()

    try:
        await message.delete()
    except Exception:
        pass

    if not re.fullmatch(r"\d{3,4}", cvc):
        await message.answer("❌ Invalid CVV. Please enter 3 or 4 digit CVV:")
        return

    await state.update_data(card_cvc=cvc)
    await message.answer(
        "✅ CVV saved.\n\n"
        "👤 Ab **Cardholder Name** bhejein\n"
        "(Wahi naam jo card ke upar likha hai, e.g. `SHIV KUMAR`):",
        parse_mode="Markdown"
    )
    await state.set_state(OrderStates.waiting_for_card_name)

# ────────────────────────────────────────────────
# Cardholder Name → Show Final Confirmation
# ────────────────────────────────────────────────
@router.message(OrderStates.waiting_for_card_name)
async def process_card_name(message: Message, state: FSMContext):
    name = message.text.strip().upper()

    try:
        await message.delete()
    except Exception:
        pass

    if len(name) < 2:
        await message.answer("❌ Invalid name. Please enter cardholder name as on the card:")
        return

    await state.update_data(card_holder_name=name)
    state_data = await state.get_data()

    sku_name = state_data.get("selected_product_name")
    price = state_data.get("selected_product_price")
    target = state_data.get("target_username")
    exp_month = state_data.get("exp_month")
    exp_year = state_data.get("exp_year")
    card_number = state_data.get("card_number", "")
    # Show masked card number for confirmation
    masked_card = f"**** **** **** {card_number[-4:]}" if len(card_number) >= 4 else "****"

    delivery_line = f"👤 **Target Account:** `{target}`\n" if target else "⚙️ **Delivery:** Instant Code Key\n"

    confirm_text = (
        f"🛒 **Order Confirmation**\n\n"
        f"📦 **Product:** {sku_name}\n"
        f"💵 **Price:** ₹{price}\n"
        f"{delivery_line}"
        f"\n💳 **Payment Details:**\n"
        f"Card: `{masked_card}`\n"
        f"Expiry: `{exp_month}/{exp_year}`\n"
        f"Name: `{name}`\n\n"
        f"⚠️ Confirm karke payment process hoga. Cancel karne par order nahi bnega."
    )
    await message.answer(confirm_text, reply_markup=get_confirmation_keyboard(), parse_mode="Markdown")
    await state.set_state(OrderStates.confirm_purchase)

# ────────────────────────────────────────────────
# Final: Execute Purchase
# ────────────────────────────────────────────────
@router.callback_query(F.data.startswith("confirm_buy_"))
async def execute_purchase(callback: CallbackQuery, state: FSMContext):
    decision = callback.data.replace("confirm_buy_", "")

    if decision == "no":
        await callback.message.edit_text("❌ **Order cancelled.**\n\nWapas menu se naya order karein.", parse_mode="Markdown")
        await state.clear()
        await callback.answer()
        return

    state_data = await state.get_data()
    product_name = state_data.get("selected_product_name")
    price = state_data.get("selected_product_price")
    sku_url = state_data.get("selected_sku_url", "")
    target_username = state_data.get("target_username")
    offer_id = state_data.get("selected_offer_id")

    # ── Build cards list (batch or single) ──
    cards_batch = state_data.get("cards_batch")
    if not cards_batch:
        # Legacy single-card path
        cards_batch = [{
            "card_number": state_data.get("card_number"),
            "exp_month": state_data.get("exp_month"),
            "exp_year": state_data.get("exp_year"),
            "card_cvc": state_data.get("card_cvc"),
            "card_holder_name": state_data.get("card_holder_name")
        }]

    user_record = await db.get_user(callback.from_user.id)
    if not user_record or not user_record.get("cookies_json"):
        await callback.message.edit_text("🔒 Session expired. Please `/login` se dobara login karein.")
        await state.clear()
        return

    await callback.message.edit_text(
        "⏳ **Processing payment...**\n\n"
        "1️⃣ Creating order on U7BUY...",
        parse_mode="Markdown"
    )
    await callback.answer()

    client = U7BuyApiClient(user_record["cookies_json"])

    # ── Multi-card sequential retry loop ──
    total_cards = len(cards_batch)
    result = {"status": "failed", "message": "No cards attempted."}
    order_id = "N/A"

    for card_idx, card in enumerate(cards_batch, 1):
        card_number = card.get("card_number")
        exp_month = card.get("exp_month")
        exp_year = card.get("exp_year")
        card_cvc = card.get("card_cvc")
        card_holder_name = card.get("card_holder_name")

        # Update status message for this attempt
        await callback.message.edit_text(
            f"⏳ **Processing payment...**\n\n"
            f"💳 Trying card **{card_idx}/{total_cards}**: `**** **** **** {card_number[-4:]}`\n"
            f"📋 Name: `{card_holder_name}`\n\n"
            f"🔄 Generating checkout...",
            parse_mode="Markdown"
        )

        # Get a fresh cashInfoKey for each card attempt
        cash_info_key = await _get_cash_info_key(client, sku_url, offer_id=offer_id, target_username=target_username)
        if not cash_info_key:
            await callback.message.edit_text(
                "❌ **Checkout Error**\n\n"
                "Product ka checkout link generate nahi ho saka.\n"
                "Possible reason: Product temporarily unavailable ya out of stock.\n\n"
                "Please dusra product try karein ya baad me try karein.",
                parse_mode="Markdown"
            )
            await state.clear()
            return

        await callback.message.edit_text(
            f"⏳ **Processing payment...**\n\n"
            f"💳 Card **{card_idx}/{total_cards}**: `**** **** **** {card_number[-4:]}`\n\n"
            f"🔒 Submitting payment via Stripe...",
            parse_mode="Markdown"
        )

        result = await client.full_checkout(
            cash_info_key=cash_info_key,
            card_number=card_number,
            exp_month=exp_month,
            exp_year=exp_year,
            cvc=card_cvc,
            card_holder_name=card_holder_name
        )

        order_id = result.get("order_id", "N/A")
        status = result.get("status")

        # Log each attempt
        await db.log_order(
            tg_id=callback.from_user.id,
            api_order_id=order_id,
            product_name=product_name,
            price=float(price) if price and str(price).replace(".", "").isdigit() else 0.0,
            status=status
        )

        # Stop retrying on success or 3DS (requires user action anyway)
        if status in ["success", "3ds_required"]:
            break

        # Notify between failed attempts (if more cards remain)
        if card_idx < total_cards:
            await callback.message.edit_text(
                f"⚠️ Card **{card_idx}/{total_cards}** (`**** {card_number[-4:]}`) → ❌ {status.upper()}\n\n"
                f"🔄 Trying next card ({card_idx+1}/{total_cards})...",
                parse_mode="Markdown"
            )

    order_id = result.get("order_id", "N/A")
    status = result.get("status")
    msg = result.get("message", "")

    # Strip any Markdown conflicting characters from raw error messages
    safe_msg = str(msg).replace("[", "(").replace("]", ")").replace("_", " ").replace("*", "")

    # Send screenshot only for the LAST card attempted (avoid spam in mass check)
    last_screenshot = result.get("screenshot_path")
    if last_screenshot and status in ["success", "3ds_required", "failed", "card_declined"]:
        import os
        if os.path.exists(last_screenshot):
            try:
                photo = FSInputFile(last_screenshot)
                label = f"**** {card_number[-4:]}" if card_number else "card"
                await callback.message.answer_photo(
                    photo=photo,
                    caption=f"📸 Card {card_idx}/{total_cards}: `{label}` → **{status.upper()}**"
                )
            except Exception:
                pass

    # ── Result messages ──
    if status == "success":
        await callback.message.edit_text(
            f"✅ **Payment Successful!**\n\n"
            f"📦 **Product:** {product_name}\n"
            f"💰 **Order ID:** `{order_id}`\n"
            f"{'👤 **Account:** ' + target_username + chr(10) if target_username else ''}"
            f"\n🎉 U7BUY par apna order history check karein delivery ke liye!",
            parse_mode="Markdown"
        )

    elif status == "3ds_required":
        redirect_url = result.get("redirect_url", "")
        await callback.message.edit_text(
            f"🔐 <b>Bank Verification Required (3DS/OTP)</b>\n\n"
            f"📦 <b>Product:</b> {product_name}\n"
            f"💰 <b>Order ID:</b> <code>{order_id}</code>\n\n"
            f"Aapke bank ne OTP/3D-Secure verification maanga hai.\n"
            f"👇 <b>Niche diye link par click karke OTP verify karein:</b>\n\n"
            f'<a href="{redirect_url}">Click Here to Verify</a>\n\n'
            f"<i>Verify karne ke baad order automatically complete ho jayega.</i>",
            parse_mode="HTML",
            disable_web_page_preview=True
        )

    elif status == "card_declined":
        await callback.message.edit_text(
            f"❌ **Card Declined**\n\n"
            f"💳 {safe_msg}\n\n"
            f"Please dusra card use karein ya apne bank se contact karein.\n"
            f"Order cancelled.",
            parse_mode="Markdown"
        )

    elif status == "card_error":
        await callback.message.edit_text(
            f"❌ **Card Error**\n\n"
            f"💳 {safe_msg}\n\n"
            f"Card details check karke dobara try karein.",
            parse_mode="Markdown"
        )

    elif status == "failed":
        await callback.message.edit_text(
            f"❌ **Payment Failed**\n\n"
            f"💰 Order ID: `{order_id}`\n"
            f"Reason: {safe_msg}\n\n"
            f"Please retry ya dusra payment method use karein.",
            parse_mode="Markdown"
        )

    elif status == "timeout":
        await callback.message.edit_text(
            f"⏳ **Payment Status Unknown**\n\n"
            f"💰 Order ID: `{order_id}`\n\n"
            f"Payment process hua lekin status confirm nahi hua.\n"
            f"U7BUY profile me apna order history check karein:\n"
            f"https://www.u7buy.com/user/order",
            parse_mode="Markdown",
            disable_web_page_preview=True
        )

    elif status == "fraud_declined":
        await callback.message.edit_text(
            f"🚫 **Payment Blocked (Fraud Detection)**\n\n"
            f"💰 Order ID: `{order_id}`\n\n"
            f"Aapka payment U7BUY ke fraud detection system (Forter) ne block kar diya.\n\n"
            f"*Reasons:*\n"
            f"• Bot se payment hone ki wajah se automated flag lagi\n"
            f"• IP address suspicious ho sakta hai\n\n"
            f"*Solution:*\n"
            f"Browser me directly U7BUY.com par jaake same product buy karein.\n"
            f"https://www.u7buy.com/telegram/top-up",
            parse_mode="Markdown",
            disable_web_page_preview=True
        )

    else:
        await callback.message.edit_text(
            f"❌ **Error**\n\n{safe_msg}\n\n"
            f"Please `/login` se session refresh karke dobara try karein.",
            parse_mode="Markdown"
        )

    await state.clear()



# ────────────────────────────────────────────────
# Helper: Get cashInfoKey for a product
# ────────────────────────────────────────────────
async def _get_cash_info_key(
    client: U7BuyApiClient,
    sku_url: str,
    offer_id: str = None,
    target_username: str = None
) -> str | None:
    """
    Gets cashInfoKey:
    - Telegram Stars: calls real save_cashier_info with offerId + TG username
    - Google Play: calls digital createOrder (URL may need updating based on future cURL capture)
    """
    if sku_url == "telegram-stars":
        if not offer_id or not target_username:
            return None
        result = await client.save_cashier_info(
            offer_id=offer_id,
            tg_username=target_username
        )
        return result.get("cashInfoKey")  # None if error key is present instead
    else:
        # Google Play digital card
        import aiohttp
        url = f"{client.BASE_URL}/prod-api/api/order/digital/createOrder"
        payload = {
            "skuUrl": sku_url,
            "currency": "INR",
            "quantity": 1
        }
        headers = {**client.headers, "content-type": "application/json"}
        async with aiohttp.ClientSession(cookies=client.cookies_dict) as session:
            try:
                async with session.post(url, json=payload, headers=headers, timeout=15) as r:
                    res_json = await r.json()
                    import logging
                    logging.getLogger(__name__).info(f"GP createOrder response: {res_json}")
                    if res_json.get("code") == 200:
                        data = res_json.get("data")
                        if isinstance(data, str) and len(data) > 10:
                            return data
                        elif isinstance(data, dict):
                            return data.get("cashInfoKey") or data.get("cashKey") or data.get("key")
            except Exception as e:
                import logging
                logging.getLogger(__name__).error(f"GP createOrder exception: {e}")
    return None
