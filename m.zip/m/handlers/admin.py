"""
Admin Handler — Complete owner control panel
Owner ID: from settings.OWNER_ID
"""
import asyncio
import logging
from datetime import datetime, timezone

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext

from config import settings
from database import db
from states.states import AdminStates
from keyboards.inline import (
    get_admin_panel, get_admin_proxy_menu, get_admin_account_menu,
    get_admin_keys_menu, get_admin_users_menu,
    get_proxy_select_keyboard, get_account_select_keyboard
)

logger = logging.getLogger(__name__)
router = Router()

OWNER_ID = settings.OWNER_ID

def is_owner(tg_id: int) -> bool:
    return tg_id == OWNER_ID

def owner_only(func):
    """Decorator to restrict handlers to owner only."""
    import functools
    @functools.wraps(func)
    async def wrapper(update, *args, **kwargs):
        uid = update.from_user.id if hasattr(update, "from_user") else 0
        if not is_owner(uid):
            if hasattr(update, "answer"):
                await update.answer("🚫 Owner only command.")
            return
        return await func(update, *args, **kwargs)
    return wrapper

def fmt_dt(iso: str) -> str:
    try:
        dt = datetime.fromisoformat(iso)
        return dt.strftime("%d %b %Y %H:%M")
    except Exception:
        return iso or "N/A"

# ─────────────────────────────────────────────────────────
# /admin command
# ─────────────────────────────────────────────────────────
@router.message(Command("admin"))
async def admin_command(message: Message, state: FSMContext):
    if not is_owner(message.from_user.id):
        await message.answer("🚫 You are not authorized to use this command.")
        return
    await state.clear()
    proxies = await db.list_proxies()
    accounts = await db.list_all_accounts()
    keys = await db.list_access_keys()
    users = await db.list_users()
    orders = await db.list_orders()

    active_proxies = sum(1 for p in proxies if p.get("active"))
    active_keys = sum(1 for k in keys if k.get("active") and not k.get("used_by_tg_id"))
    used_keys = sum(1 for k in keys if k.get("used_by_tg_id"))
    active_users = sum(1 for u in users if u.get("active"))
    success_orders = sum(1 for o in orders if o.get("status") == "success")

    text = (
        f"👑 *Admin Control Panel*\n\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🖥️ Proxies: *{active_proxies}/{len(proxies)}* active\n"
        f"👤 Accounts: *{len(accounts)}* total\n"
        f"🔑 Keys: *{active_keys}* unused  ·  *{used_keys}* claimed\n"
        f"👥 Users: *{active_users}/{len(users)}* active\n"
        f"📦 Orders: *{len(orders)}* total  ·  *{success_orders}* ✅\n"
        f"━━━━━━━━━━━━━━━━━━"
    )
    await message.answer(text, reply_markup=get_admin_panel(), parse_mode="Markdown")


@router.callback_query(F.data == "admin_back")
async def admin_back(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    await state.clear()
    proxies = await db.list_proxies()
    accounts = await db.list_all_accounts()
    keys = await db.list_access_keys()
    users = await db.list_users()
    orders = await db.list_orders()
    active_proxies = sum(1 for p in proxies if p.get("active"))
    active_keys = sum(1 for k in keys if k.get("active") and not k.get("used_by_tg_id"))
    used_keys = sum(1 for k in keys if k.get("used_by_tg_id"))
    active_users = sum(1 for u in users if u.get("active"))
    success_orders = sum(1 for o in orders if o.get("status") == "success")
    text = (
        f"👑 *Admin Control Panel*\n\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🖥️ Proxies: *{active_proxies}/{len(proxies)}* active\n"
        f"👤 Accounts: *{len(accounts)}* total\n"
        f"🔑 Keys: *{active_keys}* unused  ·  *{used_keys}* claimed\n"
        f"👥 Users: *{active_users}/{len(users)}* active\n"
        f"📦 Orders: *{len(orders)}* total  ·  *{success_orders}* ✅\n"
        f"━━━━━━━━━━━━━━━━━━"
    )
    await callback.message.edit_text(text, reply_markup=get_admin_panel(), parse_mode="Markdown")
    await callback.answer()


# ═════════════════════════════════════════════
# PROXY MANAGEMENT
# ═════════════════════════════════════════════
@router.callback_query(F.data == "admin_proxies")
async def admin_proxies(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    await callback.message.edit_text(
        "🖥️ *Proxy Pool*\n\n"
        "Manage residential proxies.\n"
        "Each proxy supports max *2 accounts*.\n\n"
        "_Add format:_ `host:port:username:password`\n"
        "_Or:_ `username:password@host:port`",
        reply_markup=get_admin_proxy_menu(),
        parse_mode="Markdown"
    )
    await callback.answer()


@router.callback_query(F.data == "admin_proxy_add")
async def admin_proxy_add_start(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    await callback.message.edit_text(
        "➕ *Add Residential Proxy*\n\n"
        "Send proxy in one of these formats:\n\n"
        "`host:port:username:password`\n"
        "`username:password@host:port`\n\n"
        "Example:\n"
        "`p105.instantproxies.com:8937:3364:y0a3zi1hkcd9`\n\n"
        "Or with label:\n"
        "`host:port:user:pass | My Label`",
        parse_mode="Markdown"
    )
    await state.set_state(AdminStates.add_proxy_input)
    await callback.answer()


@router.message(AdminStates.add_proxy_input)
async def admin_proxy_add_process(message: Message, state: FSMContext):
    if not is_owner(message.from_user.id):
        await state.clear()
        return
    raw = message.text.strip()
    label = ""

    # Parse optional label
    if " | " in raw:
        raw, label = raw.split(" | ", 1)
        label = label.strip()

    host = port = username = password = ""

    try:
        # Format: user:pass@host:port
        if "@" in raw:
            auth_part, host_part = raw.rsplit("@", 1)
            # auth_part might be user:pass or port:pass (instantproxies format)
            if ":" in auth_part:
                up = auth_part.split(":", 1)
                username, password = up[0], up[1]
            if ":" in host_part:
                hp = host_part.rsplit(":", 1)
                host, port = hp[0], hp[1]
        else:
            # Format: host:port:user:pass
            parts = raw.split(":")
            if len(parts) == 4:
                host, port, username, password = parts
    except Exception:
        pass

    if not all([host, port, username, password]):
        await message.answer(
            "❌ *Could not parse proxy format.*\n\n"
            "Please use:\n`host:port:username:password`\nor\n`username:password@host:port`",
            parse_mode="Markdown"
        )
        await state.clear()
        return

    proxy = await db.add_proxy(
        host=host, port=port, username=username, password=password,
        protocol="http", label=label or f"{host}:{port}"
    )
    await message.answer(
        f"✅ *Proxy Added!*\n\n"
        f"🆔 ID: `{proxy['id']}`\n"
        f"🌐 Host: `{host}:{port}`\n"
        f"🏷️ Label: `{proxy['label']}`\n"
        f"🔗 URL: `{proxy['url']}`",
        parse_mode="Markdown"
    )
    await state.clear()


@router.callback_query(F.data == "admin_proxy_list")
async def admin_proxy_list(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    proxies = await db.list_proxies()
    if not proxies:
        await callback.message.edit_text(
            "📋 *No proxies added yet.*\n\nUse 'Add Proxy' to add one.",
            reply_markup=get_admin_proxy_menu(), parse_mode="Markdown"
        )
        await callback.answer()
        return

    lines = ["📋 *Proxy Pool*\n"]
    for p in proxies:
        slots = len(p.get("account_slots", []))
        status = "🟢" if p.get("active") else "🔴"
        lines.append(
            f"{status} `{p['id']}`\n"
            f"   🌐 `{p['host']}:{p['port']}`\n"
            f"   🏷️ {p.get('label', '')}\n"
            f"   👤 Accounts: {slots}/2\n"
            f"   📅 Added: {fmt_dt(p.get('added_at',''))}\n"
        )
    text = "\n".join(lines)
    # Split if too long
    if len(text) > 4000:
        text = text[:4000] + "\n..."
    await callback.message.edit_text(text, reply_markup=get_admin_proxy_menu(), parse_mode="Markdown")
    await callback.answer()


@router.callback_query(F.data == "admin_proxy_test")
async def admin_proxy_test(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    await callback.message.edit_text("🔍 *Testing all proxies...*\n\nThis may take a moment.", parse_mode="Markdown")
    await callback.answer()

    proxies = await db.list_proxies()
    if not proxies:
        await callback.message.edit_text(
            "No proxies to test.",
            reply_markup=get_admin_proxy_menu()
        )
        return

    results = []
    for p in proxies:
        try:
            import requests
            proxy_url = p["url"]
            r = requests.get(
                "https://httpbin.org/ip",
                proxies={"http": proxy_url, "https": proxy_url},
                timeout=10
            )
            if r.status_code == 200:
                ip = r.json().get("origin", "?")
                results.append(f"✅ `{p['id']}` — {p.get('label','')} — IP: `{ip}`")
            else:
                results.append(f"❌ `{p['id']}` — HTTP {r.status_code}")
        except Exception as e:
            results.append(f"❌ `{p['id']}` — {str(e)[:50]}")

    text = "🔍 *Proxy Test Results*\n\n" + "\n".join(results)
    if len(text) > 4000:
        text = text[:4000]
    await callback.message.edit_text(text, reply_markup=get_admin_proxy_menu(), parse_mode="Markdown")


# ═════════════════════════════════════════════
# ACCOUNT MANAGEMENT
# ═════════════════════════════════════════════
@router.callback_query(F.data == "admin_accounts")
async def admin_accounts(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    await callback.message.edit_text(
        "👤 *Account Pool*\n\n"
        "Manage U7BUY accounts linked to proxies.\n"
        "Each proxy supports *max 2 accounts*.\n\n"
        "To add: Select proxy → Paste cookies → Enter email",
        reply_markup=get_admin_account_menu(),
        parse_mode="Markdown"
    )
    await callback.answer()


@router.callback_query(F.data == "admin_acc_add")
async def admin_acc_add_start(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    proxies = await db.list_proxies()
    accounts_all = await db.list_all_accounts()
    account_ids = {a["id"] for a in accounts_all}

    # Count only valid (existing) account slots per proxy
    available = []
    for p in proxies:
        if not p.get("active"):
            continue
        real_slots = [aid for aid in p.get("account_slots", []) if aid in account_ids]
        if len(real_slots) < 2:
            available.append(p)

    if not available:
        await callback.message.edit_text(
            "❌ *No available proxy slots.*\n\n"
            "All proxies are full (2/2 accounts).\n"
            "Add a new proxy first.",
            reply_markup=get_admin_account_menu(),
            parse_mode="Markdown"
        )
        await callback.answer()
        return
    await callback.message.edit_text(
        "➕ *Add Account — Select Proxy*\n\n"
        "Choose which proxy to link this account to:",
        reply_markup=get_proxy_select_keyboard(available, "admin_acc_proxy_"),
        parse_mode="Markdown"
    )
    await callback.answer()



@router.callback_query(F.data.startswith("admin_acc_proxy_"))
async def admin_acc_proxy_selected(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    proxy_id = callback.data.replace("admin_acc_proxy_", "")
    await state.update_data(selected_proxy_id=proxy_id)
    await callback.message.edit_text(
        "📋 *Paste Account Cookies*\n\n"
        "Export cookies from Cookie-Editor on u7buy.com\n"
        "and paste the JSON here.\n\n"
        "_Your message will be deleted automatically._",
        parse_mode="Markdown"
    )
    await state.set_state(AdminStates.add_account_cookies)
    await callback.answer()


@router.message(AdminStates.add_account_cookies)
async def admin_acc_cookies_input(message: Message, state: FSMContext):
    if not is_owner(message.from_user.id): return
    try:
        await message.delete()
    except Exception:
        pass
    cookie_data = message.text.strip()
    await state.update_data(account_cookies=cookie_data)

    # Try to extract email from token for auto-fill
    auto_email = ""
    try:
        from services.u47_api import U7BuyApiClient
        import base64, json as _json
        client = U7BuyApiClient(cookie_data)
        if client.access_token:
            parts = client.access_token.split(".")
            pl = parts[1] + "=" * (-len(parts[1]) % 4)
            payload = _json.loads(base64.urlsafe_b64decode(pl))
            auto_email = payload.get("email") or payload.get("sub") or ""
    except Exception:
        pass

    prompt = "Now enter the *email address* for this account:"
    if auto_email:
        prompt += f"\n\n_(Detected: `{auto_email}` — send it or enter a custom one)_"
    await state.update_data(detected_email=auto_email)
    await message.answer(prompt, parse_mode="Markdown")
    await state.set_state(AdminStates.add_account_email)


@router.message(AdminStates.add_account_email)
async def admin_acc_email_input(message: Message, state: FSMContext):
    if not is_owner(message.from_user.id): return
    data = await state.get_data()
    proxy_id = data.get("selected_proxy_id")
    cookies = data.get("account_cookies")
    email = message.text.strip() or data.get("detected_email", "Unknown")

    # Extract token expiry
    exp = 0
    try:
        from services.u47_api import U7BuyApiClient
        from services.cookie_monitor import decode_jwt_expiry
        client = U7BuyApiClient(cookies)
        if client.access_token:
            exp = decode_jwt_expiry(client.access_token) or 0
    except Exception:
        pass

    account = await db.add_account(
        proxy_id=proxy_id,
        email=email,
        cookies_json=cookies,
        access_token_exp=exp
    )

    if not account:
        await message.answer(
            "❌ *Failed to add account.*\n\n"
            "Proxy may be full (2/2) or proxy ID invalid.",
            parse_mode="Markdown"
        )
    else:
        import time
        exp_str = ""
        if exp:
            hrs = (exp - int(time.time())) / 3600
            exp_str = f"\n⏳ Token expires in: *{round(hrs,1)}h*"
        await message.answer(
            f"✅ *Account Added!*\n\n"
            f"🆔 ID: `{account['id']}`\n"
            f"📧 Email: `{email}`\n"
            f"🖥️ Proxy: `{proxy_id}`\n"
            f"🔢 Slot: {account.get('slot')}{exp_str}",
            parse_mode="Markdown"
        )
    await state.clear()


@router.callback_query(F.data == "admin_acc_list")
async def admin_acc_list(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    accounts = await db.list_all_accounts()
    if not accounts:
        await callback.message.edit_text(
            "📋 *No accounts added yet.*",
            reply_markup=get_admin_account_menu(),
            parse_mode="Markdown"
        )
        await callback.answer()
        return

    import time
    lines = ["📋 *Account Pool*\n"]
    for a in accounts:
        exp = a.get("access_token_exp", 0)
        if exp:
            hrs = (exp - int(time.time())) / 3600
            if hrs <= 0:
                exp_status = "🔴 EXPIRED"
            elif hrs <= 48:
                exp_status = f"🟡 {round(hrs,1)}h left"
            else:
                exp_status = f"🟢 {round(hrs,1)}h left"
        else:
            exp_status = "⚪ Unknown"
        lines.append(
            f"• `{a['id']}` — Slot {a.get('slot','?')}\n"
            f"  📧 {a.get('email','?')}\n"
            f"  🖥️ Proxy: `{a.get('proxy_id','?')}`\n"
            f"  ⏳ Token: {exp_status}\n"
            f"  🔄 Refreshed: {fmt_dt(a.get('last_refreshed',''))}\n"
        )
    text = "\n".join(lines)
    if len(text) > 4000:
        text = text[:4000] + "\n..."
    await callback.message.edit_text(text, reply_markup=get_admin_account_menu(), parse_mode="Markdown")
    await callback.answer()


@router.callback_query(F.data == "admin_acc_refresh")
async def admin_acc_refresh_start(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    accounts = await db.list_all_accounts()
    if not accounts:
        await callback.message.edit_text("No accounts to refresh.", reply_markup=get_admin_account_menu())
        await callback.answer()
        return
    await callback.message.edit_text(
        "🔄 *Refresh Cookies — Select Account:*",
        reply_markup=get_account_select_keyboard(accounts, "admin_refresh_acc_"),
        parse_mode="Markdown"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("admin_refresh_acc_"))
async def admin_refresh_acc_selected(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    acc_id = callback.data.replace("admin_refresh_acc_", "")
    await state.update_data(refresh_acc_id=acc_id)
    await callback.message.edit_text(
        f"🔄 *Refreshing:* `{acc_id}`\n\n"
        "Paste new cookies JSON below:",
        parse_mode="Markdown"
    )
    await state.set_state(AdminStates.refresh_account_cookies)
    await callback.answer()


@router.message(AdminStates.refresh_account_cookies)
async def admin_refresh_cookies_input(message: Message, state: FSMContext):
    if not is_owner(message.from_user.id): return
    try:
        await message.delete()
    except Exception:
        pass
    await state.update_data(refresh_cookies=message.text.strip())
    await message.answer("Enter the email for this account (or send '.' to keep existing):")
    await state.set_state(AdminStates.refresh_account_email)


@router.message(AdminStates.refresh_account_email)
async def admin_refresh_email_input(message: Message, state: FSMContext):
    if not is_owner(message.from_user.id): return
    data = await state.get_data()
    acc_id = data.get("refresh_acc_id")
    cookies = data.get("refresh_cookies")
    email_input = message.text.strip()
    email = "" if email_input == "." else email_input

    exp = 0
    try:
        from services.u47_api import U7BuyApiClient
        from services.cookie_monitor import decode_jwt_expiry
        client = U7BuyApiClient(cookies)
        if client.access_token:
            exp = decode_jwt_expiry(client.access_token) or 0
    except Exception:
        pass

    success = await db.refresh_account_cookies(acc_id, cookies, exp, email)
    if success:
        import time
        exp_str = ""
        if exp:
            hrs = (exp - int(time.time())) / 3600
            exp_str = f"\n⏳ New expiry: *{round(hrs,1)}h*"
        await message.answer(
            f"✅ *Cookies Refreshed!*\n\n"
            f"Account `{acc_id}` updated.{exp_str}",
            parse_mode="Markdown"
        )
    else:
        await message.answer("❌ Account not found.")
    await state.clear()


@router.callback_query(F.data == "admin_acc_remove")
async def admin_acc_remove_start(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    accounts = await db.list_all_accounts()
    if not accounts:
        await callback.message.edit_text("No accounts to remove.", reply_markup=get_admin_account_menu())
        await callback.answer()
        return
    await callback.message.edit_text(
        "🗑️ *Remove Account — Select:*",
        reply_markup=get_account_select_keyboard(accounts, "admin_remove_acc_"),
        parse_mode="Markdown"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("admin_remove_acc_"))
async def admin_remove_acc_confirm(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    acc_id = callback.data.replace("admin_remove_acc_", "")
    success = await db.remove_account(acc_id)
    await callback.message.edit_text(
        f"{'✅ Account `' + acc_id + '` removed.' if success else '❌ Account not found.'}",
        reply_markup=get_admin_account_menu(),
        parse_mode="Markdown"
    )
    await callback.answer()


# ═════════════════════════════════════════════
# ACCESS KEYS
# ═════════════════════════════════════════════
@router.callback_query(F.data == "admin_keys")
async def admin_keys(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    await callback.message.edit_text(
        "🔑 *Access Keys*\n\n"
        "Generate keys to give users access.\n"
        "Each key is tied to a proxy.\n"
        "Duration: Lifetime (0) or custom days.",
        reply_markup=get_admin_keys_menu(),
        parse_mode="Markdown"
    )
    await callback.answer()


@router.callback_query(F.data == "admin_key_gen")
async def admin_key_gen_start(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    proxies = await db.list_proxies()
    active_proxies = [p for p in proxies if p.get("active")]
    if not active_proxies:
        await callback.message.edit_text(
            "❌ No active proxies. Add a proxy first.",
            reply_markup=get_admin_keys_menu()
        )
        await callback.answer()
        return
    await callback.message.edit_text(
        "🔑 *Generate Key — Select Proxy:*\n\n"
        "The key will be linked to this proxy.",
        reply_markup=get_proxy_select_keyboard(active_proxies, "admin_key_proxy_"),
        parse_mode="Markdown"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("admin_key_proxy_"))
async def admin_key_proxy_selected(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    proxy_id = callback.data.replace("admin_key_proxy_", "")
    await state.update_data(key_proxy_id=proxy_id)
    await callback.message.edit_text(
        "🔑 *Key Duration*\n\n"
        "Enter duration in days:\n"
        "• `0` = Lifetime (never expires)\n"
        "• `30` = 30 days\n"
        "• `7` = 1 week",
        parse_mode="Markdown"
    )
    await state.set_state(AdminStates.generate_key_duration)
    await callback.answer()


@router.message(AdminStates.generate_key_duration)
async def admin_key_duration(message: Message, state: FSMContext):
    if not is_owner(message.from_user.id): return
    try:
        days = int(message.text.strip())
    except ValueError:
        await message.answer("❌ Enter a valid number.")
        return
    await state.update_data(key_duration_days=days)
    await message.answer("Add an optional note for this key (or send '.' to skip):")
    await state.set_state(AdminStates.generate_key_note)


@router.message(AdminStates.generate_key_note)
async def admin_key_note(message: Message, state: FSMContext):
    if not is_owner(message.from_user.id): return
    data = await state.get_data()
    proxy_id = data.get("key_proxy_id")
    duration = data.get("key_duration_days", 0)
    note = message.text.strip() if message.text.strip() != "." else ""

    key_obj = await db.generate_access_key(proxy_id, duration, note)
    proxy = await db.get_proxy(proxy_id)
    proxy_label = proxy.get("label", proxy_id) if proxy else proxy_id

    validity = "♾️ Lifetime" if duration == 0 else f"📅 {duration} days"
    await message.answer(
        f"🔑 *Access Key Generated!*\n\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"Key: `{key_obj['key']}`\n"
        f"━━━━━━━━━━━━━━━━━━\n\n"
        f"🖥️ Proxy: `{proxy_label}`\n"
        f"⏱️ Validity: {validity}\n"
        f"📝 Note: {note or '—'}\n\n"
        f"_Share this key with the user to grant access._",
        parse_mode="Markdown"
    )
    await state.clear()


@router.callback_query(F.data == "admin_key_list")
async def admin_key_list(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    keys = await db.list_access_keys()
    if not keys:
        await callback.message.edit_text("No keys generated yet.", reply_markup=get_admin_keys_menu())
        await callback.answer()
        return

    lines = ["🔑 *Access Keys*\n"]
    for k in keys[-20:]:  # show last 20
        status = "✅ Active" if k.get("active") else "❌ Revoked"
        used = f"👤 TG: `{k.get('used_by_tg_id')}`" if k.get("used_by_tg_id") else "⏳ Unclaimed"
        validity = "♾️ Lifetime" if not k.get("expires_at") else fmt_dt(k["expires_at"])
        lines.append(
            f"`{k['key']}`\n"
            f"  {status}  ·  {used}\n"
            f"  🖥️ `{k.get('proxy_id','?')}`  ·  {validity}\n"
            f"  📝 {k.get('note') or '—'}\n"
        )
    text = "\n".join(lines)
    if len(text) > 4000:
        text = text[:4000] + "\n..."
    await callback.message.edit_text(text, reply_markup=get_admin_keys_menu(), parse_mode="Markdown")
    await callback.answer()


@router.callback_query(F.data == "admin_key_revoke")
async def admin_key_revoke_start(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    await callback.message.edit_text(
        "❌ *Revoke Key*\n\nSend the key string to revoke:",
        parse_mode="Markdown"
    )
    await state.set_state(AdminStates.revoke_key_input)
    await callback.answer()


@router.message(AdminStates.revoke_key_input)
async def admin_key_revoke_process(message: Message, state: FSMContext):
    if not is_owner(message.from_user.id): return
    key_str = message.text.strip().upper()
    success = await db.revoke_access_key(key_str)
    await message.answer(
        f"{'✅ Key `' + key_str + '` revoked.' if success else '❌ Key not found.'}",
        parse_mode="Markdown"
    )
    await state.clear()


# ═════════════════════════════════════════════
# USER MANAGEMENT
# ═════════════════════════════════════════════
@router.callback_query(F.data == "admin_users")
async def admin_users(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    await callback.message.edit_text(
        "👥 *User Management*",
        reply_markup=get_admin_users_menu(),
        parse_mode="Markdown"
    )
    await callback.answer()


@router.callback_query(F.data == "admin_users_list")
async def admin_users_list(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    users = await db.list_users()
    if not users:
        await callback.message.edit_text("No users yet.", reply_markup=get_admin_users_menu())
        await callback.answer()
        return

    lines = ["👥 *Users List*\n"]
    for u in users:
        status = "🟢" if u.get("active") else "🔴"
        uname = f"@{u.get('username')}" if u.get("username") else "N/A"
        lines.append(
            f"{status} `{u['tg_id']}` — {uname}\n"
            f"  🔑 {u.get('access_key','N/A')}\n"
            f"  🖥️ Proxy: `{u.get('proxy_id','N/A')}`\n"
            f"  📅 {fmt_dt(u.get('joined_at',''))}\n"
        )
    text = "\n".join(lines)
    if len(text) > 4000:
        text = text[:4000] + "\n..."
    await callback.message.edit_text(text, reply_markup=get_admin_users_menu(), parse_mode="Markdown")
    await callback.answer()


@router.callback_query(F.data == "admin_users_block")
async def admin_users_block_start(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    await callback.message.edit_text("🚫 Send the Telegram ID to block:", parse_mode="Markdown")
    await state.set_state(AdminStates.block_user_input)
    await state.update_data(block_action="block")
    await callback.answer()


@router.callback_query(F.data == "admin_users_unblock")
async def admin_users_unblock_start(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    await callback.message.edit_text("✅ Send the Telegram ID to unblock:", parse_mode="Markdown")
    await state.set_state(AdminStates.block_user_input)
    await state.update_data(block_action="unblock")
    await callback.answer()


@router.message(AdminStates.block_user_input)
async def admin_block_user_process(message: Message, state: FSMContext):
    if not is_owner(message.from_user.id): return
    data = await state.get_data()
    action = data.get("block_action", "block")
    try:
        tg_id = int(message.text.strip())
    except ValueError:
        await message.answer("❌ Invalid Telegram ID.")
        await state.clear()
        return

    if action == "block":
        success = await db.block_user(tg_id)
        await message.answer(f"{'🚫 User blocked.' if success else '❌ User not found.'}")
    else:
        success = await db.unblock_user(tg_id)
        await message.answer(f"{'✅ User unblocked.' if success else '❌ User not found.'}")
    await state.clear()


@router.callback_query(F.data == "admin_broadcast")
async def admin_broadcast_start(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    await callback.message.edit_text(
        "📢 *Broadcast Message*\n\nSend the message to broadcast to all active users:",
        parse_mode="Markdown"
    )
    await state.set_state(AdminStates.broadcast_input)
    await callback.answer()


@router.message(AdminStates.broadcast_input)
async def admin_broadcast_send(message: Message, state: FSMContext):
    if not is_owner(message.from_user.id): return
    users = await db.list_users()
    active = [u for u in users if u.get("active") and u.get("tg_id") != OWNER_ID]
    sent = 0
    failed = 0
    for u in active:
        try:
            await message.bot.send_message(
                chat_id=u["tg_id"],
                text=f"📢 *Message from Admin:*\n\n{message.text}",
                parse_mode="Markdown"
            )
            sent += 1
            await asyncio.sleep(0.05)
        except Exception:
            failed += 1
    await message.answer(f"📢 Broadcast sent: ✅ {sent} users  ❌ {failed} failed")
    await state.clear()


# ═════════════════════════════════════════════
# ORDERS
# ═════════════════════════════════════════════
@router.callback_query(F.data == "admin_orders")
async def admin_orders_view(callback: CallbackQuery, state: FSMContext):
    if not is_owner(callback.from_user.id): return
    orders = await db.list_orders()
    if not orders:
        await callback.message.edit_text("No orders yet.", reply_markup=get_admin_panel())
        await callback.answer()
        return

    recent = orders[-20:]
    lines = ["📦 *Recent Orders (last 20)*\n"]
    for o in reversed(recent):
        status_icon = "✅" if o.get("status") == "success" else "❌"
        lines.append(
            f"{status_icon} #{o.get('id')} — TG:`{o.get('tg_id')}`\n"
            f"  📦 {o.get('product_name','?')}\n"
            f"  💰 ₹{o.get('price','?')}  ·  Card: `****{o.get('card_last4','????')}`\n"
            f"  📅 {fmt_dt(o.get('created_at',''))}\n"
        )
    text = "\n".join(lines)
    if len(text) > 4000:
        text = text[:4000] + "\n..."
    await callback.message.edit_text(text, reply_markup=get_admin_panel(), parse_mode="Markdown")
    await callback.answer()
