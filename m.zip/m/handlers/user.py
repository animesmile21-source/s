from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from database import db
from services.u47_api import U7BuyApiClient
from keyboards.reply import get_main_menu
from config import settings

router = Router()

@router.message(CommandStart())
async def start_command(message: Message):
    """
    Sends welcome message and registers the user locally.
    """
    # Register user locally in DB
    await db.save_user(
        tg_id=message.from_user.id,
        username=message.from_user.username,
        cookies_json="",
        logged_in=0 # initially not logged in
    )
    
    welcome_text = (
        f"👋 **Hello {message.from_user.first_name}!**\n\n"
        "Welcome to the **U7BUY Store Bot**.\n"
        "Is bot se aap direct apne telegram account se Google Play Redeem Codes aur Telegram Stars buy kar sakte hain.\n\n"
        "🚀 **Start karne ke liye:**\n"
        "Sabse pehle `/login` command bhejkar apna U7BUY account link karein."
    )
    await message.answer(welcome_text, reply_markup=get_main_menu(), parse_mode="Markdown")

@router.message(Command("help"))
async def help_command(message: Message):
    help_text = (
        "💡 **Available Bot Commands:**\n\n"
        "🔹 `/start` - Start the bot and register\n"
        "🔹 `/login` - Link your U7BUY account using cookies\n"
        "🔹 `/logout` - Remove your cookies and unlink account\n"
        "🔹 `/help` - Show this help message\n\n"
        "👇 Menu buttons use karke bhi aap interact kar sakte hain."
    )
    await message.answer(help_text, parse_mode="Markdown")

@router.message(F.text == "👤 My Profile")
async def profile_handler(message: Message):
    """
    Shows user profile details and verifies session with U7BUY.
    """
    user_record = await db.get_user(message.from_user.id)
    
    if not user_record or not user_record.get("logged_in") or not user_record.get("cookies_json"):
        await message.answer(
            "🔒 **Status: Unlinked**\n\n"
            "Aapka U7BUY account abhi bot se linked nahi hai.\n"
            "Account link karne ke liye `/login` send karein."
        )
        return
        
    status_msg = await message.answer("🔍 **Verifying profile session...**")
    
    # Verify session with U7BUY api
    client = U7BuyApiClient(user_record["cookies_json"])
    session_data = await client.validate_session()
    
    if session_data:
        email = session_data.get("email") or session_data.get("username") or "U7BUY User"
        balance = session_data.get("balance", "N/A")
        vip_level = session_data.get("vipLevel", "N/A")
        
        profile_text = (
            "👤 **Your U7BUY Profile Status**\n\n"
            f"📧 **Email:** {email}\n"
            f"🌟 **VIP Level:** {vip_level}\n"
            f"💰 **Wallet Balance:** {balance}\n"
            "🟢 **Status:** Session Active"
        )
        await status_msg.edit_text(profile_text)
    else:
        # Mark user as logged out in DB if session is expired
        await db.logout_user(message.from_user.id)
        await status_msg.edit_text(
            "⚠️ **Session Expired!**\n\n"
            "Aapka login session expire ho gaya hai.\n"
            "Kripya `/login` bhejkar fresh cookies enter karein."
        )

@router.message(F.text == "🚪 Logout")
async def logout_handler(message: Message):
    """
    Logs out the user, clearing cookies from DB.
    """
    success = await db.logout_user(message.from_user.id)
    if success:
        await message.answer("🚪 **Logged out successfully!**\n\nYour cookies have been deleted from local storage.")
    else:
        await message.answer("Aap pehle se logged out hain.")

@router.message(F.text == "📞 Support")
async def support_handler(message: Message):
    """
    Shows support information.
    """
    await message.answer(
        f"🙋‍♂️ **Customer Support**\n\n"
        f"Agar aapko cookies link karne me ya order payment me koi dikkat aa rahi hai, "
        f"to aap support admin contact kar sakte hain:\n\n"
        f"💬 **Support User:** {settings.SUPPORT_USERNAME}"
    )
    
@router.message(Command("logout"))
async def logout_command(message: Message):
    await logout_handler(message)
