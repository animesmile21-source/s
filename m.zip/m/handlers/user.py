"""
User handler — Profile, support, menu
"""
from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext

from database import db
from keyboards.reply import get_main_menu
from config import settings
import time
import logging

logger = logging.getLogger(__name__)
router = Router()


@router.message(F.text == "👤 My Profile")
async def profile_handler(message: Message, state: FSMContext):
    tg_id = message.from_user.id
    is_owner = tg_id == settings.OWNER_ID
    user = await db.get_user(tg_id)

    if not user or not user.get("access_key"):
        await message.answer(
            "🔒 *Not Activated*\n\n"
            "You don't have access yet.\n"
            "Use /start to enter your access key.",
            parse_mode="Markdown"
        )
        return

    # Rate limit info
    rl = await db.get_rate_limit(tg_id)
    total_used = rl.get("total_used", 0)
    slot1_used = rl.get("slot1_used", 0)
    slot2_used = rl.get("slot2_used", 0)
    window_start = rl.get("window_start", 0)

    cooldown_remaining = ""
    if total_used >= 10:
        from database.db import COOLDOWN_SECS
        remaining_secs = COOLDOWN_SECS - (int(time.time()) - window_start)
        if remaining_secs > 0:
            hrs = remaining_secs // 3600
            mins = (remaining_secs % 3600) // 60
            cooldown_remaining = f"\n⏳ *Cooldown:* {hrs}h {mins}m remaining"

    custom = user.get("custom_cookies", {})
    acc1 = "✅ Active (Custom)" if custom.get("slot1") else "✅ Active"
    acc2 = "✅ Active (Custom)" if custom.get("slot2") else "✅ Active"

    if is_owner:
        # Owner sees full technical details
        proxy = await db.get_proxy(user.get("proxy_id", ""))
        proxy_label = proxy.get("label", "N/A") if proxy else "N/A"
        text = (
            f"👑 *Owner Profile*\n\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"🆔 TG ID: `{tg_id}`\n"
            f"🖥️ Default Proxy: `{proxy_label}`\n"
            f"━━━━━━━━━━━━━━━━━━\n\n"
            f"💳 *CC Usage (2h window):*\n"
            f"  Premium 1: {slot1_used}/5\n"
            f"  Premium 2: {slot2_used}/5\n"
            f"  Total: {total_used}/10\n"
            f"{cooldown_remaining}"
        )
    else:
        # Regular user — no proxy/technical info
        text = (
            f"👤 *My Profile*\n\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"🆔 TG ID: `{tg_id}`\n"
            f"━━━━━━━━━━━━━━━━━━\n\n"
            f"💳 *CC Check Usage (2h window):*\n"
            f"  Premium 1: {slot1_used}/5\n"
            f"  Premium 2: {slot2_used}/5\n"
            f"  Total: {total_used}/10\n"
            f"{cooldown_remaining}\n\n"
            f"🔐 *My Accounts:*\n"
            f"  💎 Premium 1: {acc1}\n"
            f"  💎 Premium 2: {acc2}"
        )
    await message.answer(text, parse_mode="Markdown")


@router.message(F.text == "📞 Support")
async def support_handler(message: Message):
    await message.answer(
        f"🙋 *Support*\n\n"
        f"For assistance, contact:\n"
        f"💬 {settings.SUPPORT_USERNAME}\n\n"
        f"_Response time: Usually within a few hours._",
        parse_mode="Markdown"
    )


@router.message(Command("help"))
async def help_command(message: Message):
    is_owner = message.from_user.id == settings.OWNER_ID
    owner_section = "\n\n👑 *Owner Commands:*\n`/admin` — Open admin control panel" if is_owner else ""
    await message.answer(
        f"💡 *Commands*\n\n"
        f"`/start` — Start bot / Enter access key\n"
        f"`/help` — Show this help{owner_section}",
        parse_mode="Markdown"
    )
