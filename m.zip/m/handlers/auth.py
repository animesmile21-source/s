from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from states.states import AuthStates
from services.u47_api import U7BuyApiClient
from database import db
from keyboards.reply import get_main_menu

router = Router()

@router.message(Command("login"))
async def login_command(message: Message, state: FSMContext):
    """
    Prompts the user to send their exported U7BUY cookies in JSON format.
    """
    instructions = (
        "🔐 **U7BUY Account Login Instructions**\n\n"
        "Bhai, apne bot me account link karne ke liye niche diye steps follow karein:\n\n"
        "1️⃣ Apne computer browser me (ya mobile me Kiwi Browser me) **[Cookie-Editor Extension](https://chromewebstore.google.com/detail/cookie-editor/hlkenndednhfkbbhocicofopmmjoaici)** install karein.\n"
        "2️⃣ **[u7buy.com](https://www.u7buy.com)** open karein aur login karein.\n"
        "3️⃣ Login hone ke baad browser me **Cookie-Editor Extension** icon par click karein.\n"
        "4️⃣ Niche **Export** button par click karein aur **JSON** option choose karein (Isse aapki cookies clipboard par copy ho jayengi).\n"
        "5️⃣ Wahi copied JSON data yahan chat me paste karke send kar dein.\n\n"
        "⚠️ *Security Note: Aapka data local session me temporary save hota hai aur aapka password kahin share nahi hota.*"
    )
    await message.answer(instructions, parse_mode="Markdown", disable_web_page_preview=True)
    await state.set_state(AuthStates.waiting_for_cookies)

@router.message(AuthStates.waiting_for_cookies)
async def process_cookies(message: Message, state: FSMContext):
    """
    Processes the pasted JSON cookies, validates them, and saves the session.
    """
    cookie_data = message.text
    
    # 1. Delete user message immediately for security (keep cookies out of chat history)
    try:
        await message.delete()
    except Exception:
        # If the bot is not admin in the group, it might fail, but in private chat it works.
        pass
    
    status_msg = await message.answer("🔄 **Verifying session with U7BUY... Please wait.**")
    
    # 2. Validate cookies with U7BUY Api
    client = U7BuyApiClient(cookie_data)
    user_info = await client.validate_session()
    
    if user_info:
        # Success: Save session to JSON DB
        email = user_info.get("email") or user_info.get("username") or "U7BUY User"
        await db.save_user(
            tg_id=message.from_user.id,
            username=message.from_user.username,
            cookies_json=cookie_data,
            logged_in=1
        )
        
        # Delete temporary status message
        try:
            await status_msg.delete()
        except Exception:
            pass
            
        # Send new success message with persistent reply keyboard
        await message.answer(
            f"✅ **Login Successful!**\n\n"
            f"Welcome to the bot, **{email}**!\n"
            f"Ab aap direct catalog browse karke items buy kar sakte hain.",
            reply_markup=get_main_menu()
        )
        await state.clear()
    else:
        # Failure
        await status_msg.edit_text(
            "❌ **Login Failed!**\n\n"
            "Pasted cookies invalid hain ya expire ho chuki hain.\n"
            "Kripya dobara u7buy.com par login karke fresh cookies copy karein aur `/login` bhejkar enter karein."
        )
        await state.clear()
