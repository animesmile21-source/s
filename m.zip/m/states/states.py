from aiogram.fsm.state import State, StatesGroup

class AuthStates(StatesGroup):
    waiting_for_key = State()           # User enters access key
    waiting_for_cookies_slot1 = State() # User updates slot1 cookies
    waiting_for_cookies_slot2 = State() # User updates slot2 cookies

class OrderStates(StatesGroup):
    waiting_for_username = State()
    waiting_for_card_number = State()
    waiting_for_card_expiry = State()
    waiting_for_card_cvc = State()
    waiting_for_card_name = State()
    confirm_purchase = State()

class AdminStates(StatesGroup):
    # Proxy
    add_proxy_input = State()
    remove_proxy_confirm = State()
    # Account
    add_account_select_proxy = State()
    add_account_cookies = State()
    add_account_email = State()
    refresh_account_select = State()
    refresh_account_cookies = State()
    refresh_account_email = State()
    # Keys
    generate_key_select_proxy = State()
    generate_key_duration = State()
    generate_key_note = State()
    # Users
    block_user_input = State()
    broadcast_input = State()
