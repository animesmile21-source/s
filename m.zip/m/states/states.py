from aiogram.fsm.state import State, StatesGroup

class AuthStates(StatesGroup):
    waiting_for_cookies = State()

class OrderStates(StatesGroup):
    browsing_categories = State()
    browsing_products = State()
    waiting_for_username = State()      # Telegram Stars: TG username/ID
    waiting_for_card_number = State()   # Card number (single or multi-card batch)
    waiting_for_card_expiry = State()   # MM/YY expiry
    waiting_for_card_cvc = State()      # CVC/CVV
    waiting_for_card_name = State()     # Cardholder name
    waiting_for_multi_cards = State()   # Multi-card batch input (one per line)
    confirm_purchase = State()
