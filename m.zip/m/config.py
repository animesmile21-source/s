import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # Bot Token (You can set this in environment variables or replace directly)
    BOT_TOKEN: str = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
    
    # List of admin Telegram user IDs (comma-separated or list)
    ADMIN_IDS: list[int] = [int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x] or [123456789]
    
    # Path for local JSON database file (used for testing)
    JSON_DB_PATH: str = "users.json"
    
    # Support Username
    SUPPORT_USERNAME: str = os.getenv("SUPPORT_USERNAME", "@u7buy_support_bot")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

settings = Settings()
