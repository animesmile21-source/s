import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    BOT_TOKEN: str = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")

    # Owner / Admin Telegram ID
    OWNER_ID: int = int(os.getenv("OWNER_ID", "2034253345"))

    # Path for unified JSON database
    JSON_DB_PATH: str = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data.json")

    # Support Username shown to users
    SUPPORT_USERNAME: str = os.getenv("SUPPORT_USERNAME", "@support")

    # Playwright headless mode
    HEADLESS: bool = os.getenv("HEADLESS", "True").strip().lower() in ["true", "1", "yes"]

    # Global proxy URL (can be overridden per-user by proxy pool)
    PROXY_URL: str = os.getenv("PROXY_URL", "")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

settings = Settings()
