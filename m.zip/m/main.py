import asyncio
import logging
import sys
from aiogram import Bot, Dispatcher
from config import settings
from database import db
from handlers import auth, user, order

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

async def main():
    logger.info("Initializing U7BUY Shop Bot...")
    
    # 1. Initialize local JSON database
    await db.init_db()
    
    # 2. Check if Token is configured
    if settings.BOT_TOKEN == "YOUR_BOT_TOKEN_HERE" or not settings.BOT_TOKEN:
        logger.error("BOT_TOKEN is not set in environment or config.py. Please set it before running.")
        return
        
    # 3. Create Bot and Dispatcher
    bot = Bot(token=settings.BOT_TOKEN)
    dp = Dispatcher()
    
    # 4. Include routers (Register handlers)
    dp.include_router(user.router)
    dp.include_router(auth.router)
    dp.include_router(order.router)
    
    logger.info("Bot started successfully. Polling active...")
    
    # 5. Start long polling
    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot execution stopped manually by user.")
    except Exception as e:
        logger.critical(f"Bot crashed with unexpected error: {e}", exc_info=True)
