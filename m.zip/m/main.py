import asyncio
import logging
import sys
from aiogram import Bot, Dispatcher
from config import settings
from database import db
from handlers import auth, user, order
from handlers import admin
from services.cookie_monitor import run_cookie_monitor, run_session_keeper

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)


async def main():
    logger.info("Initializing U7BUY Private Bot...")

    await db.init_db()

    if not settings.BOT_TOKEN or settings.BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        logger.error("BOT_TOKEN not configured in .env")
        return

    bot = Bot(token=settings.BOT_TOKEN)
    dp = Dispatcher()

    # Register routers (order matters: admin first to catch /admin before generic handlers)
    dp.include_router(admin.router)
    dp.include_router(auth.router)
    dp.include_router(user.router)
    dp.include_router(order.router)

    logger.info(f"Bot started. Owner ID: {settings.OWNER_ID}")
    logger.info("Starting Cookie Health Monitor (every 6 hours)...")
    asyncio.create_task(run_cookie_monitor(bot, check_interval_hours=6.0))

    logger.info("Starting Session Keep-Alive + Auto-Refresher (every 4 minutes)...")
    asyncio.create_task(run_session_keeper(bot, interval_minutes=4.0))

    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user.")
    except Exception as e:
        logger.critical(f"Bot crashed: {e}", exc_info=True)
