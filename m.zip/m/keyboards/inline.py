from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

def get_categories_keyboard() -> InlineKeyboardMarkup:
    """
    Returns the categories selection keyboard.
    """
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="🎮 Google Play Gift Cards", callback_data="cat_google_play"))
    builder.row(InlineKeyboardButton(text="⭐ Telegram Stars Top-Up", callback_data="cat_telegram_stars"))
    return builder.as_markup()

def get_products_keyboard(products: list, category: str) -> InlineKeyboardMarkup:
    """
    Dynamically generates a keyboard containing product items.
    """
    builder = InlineKeyboardBuilder()
    
    prefix = "buy_gp_" if category == "google_play" else "buy_ts_"
    
    for prod in products[:25]: # Fetch more items per page
        sku_name = prod.get("skuName", "Product")
        price_str = f"₹{prod.get('skuPrice', 'N/A')}"
        product_id = prod.get("skuId")
        if product_id:
            builder.row(InlineKeyboardButton(
                text=f"{sku_name} - {price_str}", 
                callback_data=f"{prefix}{product_id}"
            ))

    # Add a back button
    builder.row(InlineKeyboardButton(text="⬅️ Back to Categories", callback_data="back_to_categories"))
    return builder.as_markup()

def get_confirmation_keyboard() -> InlineKeyboardMarkup:
    """
    Returns purchase confirmation buttons.
    """
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Confirm Purchase", callback_data="confirm_buy_yes"),
        InlineKeyboardButton(text="❌ Cancel", callback_data="confirm_buy_no")
    )
    return builder.as_markup()

def get_use_saved_username_keyboard(saved_username: str) -> InlineKeyboardMarkup:
    """
    Returns a keyboard containing a button to use the saved target username.
    """
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text=f"👤 Use Saved: {saved_username}", callback_data=f"use_saved_tg_{saved_username}"))
    builder.row(InlineKeyboardButton(text="❌ Enter New / Cancel", callback_data="cancel_saved_tg"))
    return builder.as_markup()
