from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

# ─────────────────────────────────────────────
# Main menu (for users after key activation)
# ─────────────────────────────────────────────
def get_main_menu_inline() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🎮 Google Play Cards", callback_data="cat_google_play"),
        InlineKeyboardButton(text="⭐ Telegram Stars", callback_data="cat_telegram_stars")
    )
    builder.row(
        InlineKeyboardButton(text="👤 My Profile", callback_data="my_profile"),
        InlineKeyboardButton(text="🔑 My Accounts", callback_data="my_accounts")
    )
    return builder.as_markup()

# ─────────────────────────────────────────────
# Categories
# ─────────────────────────────────────────────
def get_categories_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="🎮 Google Play Gift Cards", callback_data="cat_google_play"))
    builder.row(InlineKeyboardButton(text="⭐ Telegram Stars Top-Up", callback_data="cat_telegram_stars"))
    builder.row(InlineKeyboardButton(text="🏠 Back to Menu", callback_data="main_menu"))
    return builder.as_markup()

# ─────────────────────────────────────────────
# Products list
# ─────────────────────────────────────────────
def get_products_keyboard(products: list, category: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    prefix = "buy_gp_" if category == "google_play" else "buy_ts_"
    for prod in products[:24]:
        sku_name = prod.get("skuName", "Product")
        price_str = f"₹{prod.get('skuPrice', 'N/A')}"
        product_id = prod.get("skuId")
        if product_id:
            builder.row(InlineKeyboardButton(
                text=f"{sku_name}  ·  {price_str}",
                callback_data=f"{prefix}{product_id}"
            ))
    builder.row(InlineKeyboardButton(text="⬅️ Back to Categories", callback_data="back_to_categories"))
    return builder.as_markup()

# ─────────────────────────────────────────────
# Confirmation
# ─────────────────────────────────────────────
def get_confirmation_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Confirm & Pay", callback_data="confirm_buy_yes"),
        InlineKeyboardButton(text="❌ Cancel", callback_data="confirm_buy_no")
    )
    return builder.as_markup()

# ─────────────────────────────────────────────
# Saved username reuse
# ─────────────────────────────────────────────
def get_use_saved_username_keyboard(saved_username: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(
        text=f"♻️ Use: {saved_username}",
        callback_data=f"use_saved_tg_{saved_username}"
    ))
    builder.row(InlineKeyboardButton(text="✏️ Enter New", callback_data="cancel_saved_tg"))
    return builder.as_markup()

# ─────────────────────────────────────────────
# My Accounts (user cookie management)
# ─────────────────────────────────────────────
def get_my_accounts_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="🔄 Update Premium 1 Cookies", callback_data="update_cookies_slot1"))
    builder.row(InlineKeyboardButton(text="🔄 Update Premium 2 Cookies", callback_data="update_cookies_slot2"))
    builder.row(InlineKeyboardButton(text="⬅️ Back", callback_data="main_menu"))
    return builder.as_markup()


# ─────────────────────────────────────────────
# OWNER: Proxy selector during purchase
# ─────────────────────────────────────────────
def get_owner_proxy_select(proxies: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for i, p in enumerate(proxies, 1):
        slots = len(p.get("account_slots", []))
        status = "🟢" if p.get("active") else "🔴"
        label = p.get("label", p["id"])
        builder.row(InlineKeyboardButton(
            text=f"{status} Proxy {i} — {label} [{slots}/2]",
            callback_data=f"owner_use_proxy_{p['id']}"
        ))
    builder.row(InlineKeyboardButton(text="🔄 Use My Default Proxy", callback_data="owner_use_proxy_default"))
    return builder.as_markup()

# ─────────────────────────────────────────────
# ADMIN: Main panel
# ─────────────────────────────────────────────
def get_admin_panel() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="🖥️ Proxy Pool", callback_data="admin_proxies"))
    builder.row(InlineKeyboardButton(text="👤 Account Pool", callback_data="admin_accounts"))
    builder.row(InlineKeyboardButton(text="🔑 Access Keys", callback_data="admin_keys"))
    builder.row(InlineKeyboardButton(text="👥 Users", callback_data="admin_users"))
    builder.row(InlineKeyboardButton(text="📊 Orders", callback_data="admin_orders"))
    return builder.as_markup()

# ─────────────────────────────────────────────
# ADMIN: Proxy menu
# ─────────────────────────────────────────────
def get_admin_proxy_menu() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="➕ Add Proxy", callback_data="admin_proxy_add"))
    builder.row(InlineKeyboardButton(text="📋 List Proxies", callback_data="admin_proxy_list"))
    builder.row(InlineKeyboardButton(text="🔍 Test All Proxies", callback_data="admin_proxy_test"))
    builder.row(InlineKeyboardButton(text="⬅️ Back to Admin", callback_data="admin_back"))
    return builder.as_markup()

# ─────────────────────────────────────────────
# ADMIN: Account menu
# ─────────────────────────────────────────────
def get_admin_account_menu() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="➕ Add Account", callback_data="admin_acc_add"))
    builder.row(InlineKeyboardButton(text="📋 List Accounts", callback_data="admin_acc_list"))
    builder.row(InlineKeyboardButton(text="🔄 Refresh Cookies", callback_data="admin_acc_refresh"))
    builder.row(InlineKeyboardButton(text="🗑️ Remove Account", callback_data="admin_acc_remove"))
    builder.row(InlineKeyboardButton(text="⬅️ Back to Admin", callback_data="admin_back"))
    return builder.as_markup()

# ─────────────────────────────────────────────
# ADMIN: Keys menu
# ─────────────────────────────────────────────
def get_admin_keys_menu() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="➕ Generate Key", callback_data="admin_key_gen"))
    builder.row(InlineKeyboardButton(text="📋 List Keys", callback_data="admin_key_list"))
    builder.row(InlineKeyboardButton(text="❌ Revoke Key", callback_data="admin_key_revoke"))
    builder.row(InlineKeyboardButton(text="⬅️ Back to Admin", callback_data="admin_back"))
    return builder.as_markup()

# ─────────────────────────────────────────────
# ADMIN: Users menu
# ─────────────────────────────────────────────
def get_admin_users_menu() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="📋 List Users", callback_data="admin_users_list"))
    builder.row(InlineKeyboardButton(text="🚫 Block User", callback_data="admin_users_block"))
    builder.row(InlineKeyboardButton(text="✅ Unblock User", callback_data="admin_users_unblock"))
    builder.row(InlineKeyboardButton(text="📢 Broadcast", callback_data="admin_broadcast"))
    builder.row(InlineKeyboardButton(text="⬅️ Back to Admin", callback_data="admin_back"))
    return builder.as_markup()

# ─────────────────────────────────────────────
# Dynamic: Proxy selection for key gen / account
# ─────────────────────────────────────────────
def get_proxy_select_keyboard(proxies: list, callback_prefix: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for p in proxies:
        label = p.get("label", p["id"])
        slots_used = len(p.get("account_slots", []))
        text = f"{'🟢' if p.get('active') else '🔴'} {label} [{slots_used}/2 slots]"
        builder.row(InlineKeyboardButton(
            text=text,
            callback_data=f"{callback_prefix}{p['id']}"
        ))
    builder.row(InlineKeyboardButton(text="❌ Cancel", callback_data="admin_back"))
    return builder.as_markup()

# ─────────────────────────────────────────────
# Dynamic: Account selection
# ─────────────────────────────────────────────
def get_account_select_keyboard(accounts: list, callback_prefix: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for a in accounts:
        email = a.get("email", a["id"])
        text = f"📧 {email} [Slot {a.get('slot', '?')}]"
        builder.row(InlineKeyboardButton(
            text=text,
            callback_data=f"{callback_prefix}{a['id']}"
        ))
    builder.row(InlineKeyboardButton(text="❌ Cancel", callback_data="admin_back"))
    return builder.as_markup()
