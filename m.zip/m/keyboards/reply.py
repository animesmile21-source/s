from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove

def get_main_menu() -> ReplyKeyboardMarkup:
    keyboard = [
        [KeyboardButton(text="🛍️ Browse Products"), KeyboardButton(text="👤 My Profile")],
        [KeyboardButton(text="🔑 My Accounts"), KeyboardButton(text="📞 Support")]
    ]
    return ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)

def remove_keyboard() -> ReplyKeyboardRemove:
    return ReplyKeyboardRemove()
