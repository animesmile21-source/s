from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

def get_main_menu() -> ReplyKeyboardMarkup:
    """
    Returns the persistent main menu keyboard.
    """
    keyboard = [
        [KeyboardButton(text="🛍️ Browse Products"), KeyboardButton(text="👤 My Profile")],
        [KeyboardButton(text="🚪 Logout"), KeyboardButton(text="📞 Support")]
    ]
    return ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)
