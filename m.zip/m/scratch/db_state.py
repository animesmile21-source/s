import json
with open('users.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

proxies = data.get('proxies', {})
accounts = data.get('accounts', {})

print('=== PROXIES ===')
for pid, p in proxies.items():
    url = p.get('url','?')[:45]
    label = p.get('label', pid)
    active = p.get('active', False)
    print(f'  [{label}] url={url} active={active}')

print()
print('=== ACCOUNTS ===')
for aid, a in accounts.items():
    has_ck = bool(a.get('cookies_json','').strip())
    email = a.get('email', aid)
    slot = a.get('slot', '?')
    proxy_id = a.get('proxy_id', '?')
    proxy_label = proxies.get(proxy_id, {}).get('label', proxy_id) if proxy_id in proxies else proxy_id
    print(f'  [{email}] slot={slot} proxy=[{proxy_label}] has_cookies={has_ck}')

print()
print(f'Total proxies: {len(proxies)}')
print(f'Total accounts: {len(accounts)}')
