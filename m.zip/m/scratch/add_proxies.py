import asyncio
import sys
sys.path.insert(0, '.')
from database import db

RESIDENTIAL_PROXIES = [
    {"raw": "3364:y0a3zi1hkcd9@p105.instantproxies.com:8937",  "label": "Residential-1 (1.2GB instantproxies)"},
    {"raw": "3350:i63n2pm5Tt2v@p105.instantproxies.com:8927",  "label": "Residential-2 (1GB instantproxies)"},
    {"raw": "207657:qeyWpB6yZ@66.212.23.107:8800",             "label": "Residential-3 (20GB direct)"},
    {"raw": "2906:XANpZWO45A2U@p101.instantproxies.com:9091",  "label": "Residential-4 (20GB instantproxies)"},
    {"raw": "2906:XANpZWO45A2U@p103.instantproxies.com:9090",  "label": "Residential-5 (20GB instantproxies)"},
]

def parse_proxy(raw):
    auth_part, host_part = raw.rsplit("@", 1)
    username, password = auth_part.split(":", 1)
    host, port = host_part.rsplit(":", 1)
    return host, port, username, password

async def main():
    await db.init_db()
    
    # Remove test proxy added earlier if any
    existing = await db.list_proxies()
    for p in existing:
        if "pointtoserver" in p.get("host", "") or p.get("label", "") == "Residential-1":
            # Don't remove real ones already added
            pass

    print("Adding residential proxies from proxies.text...\n")
    for item in RESIDENTIAL_PROXIES:
        host, port, user, pwd = parse_proxy(item["raw"])
        added = await db.add_proxy(host, port, user, pwd, protocol="http", label=item["label"])
        pid = added["id"]
        url = added["url"]
        print(f"[OK] {pid}")
        print(f"     Label : {item['label']}")
        print(f"     Host  : {host}:{port}")
        print(f"     User  : {user}")
        print()

    all_proxies = await db.list_proxies()
    print(f"Total proxies in DB: {len(all_proxies)}")
    print("\nDone! Cookies baad mein /admin se add kar lena.")

asyncio.run(main())
