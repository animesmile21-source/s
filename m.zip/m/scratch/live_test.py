"""Live test with the actual fresh session data"""
import sys, os, asyncio, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

SESSION_JSON = r"""{"user": "{\"state\":{\"userInfo\":{\"accessToken\":\"u7buy_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOiJtZW1iZXJfdXNlcjoyMDc2NTY1NDMwNjI4MjA0NTQ1Iiwicm5TdHIiOiI0UWplWWg1aUNvMHhPSUZDektWM1pXdlRIV1ZXWUl3NiIsInVpZCI6MjA3NjU2NTQzMDYyODIwNDU0NSwiY2xpZW50aWQiOiI5NGY2NzBjOTU0MTgyZTljMzA1MzVmYTljYWQzNTk4MyIsInJlZnJlc2hUb2tlbiI6ImFsVDVjazBSdkFyZG1CU3E2SkFQbzdMREYxeWk3NXMzR1YzeFFVanhFV1VRRFBzdldGdzdDMzlzaWdNY21adlZfTWpBM05qVTJOVFF6TURZeU9ESXdORFUwTlE9PSJ9.IPn_Fyk37bi0XJj5BYDy35ghMEow0HjjUMXjFVJo4eQ\",\"email\":null,\"phone\":null,\"refreshToken\":\"alT5ck0RvArdmBSq6JAPo7LDF1yi75s3GV3xQUjxEWUQDPsvWFw7C39sigMcmZvV_MjA3NjU2NTQzMDYyODIwNDU0NQ==\"}}}", "cookies": "_ga=GA1.1.1044961325.1783926620; cookieyes-consent=consentid:SzRrOXRnSGlxS2VYZExscWNzZm42ekxybFVQR0hmbGM,consent:yes,action:no,necessary:yes,functional:yes,analytics:yes,performance:yes,advertisement:yes,other:yes; g_state={\"i_l\":0,\"i_ll\":1783926656962}; __stripe_mid=bc6b85a7-3198-4d3a-99bd-94d2861426622bfcc3; nuxt-color-mode=system; u7CookieConfig=%7B%22state%22%3A%7B%22defaultCurrency%22%3A%22INR%22%2C%22accessToken%22%3A%22u7buy_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOiJtZW1iZXJfdXNlcjoyMDc2NTY1NDMwNjI4MjA0NTQ1Iiwicm5TdHIiOiJ3bnBURENNYU04UFA2RmtobU5pR3hGR1h2SUliUFIzZCIsInVpZCI6MjA3NjU2NTQzMDYyODIwNDU0NSwiY2xpZW50aWQiOiI5NGY2NzBjOTU0MTgyZTljMzA1MzVmYTljYWQzNTk4MyIsInJlZnJlc2hUb2tlbiI6ImFsVDVjazBSdkFyZG1CU3E2SkFQbzdMREYxeWk3NXMzR1YzeFFVanhFV1VRRFBzdldGdzdDMzlzaWdNY21adlZfTWpBM05qVTJOVFF6TURZeU9ESXdORFUwTlE9PSJ9.snNIZ_hjsvLSfUFMQLom6mm4Pez1DADL_8jrU78JDqY%22%2C%22refreshToken%22%3A%22alT5ck0RvArdmBSq6JAPo7LDF1yi75s3GV3xQUjxEWUQDPsvWFw7C39sigMcmZvV_MjA3NjU2NTQzMDYyODIwNDU0NQ%3D%3D%22%7D%7D; _clck=2t7gzf%5E2%5Eg7t%5E0%5E2385; _uetsid=2e6e24b081cd11f18fb50976660f0325; _uetvid=e84ef7a07e8911f1b16d0515d8c34745; _gcl_au=1.1.1204910484.1783926429; _clsk=cc6a83%5E1784285478545%5E14%5E1%5Ey.clarity.ms%2Fcollect; __stripe_sid=9d0b250f-810d-4f63-8e61-d041167fc5a0d83e4a"}"""

async def main():
    from services.u47_api import U7BuyApiClient
    
    print("=" * 55)
    print("LIVE SESSION TEST — Teri fresh cookies se")
    print("Cookies di thi: ~2.5 ghante pehle (16:14 IST)")
    print("Current time:   18:50 IST")
    print("=" * 55)
    
    client = U7BuyApiClient(SESSION_JSON)
    print(f"access_token:  {client.access_token[:40]}...")
    print(f"__cf_bm before: {client.cookies_dict.get('__cf_bm', 'NOT PRESENT')}")
    print()
    print("Calling validate_session()...")
    
    t0 = time.time()
    result = await client.validate_session()
    elapsed = time.time() - t0
    
    print(f"Response time: {elapsed:.2f}s")
    print(f"__cf_bm after:  {client.cookies_dict.get('__cf_bm', 'NOT RECEIVED')[:40] if client.cookies_dict.get('__cf_bm') else 'NOT RECEIVED'}")
    print()
    
    if result:
        print("RESULT: SESSION ALIVE")
        print(f"Data: {str(result)[:200]}")
    else:
        print("RESULT: SESSION DEAD (2.5 ghante mein expire ho gayi)")

asyncio.run(main())
