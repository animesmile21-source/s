"""
HttpOnly Cookie Detector
Checks which cookies from your export are missing (those are likely HttpOnly).
Run: python scratch/check_httponly.py
"""
import json, urllib.parse, sys, os

EXPORTED_COOKIES = """_ga=GA1.1.1044961325.1783926620; cookieyes-consent=consentid:SzRrOXRnSGlxS2VYZExscWNzZm42ekxybFVQR0hmbGM,consent:yes,action:no,necessary:yes,functional:yes,analytics:yes,performance:yes,advertisement:yes,other:yes; g_state={"i_l":0}; __stripe_mid=bc6b85a7-3198-4d3a-99bd-94d2861426622bfcc3; nuxt-color-mode=system; u7CookieConfig=%7B%22state%22%3A%7B%22defaultCurrency%22%3A%22INR%22%7D%7D; _clck=2t7gzf; _uetsid=2e6e24b0; _uetvid=e84ef7a0; _ga_1KFBC8P097=GS2.1; _gcl_au=1.1.1204910484; _clsk=cc6a83; __stripe_sid=9d0b250f"""

print("=" * 60)
print("COOKIES YOU EXPORTED (visible / non-HttpOnly):")
print("=" * 60)

visible = {}
for item in EXPORTED_COOKIES.split(";"):
    item = item.strip()
    if "=" in item:
        k, v = item.split("=", 1)
        visible[k.strip()] = v.strip()

for name in visible:
    print(f"  {name}")

print()
print("=" * 60)
print("POSSIBLE MISSING HttpOnly cookies:")
print("(Common SaToken / Java backend session cookies)")
print("=" * 60)

common_httponly = [
    "JSESSIONID",
    "SESSION",
    "satoken",
    "sa-token",
    "satoken-login",
    "token",
    "Authorization",
    "X-Token",
    "XSRF-TOKEN",
    "csrf-token",
]

for name in common_httponly:
    if name.lower() not in [k.lower() for k in visible]:
        print(f"  POSSIBLY MISSING: {name}")

print()
print("=" * 60)
print("HOW TO CHECK:")
print("  1. Open u7buy.com (logged in)")
print("  2. F12 → Application → Cookies → https://www.u7buy.com")
print("  3. Look for cookies with 'HttpOnly' checkbox ticked")
print("  4. If you see any HttpOnly cookie NOT in your export above,")
print("     that is why the bot's session expires!")
print()
print("  SOLUTION: Install 'Cookie-Editor' Chrome Extension")
print("  It exports ALL cookies including HttpOnly ones.")
print("=" * 60)
