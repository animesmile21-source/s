"""
Quick test: Verify refreshToken is extracted correctly from the session data.
Run: python scratch/test_refresh_token.py
"""
import sys
import os
import json
import base64

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# ── Paste your session data here (the JSON you shared) ──
SAMPLE_SESSION = r"""
{
  "user": "{\"state\":{\"userInfo\":{\"accessToken\":\"u7buy_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOiJtZW1iZXJfdXNlcjoyMDc2NTY1NDMwNjI4MjA0NTQ1Iiwicm5TdHIiOiI0UWplWWg1aUNvMHhPSUZDektWM1pXdlRIV1ZXWUl3NiIsInVpZCI6MjA3NjU2NTQzMDYyODIwNDU0NSwiY2xpZW50aWQiOiI5NGY2NzBjOTU0MTgyZTljMzA1MzVmYTljYWQzNTk4MyIsInJlZnJlc2hUb2tlbiI6ImFsVDVjazBSdkFyZG1CU3E2SkFQbzdMREYxeWk3NXMzR1YzeFFVanhFV1VRRFBzdldGdzdDMzlzaWdNY21adlZfTWpBM05qVTJOVFF6TURZeU9ESXdORFUwTlE9PSJ9.IPn_Fyk37bi0XJj5BYDy35ghMEow0HjjUMXjFVJo4eQ\",\"email\":null,\"phone\":null,\"refreshToken\":\"alT5ck0RvArdmBSq6JAPo7LDF1yi75s3GV3xQUjxEWUQDPsvWFw7C39sigMcmZvV_MjA3NjU2NTQzMDYyODIwNDU0NQ==\"}}}",
  "cookies": "_ga=GA1.1.1044961325.1783926620; u7CookieConfig=%7B%22state%22%3A%7B%22defaultCurrency%22%3A%22INR%22%2C%22accessToken%22%3A%22u7buy_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOiJtZW1iZXJfdXNlcjoyMDc2NTY1NDMwNjI4MjA0NTQ1Iiwicm5TdHIiOiJ3bnBURENNYU04UFA2RmtobU5pR3hGR1h2SUliUFIzZCIsInVpZCI6MjA3NjU2NTQzMDYyODIwNDU0NSwiY2xpZW50aWQiOiI5NGY2NzBjOTU0MTgyZTljMzA1MzVmYTljYWQzNTk4MyIsInJlZnJlc2hUb2tlbiI6ImFsVDVjazBSdkFyZG1CU3E2SkFQbzdMREYxeWk3NXMzR1YzeFFVanhFV1VRRFBzdldGdzdDMzlzaWdNY21adlZfTWpBM05qVTJOVFF6TURZeU9ESXdORFUwTlE9PSJ9.snNIZ_hjsvLSfUFMQLom6mm4Pez1DADL_8jrU78JDqY%22%2C%22refreshToken%22%3A%22alT5ck0RvArdmBSq6JAPo7LDF1yi75s3GV3xQUjxEWUQDPsvWFw7C39sigMcmZvV_MjA3NjU2NTQzMDYyODIwNDU0NQ%3D%3D%22%7D%7D"
}
"""

def decode_jwt(token):
    raw = token
    if raw.startswith("u7buy_"):
        raw = raw[6:]
    parts = raw.split(".")
    if len(parts) < 2:
        return {}
    pad = parts[1] + "=" * ((4 - len(parts[1]) % 4) % 4)
    return json.loads(base64.urlsafe_b64decode(pad))

print("=" * 60)
print("Testing refreshToken extraction...")
print("=" * 60)

from services.u47_api import U7BuyApiClient

client = U7BuyApiClient(SAMPLE_SESSION)

print(f"\n[OK] access_token found:   {bool(client.access_token)}")
print(f"[OK] refresh_token found:  {bool(client.refresh_token)}")

if client.access_token:
    payload = decode_jwt(client.access_token)
    import time
    exp = payload.get("exp", 0)
    hours_left = (exp - time.time()) / 3600 if exp else -1
    print(f"\nJWT Payload:")
    print(f"   loginId:      {payload.get('loginId')}")
    print(f"   uid:          {payload.get('uid')}")
    print(f"   hours_left:   {hours_left:.2f}h")
    rt_in_jwt = payload.get("refreshToken", "")
    print(f"   refreshToken in JWT: {rt_in_jwt[:30]}..." if rt_in_jwt else "   refreshToken in JWT: MISSING!")

print(f"\nREFRESH TOKEN: {client.refresh_token[:40]}..." if client.refresh_token else "\n[FAIL] client.refresh_token: EMPTY!")
print(f"currency: {client.currency}")

print("\n" + "=" * 60)
print("If REFRESH TOKEN found above, auto-refresh will work!")
print("=" * 60)
