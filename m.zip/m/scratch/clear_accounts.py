"""Clear all accounts from data.json and show current proxy/account state"""
import json, os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data.json")

with open(DB_PATH, 'r', encoding='utf-8') as f:
    data = json.load(f)

proxies = data.get('proxies', {})
accounts = data.get('accounts', {})

print('=== CURRENT STATE ===')
print(f'Proxies: {len(proxies)}')
print(f'Accounts: {len(accounts)}')
print()
for pid, p in proxies.items():
    print(f'  [{p.get("label",pid)}] slots={p.get("account_slots",[])} active={p.get("active")}')
for aid, a in accounts.items():
    has_ck = bool(a.get('cookies_json','').strip())
    print(f'  ACC [{a.get("email",aid)}] slot={a.get("slot")} proxy={a.get("proxy_id")} cookies={has_ck}')

print()
print('=== CLEARING ALL ACCOUNTS ===')

# Clear all accounts
data['accounts'] = {}

# Reset all proxy account_slots
for pid in data['proxies']:
    data['proxies'][pid]['account_slots'] = []

# Also clear account_checks (rate limit tracking)
data.pop('account_checks', None)

with open(DB_PATH, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2, ensure_ascii=False)

print(f'Done! Cleared {len(accounts)} accounts')
print('All proxy slots reset to []')
print('All account_checks cleared')
print()
print('=== PROXIES REMAINING ===')
for pid, p in data['proxies'].items():
    print(f'  [{p.get("label",pid)}] active={p.get("active")} url={p.get("url","?")[:50]}')
