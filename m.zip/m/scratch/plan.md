# Implementation Plan

## Requirements:
1. Clear all cookies from users.json (done separately)
2. Owner ko SIRF success + error messages aayein (CC details ke saath) - NO "failed" spam for each card attempt during rotation
3. TXT file se bhi limit 10 (users ke liye) - ALREADY IMPLEMENTED (line 674-676)
4. Owner unlimited - account rotation: 5 per account, rotate circular (acc1→acc2→...→wrap back to acc1)
5. Random realistic cardholder name when name = "CARD HOLDER" default

## Changes needed in order.py:

### A. Random cardholder name (parse_one_line_card & parse_robust_card)
- Replace "CARD HOLDER" default with random name from list

### B. Owner account rotation - circular 5-per-account
- Currently: sorts by least used, stops when all exhausted
- Need: circular rotation - acc1 (5 checks) → acc2 (5 checks) → ... → wrap to acc1
- Each account has its own 5-check limit tracked via increment_account_check

### C. Owner notifications:
- REMOVE: _notify_owner_error for regular "failed/card_declined" per attempt (currently fires on each card attempt rotation)
- KEEP: Only send 1 final message at end:
  - If SUCCESS → send success with full CC details (already done)
  - If final FAIL → send ONE error message with CC details at the very end
  - For fraud_declined, captcha, timeout, session_error → keep those special alerts

### D. Users.json cookies clear - done via separate step
