"""
Quick check: Are these 4 fresh cookie sets still alive?
"""
import sys, os, asyncio
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

SESSIONS = {
    "ofdipsip@sendapp.uk": r"""{"user": "{\"state\":{\"userInfo\":{\"signInFlag\":0,\"accessToken\":\"u7buy_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOiJtZW1iZXJfdXNlcjoyMDc4MTE0NjU3MDEzNTg3OTcwIiwicm5TdHIiOiJublF1UVNMZHp1U3RYbzU0RW1KbWk3NjE1MXhOdTY2ZSIsInVpZCI6MjA3ODExNDY1NzAxMzU4Nzk3MCwiY2xpZW50aWQiOiI5NGY2NzBjOTU0MTgyZTljMzA1MzVmYTljYWQzNTk4MyIsInJlZnJlc2hUb2tlbiI6IjNjOHUzekJZYTA1ek5NYzcyNUJkVVBJTlo1N3FYRExBYWxBNmxicDF1cHJuekNBZmE1cTRkSEdXemVIWE1Gb2ZfTWpBM09ERXhORFkxTnpBeE16VTROemszTUE9PSJ9.CaEH3MA79XUQX1YZ7tSFgbrRIgsRGO75ZucsBcadqso\",\"refreshToken\":\"3c8u3zBYa05zNMc725BdUPINZ57qXDLAalA6lbp1uprnzCAfa5q4dHGWzeHXMFof_MjA3ODExNDY1NzAxMzU4Nzk3MA==\"}}}", "cookies": "_ga=GA1.1.1044961325.1783926620; u7CookieConfig=%7B%22state%22%3A%7B%22defaultCurrency%22%3A%22INR%22%2C%22accessToken%22%3A%22u7buy_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOiJtZW1iZXJfdXNlcjoyMDc4MTE0NjU3MDEzNTg3OTcwIiwicm5TdHIiOiJublF1UVNMZHp1U3RYbzU0RW1KbWk3NjE1MXhOdTY2ZSIsInVpZCI6MjA3ODExNDY1NzAxMzU4Nzk3MCwiY2xpZW50aWQiOiI5NGY2NzBjOTU0MTgyZTljMzA1MzVmYTljYWQzNTk4MyIsInJlZnJlc2hUb2tlbiI6IjNjOHUzekJZYTA1ek5NYzcyNUJkVVBJTlo1N3FYRExBYWxBNmxicDF1cHJuekNBZmE1cTRkSEdXemVIWE1Gb2ZfTWpBM09ERXhORFkxTnpBeE16VTROemszTUE9PSJ9.CaEH3MA79XUQX1YZ7tSFgbrRIgsRGO75ZucsBcadqso%22%7D%7D"}""",

    "n*w@owleyes.ch": r"""{"user": "{\"state\":{\"userInfo\":{\"signInFlag\":0,\"accessToken\":\"u7buy_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOiJtZW1iZXJfdXNlcjoyMDc4MTE0MTcyNTY1MTQzNTU0Iiwicm5TdHIiOiI0Z015SHpPb2dkMnZIckxnVDdzb0RsVHRRWEFnZENlcyIsInVpZCI6MjA3ODExNDE3MjU2NTE0MzU1NCwiY2xpZW50aWQiOiI5NGY2NzBjOTU0MTgyZTljMzA1MzVmYTljYWQzNTk4MyIsInJlZnJlc2hUb2tlbiI6InVtZTBKVnQwNmpiNTU3cE1yVUZieEhYWEgwSWRINElLcFJGR0FpcDRMVERZUTZFNHVEU3VsblNxREJkYXBWdmJfTWpBM09ERXhOREUzTWpVMk5URTBNelUxTkE9PSJ9._4gGizrmQMNq1piDQ9_3FP455m11zTVXPpBCUd_j2_8\",\"refreshToken\":\"ume0JVt06jb557pMrUFbxHXXH0IdH4IKpRFGAip4LTDYQ6E4uDSulnSqDBdapVvb_MjA3ODExNDE3MjU2NTE0MzU1NA==\"}}}", "cookies": "_ga=GA1.1.1044961325.1783926620; u7CookieConfig=%7B%22state%22%3A%7B%22defaultCurrency%22%3A%22INR%22%2C%22accessToken%22%3A%22u7buy_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOiJtZW1iZXJfdXNlcjoyMDc4MTE0MTcyNTY1MTQzNTU0Iiwicm5TdHIiOiI0Z015SHpPb2dkMnZIckxnVDdzb0RsVHRRWEFnZENlcyIsInVpZCI6MjA3ODExNDE3MjU2NTE0MzU1NCwiY2xpZW50aWQiOiI5NGY2NzBjOTU0MTgyZTljMzA1MzVmYTljYWQzNTk4MyIsInJlZnJlc2hUb2tlbiI6InVtZTBKVnQwNmpiNTU3cE1yVUZieEhYWEgwSWRINElLcFJGR0FpcDRMVERZUTZFNHVEU3VsblNxREJkYXBWdmJfTWpBM09ERXhOREUzTWpVMk5URTBNelUxTkE9PSJ9._4gGizrmQMNq1piDQ9_3FP455m11zTVXPpBCUd_j2_8%22%7D%7D"}""",

    "w*7@neko2.net": r"""{"user": "{\"state\":{\"userInfo\":{\"signInFlag\":0,\"accessToken\":\"u7buy_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOiJtZW1iZXJfdXNlcjoyMDc3MzEwNjI4MDYyODE0MjA5Iiwicm5TdHIiOiI2emI1ZVRHTFVER1U5WmgzcVZEYmJmQThSZXdoZkxpMCIsInVpZCI6MjA3NzMxMDYyODA2MjgxNDIwOSwiY2xpZW50aWQiOiI5NGY2NzBjOTU0MTgyZTljMzA1MzVmYTljYWQzNTk4MyIsInJlZnJlc2hUb2tlbiI6InJldmdmd1ZudlJQakxXVTZwajMwb0lhMlhSREZpVXFveTkzUG9HMlU4MDFWSGRlTHk5dnRRR1BIdG9tR1R2Z05fTWpBM056TXhNRFl5T0RBMk1qZ3hOREl3T1E9PSJ9.PbsZJQRz_Ar2qpEdGrKMVbV3Grebpra7NGacQuQe9Jg\",\"refreshToken\":\"revgfwVnvRPjLWU6pj30oIa2XRDFiUqoy93PoG2U801VHdeLy9vtQGPHtomGTvgN_MjA3NzMxMDYyODA2MjgxNDIwOQ==\"}}}", "cookies": "_ga=GA1.1.1044961325.1783926620; u7CookieConfig=%7B%22state%22%3A%7B%22defaultCurrency%22%3A%22INR%22%2C%22accessToken%22%3A%22u7buy_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOiJtZW1iZXJfdXNlcjoyMDc3MzEwNjI4MDYyODE0MjA5Iiwicm5TdHIiOiI2emI1ZVRHTFVER1U5WmgzcVZEYmJmQThSZXdoZkxpMCIsInVpZCI6MjA3NzMxMDYyODA2MjgxNDIwOSwiY2xpZW50aWQiOiI5NGY2NzBjOTU0MTgyZTljMzA1MzVmYTljYWQzNTk4MyIsInJlZnJlc2hUb2tlbiI6InJldmdmd1ZudlJQakxXVTZwajMwb0lhMlhSREZpVXFveTkzUG9HMlU4MDFWSGRlTHk5dnRRR1BIdG9tR1R2Z05fTWpBM056TXhNRFl5T0RBMk1qZ3hOREl3T1E9PSJ9.PbsZJQRz_Ar2qpEdGrKMVbV3Grebpra7NGacQuQe9Jg%22%7D%7D"}""",

    "r*3@sendnow.win": r"""{"user": "{\"state\":{\"userInfo\":{\"signInFlag\":0,\"accessToken\":\"u7buy_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOiJtZW1iZXJfdXNlcjoyMDc3MzExMTgzNDQxMDUxNjQ5Iiwicm5TdHIiOiIwZENzUFozemgxamtVU1FYR1dyVVhSV0ZJV0FGRVh0bSIsInVpZCI6MjA3NzMxMTE4MzQ0MTA1MTY0OSwiY2xpZW50aWQiOiI5NGY2NzBjOTU0MTgyZTljMzA1MzVmYTljYWQzNTk4MyIsInJlZnJlc2hUb2tlbiI6IjhveGRUSEQ5cmswZXgwNXc0Mnh2NzZ3RG9LTmxwSjRNWTlCUWxjWGJUZmY2WGdtelVnY0I3aUwwTkFkRkFZR0VfTWpBM056TXhNVEU0TXpRME1UQTFNVFkwT1E9PSJ9.C3yLLz82JdiZpdfzVxfZE_ex9PBxaDdqWfSAEegbdac\",\"refreshToken\":\"8oxdTHD9rk0ex05w42xv76wDoKNlpJ4MY9BQlcXbTff6XgmzUgcB7iL0NAdFAYGE_MjA3NzMxMTE4MzQ0MTA1MTY0OQ==\"}}}", "cookies": "_ga=GA1.1.1044961325.1783926620; u7CookieConfig=%7B%22state%22%3A%7B%22defaultCurrency%22%3A%22INR%22%2C%22accessToken%22%3A%22u7buy_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOiJtZW1iZXJfdXNlcjoyMDc3MzExMTgzNDQxMDUxNjQ5Iiwicm5TdHIiOiIwZENzUFozemgxamtVU1FYR1dyVVhSV0ZJV0FGRVh0bSIsInVpZCI6MjA3NzMxMTE4MzQ0MTA1MTY0OSwiY2xpZW50aWQiOiI5NGY2NzBjOTU0MTgyZTljMzA1MzVmYTljYWQzNTk4MyIsInJlZnJlc2hUb2tlbiI6IjhveGRUSEQ5cmswZXgwNXc0Mnh2NzZ3RG9LTmxwSjRNWTlCUWxjWGJUZmY2WGdtelVnY0I3aUwwTkFkRkFZR0VfTWpBM056TXhNVEU0TXpRME1UQTFNVFkwT1E9PSJ9.C3yLLz82JdiZpdfzVxfZE_ex9PBxaDdqWfSAEegbdac%22%7D%7D"}"""
}

async def check(email, session_str):
    from services.u47_api import U7BuyApiClient
    client = U7BuyApiClient(session_str)
    result = await client.validate_session()
    status = "ALIVE [OK]" if result else "DEAD [FAIL]"
    print(f"  {email:30s} -> {status}")

async def main():
    print("=" * 55)
    print("Checking 4 fresh cookie sessions...")
    print("=" * 55)
    for email, sess in SESSIONS.items():
        await check(email, sess)
    print("=" * 55)

asyncio.run(main())
