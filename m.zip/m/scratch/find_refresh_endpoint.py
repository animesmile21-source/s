"""
LIVE REFRESH ENDPOINT TESTER
Tests all known U7Buy refresh endpoints with REAL refresh token.
Run: python scratch/find_refresh_endpoint.py
"""
import sys, os, asyncio, json, base64
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# ── Paste your FULL session JSON here ──
SESSION_JSON = r"""
{
  "user": "{\"state\":{\"userInfo\":{\"accessToken\":\"u7buy_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOiJtZW1iZXJfdXNlcjoyMDc2NTY1NDMwNjI4MjA0NTQ1Iiwicm5TdHIiOiI0UWplWWg1aUNvMHhPSUZDektWM1pXdlRIV1ZXWUl3NiIsInVpZCI6MjA3NjU2NTQzMDYyODIwNDU0NSwiY2xpZW50aWQiOiI5NGY2NzBjOTU0MTgyZTljMzA1MzVmYTljYWQzNTk4MyIsInJlZnJlc2hUb2tlbiI6ImFsVDVjazBSdkFyZG1CU3E2SkFQbzdMREYxeWk3NXMzR1YzeFFVanhFV1VRRFBzdldGdzdDMzlzaWdNY21adlZfTWpBM05qVTJOVFF6TURZeU9ESXdORFUwTlE9PSJ9.IPn_Fyk37bi0XJj5BYDy35ghMEow0HjjUMXjFVJo4eQ\",\"email\":null,\"phone\":null,\"refreshToken\":\"alT5ck0RvArdmBSq6JAPo7LDF1yi75s3GV3xQUjxEWUQDPsvWFw7C39sigMcmZvV_MjA3NjU2NTQzMDYyODIwNDU0NQ==\"}}}",
  "cookies": "_ga=GA1.1.1044961325.1783926620; u7CookieConfig=%7B%22state%22%3A%7B%22defaultCurrency%22%3A%22INR%22%2C%22accessToken%22%3A%22u7buy_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOiJtZW1iZXJfdXNlcjoyMDc2NTY1NDMwNjI4MjA0NTQ1Iiwicm5TdHIiOiJ3bnBURENNYU04UFA2RmtobU5pR3hGR1h2SUliUFIzZCIsInVpZCI6MjA3NjU2NTQzMDYyODIwNDU0NSwiY2xpZW50aWQiOiI5NGY2NzBjOTU0MTgyZTljMzA1MzVmYTljYWQzNTk4MyIsInJlZnJlc2hUb2tlbiI6ImFsVDVjazBSdkFyZG1CU3E2SkFQbzdMREYxeWk3NXMzR1YzeFFVanhFV1VRRFBzdldGdzdDMzlzaWdNY21adlZfTWpBM05qVTJOVFF6TURZeU9ESXdORFUwTlE9PSJ9.snNIZ_hjsvLSfUFMQLom6mm4Pez1DADL_8jrU78JDqY%22%2C%22refreshToken%22%3A%22alT5ck0RvArdmBSq6JAPo7LDF1yi75s3GV3xQUjxEWUQDPsvWFw7C39sigMcmZvV_MjA3NjU2NTQzMDYyODIwNDU0NQ%3D%3D%22%7D%7D"
}
"""

BASE_URL = "https://www.u7buy.com"

async def test_refresh_endpoints():
    from services.u47_api import U7BuyApiClient
    client = U7BuyApiClient(SESSION_JSON)

    refresh_token = client.refresh_token
    access_token = client.access_token

    print("=" * 65)
    print("LIVE REFRESH ENDPOINT TESTER")
    print("=" * 65)
    print(f"access_token:  {access_token[:40]}...")
    print(f"refresh_token: {refresh_token[:40]}...")
    print()

    # All candidate endpoints
    attempts = [
        ("POST", f"{BASE_URL}/prod-api/member/login/doRefreshToken", {"refreshToken": refresh_token}),
        ("POST", f"{BASE_URL}/prod-api/app/getNewToken",             {"refreshToken": refresh_token}),
        ("POST", f"{BASE_URL}/prod-api/auth/refreshToken",           {"refreshToken": refresh_token}),
        ("POST", f"{BASE_URL}/prod-api/member/login/refreshToken",   {"refreshToken": refresh_token}),
        ("POST", f"{BASE_URL}/prod-api/auth/refresh",                {"refreshToken": refresh_token}),
        ("POST", f"{BASE_URL}/prod-api/member/userAuth/refreshToken",{"refreshToken": refresh_token}),
        # SaToken standard endpoints
        ("POST", f"{BASE_URL}/prod-api/user/refresh",                {"refreshToken": refresh_token}),
        ("POST", f"{BASE_URL}/prod-api/member/token/refresh",        {"refreshToken": refresh_token}),
        # GET variants
        ("GET",  f"{BASE_URL}/prod-api/member/login/doRefreshToken", {"refreshToken": refresh_token}),
        ("GET",  f"{BASE_URL}/prod-api/app/getNewToken",             {"refreshToken": refresh_token}),
    ]

    winner = None
    for method, url, body in attempts:
        try:
            if method == "POST":
                r = await client._request("POST", url, json=body, timeout=8)
            else:
                r = await client._request("GET", url, params=body, timeout=8)

            status_icon = "[PASS]" if r.status_code == 200 else "[FAIL]"
            try:
                rj = r.json()
                code = rj.get("code", "?")
                msg_short = str(rj)[:120]
            except Exception:
                code = "??"
                msg_short = r.text[:120]

            print(f"{status_icon} {method:4} {url.split('/prod-api')[1]:45} HTTP={r.status_code} code={code}")

            if r.status_code == 200 and rj.get("code") == 200:
                print(f"         FULL RESPONSE: {msg_short}")
                winner = (method, url, rj)
                break
            elif r.status_code not in (404, 405):
                # Any non-404/405 response worth showing
                print(f"         RESPONSE: {msg_short}")

        except Exception as e:
            print(f"[ERR]  {method:4} {url.split('/prod-api')[1]:45} ERROR: {str(e)[:60]}")

    print()
    print("=" * 65)
    if winner:
        method, url, resp = winner
        print(f"SUCCESS! Working endpoint found:")
        print(f"  Method: {method}")
        print(f"  URL:    {url}")
        print(f"  Data:   {json.dumps(resp.get('data', {}), indent=2)[:300]}")
    else:
        print("No working refresh endpoint found.")
        print()
        print("ALTERNATIVE: Check if validate_session still works (is session alive?)")
        try:
            session_data = await client.validate_session()
            if session_data:
                print(f"  validate_session: ALIVE - uid={session_data.get('uid', session_data.get('memberInfo', {}).get('uid', '?'))}")
            else:
                print("  validate_session: DEAD (session already expired)")
        except Exception as e:
            print(f"  validate_session: ERROR: {e}")
    print("=" * 65)


asyncio.run(test_refresh_endpoints())
