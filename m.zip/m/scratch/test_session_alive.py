"""
SESSION ALIVE TEST — Continuously pings validate_session every 4 min
Run: python scratch/test_session_alive.py
Press Ctrl+C to stop
Shows EXACTLY what the bot's session keeper does
"""
import sys, os, asyncio, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# Paste your latest session JSON here
SESSION_JSON = r"""PASTE_YOUR_SESSION_JSON_HERE"""

async def run_test():
    from services.u47_api import U7BuyApiClient

    attempt = 0
    consecutive_failures = 0
    start_time = time.time()

    print("=" * 55)
    print("SESSION ALIVE TESTER")
    print("Pinging U7Buy every 4 min — same as bot does")
    print("Press Ctrl+C to stop")
    print("=" * 55)

    while True:
        attempt += 1
        elapsed_hours = (time.time() - start_time) / 3600
        now_str = time.strftime("%H:%M:%S")

        try:
            client = U7BuyApiClient(SESSION_JSON)
            session_data = await client.validate_session()

            if session_data:
                consecutive_failures = 0
                print(f"[{now_str}] #{attempt} ALIVE ({elapsed_hours:.2f}h elapsed)")
            else:
                consecutive_failures += 1
                print(f"[{now_str}] #{attempt} DEAD! ({elapsed_hours:.2f}h elapsed) — consecutive failures: {consecutive_failures}")
                if consecutive_failures >= 3:
                    print(f"\n*** SESSION CONFIRMED DEAD after {elapsed_hours:.2f} hours ***")
                    print("Cookies need to be refreshed manually.")
                    break

        except Exception as e:
            print(f"[{now_str}] #{attempt} ERROR: {e}")

        await asyncio.sleep(4 * 60)   # Wait 4 minutes

asyncio.run(run_test())
