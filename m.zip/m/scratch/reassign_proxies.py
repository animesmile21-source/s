import asyncio
import sys
sys.path.insert(0, '.')
from database import db

async def main():
    await db.init_db()
    
    # 1. Fetch all accounts and proxies
    accounts = await db.list_all_accounts()
    proxies = await db.list_proxies()
    
    # Filter PureVPN (working) and InstantProxies (expired)
    purevpn_proxies = [p for p in proxies if "PureVPN" in p.get("label", "")]
    expired_proxies = [p for p in proxies if "instantproxies" in p.get("host", "") or "66.212.23.107" in p.get("host", "")]
    
    print(f"Total Accounts: {len(accounts)}")
    print(f"Active Working PureVPN Proxies: {len(purevpn_proxies)}")
    print(f"Expired/Broken Proxies to remove: {len(expired_proxies)}")
    
    # 2. Re-assign accounts to new PureVPN proxies (max 2 accounts per proxy)
    proxy_index = 0
    assigned_counts = {}  # proxy_id -> count
    
    db_data = db._load()
    
    for account in accounts:
        acc_id = account["id"]
        email = account.get("email", "Unknown")
        
        # Select a working proxy that has less than 2 accounts
        selected_proxy = None
        while proxy_index < len(purevpn_proxies):
            p = purevpn_proxies[proxy_index]
            count = assigned_counts.get(p["id"], 0)
            if count < 2:
                selected_proxy = p
                assigned_counts[p["id"]] = count + 1
                break
            else:
                proxy_index += 1
                
        if selected_proxy:
            # Update account with the new proxy ID
            if acc_id in db_data.get("accounts", {}):
                db_data["accounts"][acc_id]["proxy_id"] = selected_proxy["id"]
                print(f"Mapped Account {acc_id} ({email}) -> {selected_proxy['label']} ({selected_proxy['id']})")
        else:
            print(f"Warning: No working proxy available for account {acc_id}!")
            
    # 3. Clean up expired proxies from database
    for ep in expired_proxies:
        pid = ep["id"]
        if pid in db_data.get("proxies", {}):
            del db_data["proxies"][pid]
            print(f"Deleted expired proxy: {ep['label']} ({pid})")
            
    # Save the updated database
    db._save(db_data)
    print("\nDatabase cleanup and account re-assignment completed successfully!")

if __name__ == "__main__":
    asyncio.run(main())
