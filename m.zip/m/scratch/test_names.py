import sys; sys.path.insert(0, '.')
from handlers.order import parse_robust_card

cards = ['4111111111111111|12|28|123', '5500005555555559|06|27|321', '378282246310005|03|26|1234']
for c in cards:
    p = parse_robust_card(c)
    if p:
        num = p["card_number"][-4:]
        name = p["card_holder_name"]
        print(num + " -> " + name)
print("All USA = " + str(not any(n in [p["card_holder_name"] for c in cards for p in [parse_robust_card(c)] if p] for n in ["RAHUL","PRIYA","AMIT"])))
