import asyncio
import sys
import os
import requests
import time
sys.path.insert(0, '.')
from database import db

# Read proxies.text
PROXY_FILE = "proxies.text"

def test_single_proxy(line_idx, proxy_line):
    parts = proxy_line.strip().split(":")
    if len(parts) < 4:
        return None
    host, port, user, password = parts[0], parts[1], parts[2], parts[3]
    proxy_url = f"http://{user}:{password}@{host}:{port}"
    proxies = {"http": proxy_url, "https": proxy_url}
    
    try:
        # Test U7BUY
        url = "https://www.u7buy.com/api/configuration"
        start = time.time()
        r = requests.get(url, proxies=proxies, timeout=6)
        latency = time.time() - start
        
        if r.status_code == 200:
            # Check country
            try:
                r2 = requests.get("https://ipinfo.io/json", proxies=proxies, timeout=4)
                country = r2.json().get("country", "Unknown")
            except Exception:
                country = "Unknown"
                
            return {
                "host": host,
                "port": port,
                "username": user,
                "password": password,
                "url": proxy_url,
                "country": country.upper(),
                "latency": latency
            }
    except Exception:
        pass
    return None

async def main():
    await db.init_db()
    
    if not os.path.exists(PROXY_FILE):
        print(f"Error: {PROXY_FILE} not found!")
        return

    with open(PROXY_FILE, "r") as f:
        lines = [line.strip() for line in f if line.strip()]

    print(f"Scanning {len(lines)} proxies from proxies.text to find working ones...")
    
    # Import ThreadPoolExecutor
    import concurrent.futures
    working_proxies = []
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=25) as executor:
        futures = {executor.submit(test_single_proxy, idx+1, line): line for idx, line in enumerate(lines)}
        for future in concurrent.futures.as_completed(futures):
            res = future.result()
            if res:
                working_proxies.append(res)
                print(f"[WORKING] Host: {res['host']} | Country: {res['country']} | Latency: {res['latency']:.2f}s")

    if not working_proxies:
        print("No working proxies found in proxies.text!")
        return

    # Sort by latency
    working_proxies.sort(key=lambda x: x["latency"])
    
    # Add top 15 working proxies
    print("\nAdding top working proxies to database...")
    added_count = 0
    for p in working_proxies[:15]:
        label = f"PureVPN-{p['country']} ({round(p['latency'], 2)}s)"
        added = await db.add_proxy(
            host=p["host"],
            port=p["port"],
            username=p["username"],
            password=p["password"],
            protocol="http",
            label=label
        )
        print(f"Added: {label} -> ID: {added['id']}")
        added_count += 1

    print(f"\nSuccessfully added {added_count} working proxies to database!")

if __name__ == "__main__":
    asyncio.run(main())
