import asyncio
import logging
import uuid
import random
import urllib.parse
from playwright.async_api import async_playwright
from config import settings

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────
# Randomized human-like typing helper
# ─────────────────────────────────────────────────────────
async def _type_humanlike(locator, text: str):
    """Type text with random per-character delays to mimic human input."""
    await locator.click()
    await asyncio.sleep(random.uniform(0.2, 0.5))
    for char in text:
        await locator.type(char, delay=random.randint(40, 130))
    await asyncio.sleep(random.uniform(0.1, 0.3))


async def _extract_hcaptcha_sitekey(page) -> str:
    """Extract hCaptcha site key from the page."""
    try:
        # Try data-sitekey attribute on hcaptcha widget
        sitekey = await page.evaluate("""
            () => {
                const el = document.querySelector('[data-sitekey]');
                return el ? el.getAttribute('data-sitekey') : null;
            }
        """)
        if sitekey:
            return sitekey
    except Exception:
        pass
    # Fallback: search iframe src for sitekey param
    for frame in page.frames:
        if "hcaptcha.com" in frame.url:
            import urllib.parse
            parsed = urllib.parse.urlparse(frame.url)
            params = urllib.parse.parse_qs(parsed.query)
            sk = params.get("sitekey", [None])[0]
            if sk:
                return sk
    return ""


async def execute_browser_checkout(
    cash_info_key: str,
    cookies_dict: dict,
    card_number: str,
    exp_month: str,
    exp_year: str,
    cvc: str,
    card_holder_name: str,
    user_agent: str,
    user_storage_str: str = "",
    captcha_token: str = "",        # Pre-solved hCaptcha token (from user)
    proxy_url: str = ""             # Dynamic proxy url
) -> dict:
    """
    Automates the cashier checkout page using Playwright.
    Returns status: "success", "failed", "3ds_required", "captcha_needed", "error", or "timeout".
    captcha_needed → includes sitekey so user can manually solve.
    """
    playwright_cookies = []
    for name, value in cookies_dict.items():
        if not name or not value:
            continue
        if "stripe" in name or name == "stripe_sid":
            domain = ".stripe.com"
        else:
            domain = "www.u7buy.com"
        playwright_cookies.append({
            "name": name.strip(),
            "value": value.strip(),
            "domain": domain,
            "path": "/"
        })

    logger.info(f"Starting browser checkout. Loaded {len(playwright_cookies)} cookies.")

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=settings.HEADLESS,
            args=[
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
                "--disable-accelerated-2d-canvas",
                "--no-first-run",
                "--no-zygote",
                "--disable-gpu"
            ]
        )

        # Parse proxy
        proxy_config = None
        p_url = proxy_url.strip() if proxy_url else (settings.PROXY_URL.strip() if settings.PROXY_URL else "")
        if p_url:
            try:
                parsed = urllib.parse.urlparse(p_url)
                if not parsed.scheme:
                    parsed = urllib.parse.urlparse("http://" + p_url)
                server_str = f"{parsed.scheme}://{parsed.hostname}"
                if parsed.port:
                    server_str += f":{parsed.port}"
                proxy_config = {"server": server_str}
                if parsed.username and parsed.password:
                    proxy_config["username"] = parsed.username
                    proxy_config["password"] = parsed.password
                logger.info(f"Browser proxy: {parsed.hostname}:{parsed.port}")
            except Exception as pe:
                logger.error(f"Failed to parse proxy URL: {pe}")
                proxy_config = {"server": p_url}


        # Realistic mobile context
        context = await browser.new_context(
            user_agent=user_agent,
            viewport={"width": 390, "height": 844},
            is_mobile=True,
            has_touch=True,
            locale="en-IN",
            timezone_id="Asia/Kolkata",
            color_scheme="light",
            proxy=proxy_config
        )

        # ── Advanced stealth script ──
        await context.add_init_script("""
            // Remove webdriver flag
            Object.defineProperty(navigator, 'webdriver', { get: () => undefined });

            // Fake chrome object
            window.chrome = {
                app: { isInstalled: false },
                runtime: { id: undefined },
                csi: () => {},
                loadTimes: () => {}
            };

            // Fake plugins (non-empty)
            Object.defineProperty(navigator, 'plugins', {
                get: () => {
                    const plugins = [
                        { name: 'Chrome PDF Plugin', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
                        { name: 'Chrome PDF Viewer', filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai', description: '' },
                        { name: 'Native Client', filename: 'internal-nacl-plugin', description: '' }
                    ];
                    Object.defineProperty(plugins, 'length', { get: () => 3 });
                    plugins.item = (i) => plugins[i];
                    plugins.namedItem = (n) => plugins.find(p => p.name === n);
                    plugins.refresh = () => {};
                    return plugins;
                }
            });

            // Realistic language list
            Object.defineProperty(navigator, 'languages', {
                get: () => ['en-IN', 'en-US', 'en', 'hi']
            });

            // Realistic hardware concurrency
            Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 4 });

            // Fake screen dimensions
            Object.defineProperty(screen, 'width', { get: () => 390 });
            Object.defineProperty(screen, 'height', { get: () => 844 });
            Object.defineProperty(screen, 'availWidth', { get: () => 390 });
            Object.defineProperty(screen, 'availHeight', { get: () => 844 });

            // Disable automation detection props
            delete Object.getPrototypeOf(navigator).__proto__.webdriver;

            // Permission query spoof
            const originalQuery = window.navigator.permissions.query;
            window.navigator.permissions.query = (parameters) => (
                parameters.name === 'notifications' ?
                    Promise.resolve({ state: Notification.permission }) :
                    originalQuery(parameters)
            );
        """)

        await context.add_cookies(playwright_cookies)
        page = await context.new_page()

        try:
            # Random pre-navigation delay (human feel)
            await asyncio.sleep(random.uniform(0.5, 1.5))

            logger.info("Loading U7BUY homepage to establish session...")
            await page.goto("https://www.u7buy.com", wait_until="commit", timeout=40000)
            await asyncio.sleep(random.uniform(1.5, 3.0))

            # Inject localStorage if available
            if user_storage_str:
                import json
                await page.evaluate(f"localStorage.setItem('user', {json.dumps(user_storage_str)})")

            # Random mouse movement to appear human
            try:
                await page.mouse.move(
                    random.randint(50, 300),
                    random.randint(100, 400)
                )
                await asyncio.sleep(random.uniform(0.3, 0.8))
            except Exception:
                pass

            # Load cashier page
            cashier_url = f"https://www.u7buy.com/cashier?cashInfoKey={cash_info_key}&buyMin=1"
            logger.info(f"Loading cashier: {cashier_url}")
            await page.goto(cashier_url, wait_until="commit", timeout=40000)

            # Wait for page to stabilize
            await asyncio.sleep(random.uniform(3.0, 5.0))

            # Find Stripe iframe
            logger.info("Scanning frames for Stripe input...")
            stripe_frame = None
            for attempt in range(120):
                if attempt % 15 == 0 and attempt > 0:
                    logger.info(f"Frame scan attempt {attempt}. Frames: {len(page.frames)}")

                for frame in page.frames:
                    try:
                        if any(k in frame.url for k in [
                            "elements-inner-accessory-target",
                            "elements-inner-loader-ui",
                            "elements-inner-card"
                        ]):
                            if await frame.locator('input').count() > 0:
                                stripe_frame = frame
                                break
                    except Exception:
                        pass
                if stripe_frame:
                    break
                await asyncio.sleep(0.5)

            if not stripe_frame:
                import os
                os.makedirs("scratch", exist_ok=True)
                await page.screenshot(path="scratch/cashier_frame_error.png", timeout=5000)
                logger.error("Stripe iframe not found.")
                return {"status": "error", "message": "Stripe payment form failed to load.", "screenshot_path": "scratch/cashier_frame_error.png"}

            logger.info(f"Stripe iframe found: {stripe_frame.url[:80]}")

            # Locate card fields
            card_input = stripe_frame.locator(
                'input[autocomplete="cc-number"]:visible, input[name="number"]:visible, input#payment-numberInput:visible'
            )
            exp_input = stripe_frame.locator(
                'input[autocomplete="cc-exp"]:visible, input[name="expiry"]:visible, input#payment-expiryInput:visible'
            )
            cvc_input = stripe_frame.locator(
                'input[autocomplete="cc-csc"]:visible, input[name="cvc"]:visible, input#payment-cvcInput:visible'
            )

            # Wait for card number field
            try:
                await card_input.wait_for(state="visible", timeout=15000)
            except Exception as e:
                import os
                os.makedirs("scratch", exist_ok=True)
                await page.screenshot(path="scratch/cashier_frame_error.png", timeout=5000)
                return {"status": "error", "message": "Stripe payment form not visible.", "screenshot_path": "scratch/cashier_frame_error.png"}

            # ── Fill card details with human-like typing ──
            logger.info("Filling card number...")
            await _type_humanlike(card_input, card_number.replace(" ", ""))

            await asyncio.sleep(random.uniform(0.4, 0.8))

            logger.info("Filling expiry...")
            await _type_humanlike(exp_input, f"{exp_month}{exp_year[-2:]}")

            await asyncio.sleep(random.uniform(0.3, 0.6))

            logger.info("Filling CVC...")
            await _type_humanlike(cvc_input, cvc)

            await asyncio.sleep(random.uniform(0.3, 0.7))

            # Fill cardholder name
            logger.info("Filling cardholder name...")
            cardholder_selector = (
                'input[placeholder*="Card holder"]:visible, '
                'input[placeholder*="Cardholder"]:visible, '
                'input[placeholder="Name on card"]:visible, '
                'input[autocomplete="cc-name"]:visible, '
                'input[name="name"]:visible, '
                'input#Field-nameInput:visible'
            )
            filled_name = False
            for inp in await page.locator(cardholder_selector).all():
                name_attr = await inp.get_attribute("name") or ""
                placeholder = await inp.get_attribute("placeholder") or ""
                if "search" in name_attr.lower() or "search" in placeholder.lower():
                    continue
                await _type_humanlike(inp, card_holder_name)
                filled_name = True
            if not filled_name:
                for inp in await stripe_frame.locator(cardholder_selector).all():
                    await _type_humanlike(inp, card_holder_name)
                    filled_name = True

            await asyncio.sleep(random.uniform(0.5, 1.2))

            # ── If user provided a pre-solved token, inject it now ──
            if captcha_token:
                logger.info("Injecting pre-solved hCaptcha token...")
                try:
                    await page.evaluate(f"""
                        () => {{
                            // Set token in all hcaptcha response textareas
                            document.querySelectorAll('[name="h-captcha-response"]').forEach(el => {{
                                el.value = '{captcha_token}';
                            }});
                            // Also set g-recaptcha-response if present
                            document.querySelectorAll('[name="g-recaptcha-response"]').forEach(el => {{
                                el.value = '{captcha_token}';
                            }});
                        }}
                    """)
                    await asyncio.sleep(0.5)
                    logger.info("Captcha token injected successfully.")
                except Exception as te:
                    logger.warning(f"Token injection error: {{te}}")
            # Submit payment

            # Submit payment
            logger.info("Clicking pay button...")
            pay_button = (
                page.get_by_text("Secure Payment", exact=True)
                .or_(page.get_by_role("button", name="Secure Payment"))
                .or_(page.get_by_role("button", name="Pay"))
                .or_(page.locator('button:has-text("Secure Payment")'))
                .or_(page.locator('[class*="pay-btn"]'))
            ).first

            await pay_button.wait_for(state="visible", timeout=15000)
            await asyncio.sleep(random.uniform(0.3, 0.8))
            await pay_button.click()

            # ── Monitor result ──
            logger.info("Monitoring payment result...")
            captcha_alerted = False

            for attempt in range(240):
                current_url = page.url

                # ── hCaptcha check every 5 attempts ──
                if attempt % 5 == 0:
                    captcha_found = await _check_and_handle_captcha(page, stage=f"monitor_{attempt}")
                    if captcha_found:
                        logger.warning("hCaptcha active during monitoring — returning to user to solve.")
                        return captcha_found

                # Success
                if "/order/success" in current_url:
                    logger.info(f"Success! URL: {current_url}")
                    await asyncio.sleep(2)
                    import os
                    os.makedirs("scratch", exist_ok=True)
                    ss = "scratch/cashier_success.png"
                    try:
                        await page.screenshot(path=ss, timeout=5000)
                    except Exception:
                        pass
                    parsed_url = urllib.parse.urlparse(current_url)
                    params = urllib.parse.parse_qs(parsed_url.query)
                    order_no = params.get("orderNo", [None])[0]
                    return {"status": "success", "order_id": order_no, "screenshot_path": ss}

                # Failed
                if "/order/fail" in current_url:
                    await asyncio.sleep(2)
                    import os
                    os.makedirs("scratch", exist_ok=True)
                    ss = "scratch/cashier_fail.png"
                    try:
                        await page.screenshot(path=ss, timeout=5000)
                    except Exception:
                        pass
                    return {"status": "failed", "message": "Transaction declined.", "screenshot_path": ss}

                # 3DS on parent frame
                if "hooks.stripe.com" in current_url or "3d_secure" in current_url:
                    await asyncio.sleep(2)
                    import os
                    os.makedirs("scratch", exist_ok=True)
                    ss = "scratch/cashier_3ds.png"
                    try:
                        await page.screenshot(path=ss, timeout=5000)
                    except Exception:
                        pass
                    return {"status": "3ds_required", "redirect_url": current_url, "screenshot_path": ss}

                # 3DS in iframe
                for frame in page.frames:
                    if "hooks.stripe.com" in frame.url or "3d_secure" in frame.url:
                        await asyncio.sleep(2)
                        import os
                        os.makedirs("scratch", exist_ok=True)
                        ss = "scratch/cashier_3ds.png"
                        try:
                            await page.screenshot(path=ss, timeout=5000)
                        except Exception:
                            pass
                        return {"status": "3ds_required", "redirect_url": frame.url, "screenshot_path": ss}

                # Direct error messages
                error_locator = page.locator('.error-message, .alert-danger, .error-tip, .stripe-error-message')
                if await error_locator.count() > 0:
                    for idx in range(await error_locator.count()):
                        el = error_locator.nth(idx)
                        if await el.is_visible():
                            err_text = await el.text_content()
                            if err_text:
                                logger.warning(f"Page error: {err_text}")
                                import os
                                os.makedirs("scratch", exist_ok=True)
                                ss = "scratch/cashier_fail.png"
                                try:
                                    await page.screenshot(path=ss, timeout=5000)
                                except Exception:
                                    pass
                                return {"status": "failed", "message": err_text.strip(), "screenshot_path": ss}


                await asyncio.sleep(0.5)

            # Timeout
            logger.warning("Payment monitoring timed out.")
            import os
            os.makedirs("scratch", exist_ok=True)
            ss = "scratch/cashier_error.png"
            try:
                await page.screenshot(path=ss, timeout=5000)
            except Exception:
                pass
            return {"status": "timeout", "message": "Payment processing timed out.", "screenshot_path": ss}

        except Exception as e:
            logger.error(f"Checkout exception: {e}")
            import os
            os.makedirs("scratch", exist_ok=True)
            ss = "scratch/cashier_error.png"
            try:
                await page.screenshot(path=ss, timeout=5000)
            except Exception:
                pass
            return {"status": "error", "message": f"Browser error: {str(e)}", "screenshot_path": ss}

        finally:
            await context.close()
            await browser.close()


async def _check_and_handle_captcha(page, stage: str = "") -> dict | None:
    """
    Check if hCaptcha is present and visible on page.
    If found: extract sitekey, take screenshot, return captcha_needed dict.
    Returns None if no captcha.
    """
    try:
        captcha_frame_url = None
        # Find all iframes on the page
        iframes = page.locator("iframe")
        count = await iframes.count()
        
        for i in range(count):
            iframe_loc = iframes.nth(i)
            try:
                src = await iframe_loc.get_attribute("src") or ""
                # hcaptcha elements or main solver iframe
                if "hcaptcha.com" in src or ("captcha" in src.lower() and "stripe" not in src.lower()):
                    # Double check if the iframe is actually visible to the user
                    if await iframe_loc.is_visible():
                        captcha_frame_url = src
                        break
            except Exception:
                pass

        if not captcha_frame_url:
            return None

        logger.warning(f"[{stage}] hCaptcha detected and visible! Frame: {captcha_frame_url[:80]}")

        sitekey = await _extract_hcaptcha_sitekey(page)
        page_url = page.url

        import os
        os.makedirs("scratch", exist_ok=True)
        ss = "scratch/cashier_captcha.png"
        try:
            await page.screenshot(path=ss, timeout=5000)
        except Exception:
            pass

        logger.info(f"Captcha sitekey: {sitekey}")
        return {
            "status": "captcha_needed",
            "sitekey": sitekey,
            "page_url": page_url,
            "screenshot_path": ss,
            "message": "hCaptcha verification required."
        }
    except Exception as e:
        logger.warning(f"Captcha check error: {e}")
    return None
