import asyncio
import logging
import uuid
import urllib.parse
from playwright.async_api import async_playwright
from config import settings

logger = logging.getLogger(__name__)


async def execute_browser_checkout(
    cash_info_key: str,
    cookies_dict: dict,
    card_number: str,
    exp_month: str,
    exp_year: str,
    cvc: str,
    card_holder_name: str,
    user_agent: str,
    user_storage_str: str = ""
) -> dict:
    """
    Automates the cashier checkout page using Playwright.
    Returns status: "success", "failed", "3ds_required", or "error".
    """
    # Format cookies for Playwright injection
    playwright_cookies = []
    for name, value in cookies_dict.items():
        if not name or not value:
            continue
        # For u7buy cookies, use u7buy.com domain (without leading dot).
        # Stripe elements and sessions require elements.stripe.com or .stripe.com domain context.
        if "stripe" in name or name == "stripe_sid":
            domain = ".stripe.com"
        else:
            domain = "www.u7buy.com"
            
        playwright_cookies.append({
            "name": name.strip(),
            "value": value.strip(),
            "domain": domain,
            "path": "/"
        })

    logger.info(f"Starting browser checkout automation. Loaded {len(playwright_cookies)} cookies.")

    async with async_playwright() as p:
        # Launch Chromium (headed or headless based on config)
        browser = await p.chromium.launch(
            headless=settings.HEADLESS,
            args=[
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-blink-features=AutomationControlled"
            ]
        )

        # Build proxy config for Playwright if PROXY_URL is set
        proxy_config = None
        proxy_url = settings.PROXY_URL.strip() if settings.PROXY_URL else ""
        if proxy_url:
            import urllib.parse
            try:
                parsed = urllib.parse.urlparse(proxy_url)
                if not parsed.scheme:
                    parsed = urllib.parse.urlparse("http://" + proxy_url)
                
                server_str = f"{parsed.scheme}://{parsed.hostname}"
                if parsed.port:
                    server_str += f":{parsed.port}"
                    
                proxy_config = {"server": server_str}
                if parsed.username and parsed.password:
                    proxy_config["username"] = parsed.username
                    proxy_config["password"] = parsed.password
                
                logger.info(f"Browser using proxy: {parsed.hostname}:{parsed.port}")
            except Exception as pe:
                logger.error(f"Failed to parse proxy URL: {pe}")
                proxy_config = {"server": proxy_url}

        # Build context imitating a real mobile viewport to pass security checks
        context = await browser.new_context(
            user_agent=user_agent,
            viewport={"width": 390, "height": 844},
            is_mobile=True,
            has_touch=True,
            locale="en-US",
            proxy=proxy_config  # None = direct connection
        )

        # Inject Stealth Script to bypass headless detection (Forter / Cloudflare anti-bot)
        await context.add_init_script("""
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined
            });
            window.chrome = {
                runtime: {}
            };
            Object.defineProperty(navigator, 'plugins', {
                get: () => [1, 2, 3, 4, 5]
            });
            Object.defineProperty(navigator, 'languages', {
                get: () => ['en-US', 'en']
            });
        """)

        await context.add_cookies(playwright_cookies)
        page = await context.new_page()
        
        try:
            # Go directly to U7BUY homepage with a short "commit" wait to establish domain origin fast
            homepage_url = "https://www.u7buy.com"
            logger.info(f"Establishing domain context by loading Homepage (commit): {homepage_url}")
            await page.goto(homepage_url, wait_until="commit", timeout=40000)
            
            # Inject localStorage user profile if available
            if user_storage_str:
                logger.info("Injecting localStorage user session state...")
                import json
                await page.evaluate(f"localStorage.setItem('user', {json.dumps(user_storage_str)})")
                
            # Now load the Cashier page with wait_until="commit" to avoid tracker timeouts
            cashier_url = f"https://www.u7buy.com/cashier?cashInfoKey={cash_info_key}&buyMin=1"
            logger.info(f"Loading Cashier URL (commit): {cashier_url}")
            await page.goto(cashier_url, wait_until="commit", timeout=40000)
            
            # Wait 3 seconds for initial HTML parsing to begin
            await asyncio.sleep(3)

            # Locate Stripe Elements Card Input iframe dynamically by scanning all frames
            # This is 100% immune to Stripe's nested structure and URL naming changes.
            logger.info("Scanning page frames dynamically to locate Stripe input fields...")
            stripe_frame = None
            for attempt in range(120):
                if attempt % 15 == 0:
                    logger.info(f"Frame search attempt {attempt}. Total frames in tree: {len(page.frames)}")
                    for idx, f in enumerate(page.frames):
                        logger.info(f"  Frame {idx}: URL={f.url[:100]}...")

                for frame in page.frames:
                    try:
                        # Direct URL segment check for Stripe Element frames
                        if "elements-inner-accessory-target" in frame.url or "elements-inner-loader-ui" in frame.url or "elements-inner-card" in frame.url:
                            # Verify if the frame has active inputs loaded
                            inputs_count = await frame.locator('input').count()
                            if inputs_count > 0:
                                stripe_frame = frame
                                break
                    except Exception:
                        pass
                if stripe_frame:
                    break
                await asyncio.sleep(0.5)
                
            if not stripe_frame:
                # Capture diagnostic screenshot on frame locate fail
                import os
                os.makedirs("scratch", exist_ok=True)
                await page.screenshot(path="scratch/cashier_frame_error.png", timeout=5000)
                logger.error("Stripe elements input iframe not found. Saved screenshot to scratch/cashier_frame_error.png")
                return {"status": "error", "message": "Stripe payment form failed to load.", "screenshot_path": "scratch/cashier_frame_error.png"}
                
            logger.info(f"Stripe input iframe found: {stripe_frame.url[:80]}...")
            
            # Locate secure input elements inside the Stripe frame (filtering by :visible and exact elements found in diagnostics)
            card_input = stripe_frame.locator('input[autocomplete="cc-number"]:visible, input[name="number"]:visible, input#payment-numberInput:visible')
            exp_input = stripe_frame.locator('input[autocomplete="cc-exp"]:visible, input[name="expiry"]:visible, input#payment-expiryInput:visible')
            cvc_input = stripe_frame.locator('input[autocomplete="cc-csc"]:visible, input[name="cvc"]:visible, input#payment-cvcInput:visible')
            
            # Locate Cardholder name input inside Stripe iframe and main document (filtering by :visible)
            name_input_stripe = stripe_frame.locator('input[placeholder*="Card holder"]:visible, input[placeholder*="Cardholder"]:visible, input[name*="name"]:visible, input#Field-nameInput:visible')
            name_input_page = page.locator('input[placeholder*="Card holder"]:visible, input[placeholder*="Cardholder"]:visible, input[name*="name"]:visible, input#Field-nameInput:visible')
            
            # Wait for elements to be interactive
            logger.info("Waiting for Stripe card number input field to be visible...")
            try:
                await card_input.wait_for(state="visible", timeout=15000)
            except Exception as e:
                # Capture diagnostic screenshot on frame/input wait fail
                import os
                os.makedirs("scratch", exist_ok=True)
                await page.screenshot(path="scratch/cashier_frame_error.png", timeout=5000)
                logger.error(f"Stripe elements inputs not visible on page. Saved screenshot. Error: {e}")
                return {"status": "error", "message": "Stripe payment form failed to load."}
            
            # Type values with short random delays to simulate real keyboard inputs
            logger.info("Filling payment details...")
            await card_input.click()
            await card_input.fill(card_number.replace(" ", ""))
            
            await exp_input.click()
            # Send MMYY format
            exp_short = f"{exp_month}{exp_year[-2:]}"
            await exp_input.fill(exp_short)
            
            await cvc_input.click()
            await cvc_input.fill(cvc)
            
            # Fill cardholder name (try to fill matching visible fields on both the main page and in the Stripe iframe)
            logger.info("Filling Cardholder Name...")
            filled_name = False
            
            # Precise Cardholder input selectors
            cardholder_selector = (
                'input[placeholder*="Card holder"]:visible, '
                'input[placeholder*="Cardholder"]:visible, '
                'input[placeholder="Name on card"]:visible, '
                'input[autocomplete="cc-name"]:visible, '
                'input[name="name"]:visible, '
                'input#Field-nameInput:visible'
            )
            
            # Fill matching inputs on the main page
            try:
                for inp in await page.locator(cardholder_selector).all():
                    # Double check it is not a search box or account username
                    name_attr = await inp.get_attribute("name") or ""
                    placeholder = await inp.get_attribute("placeholder") or ""
                    if "search" in name_attr.lower() or "search" in placeholder.lower():
                        continue
                    await inp.click()
                    await inp.fill(card_holder_name)
                    logger.info(f"Filled Cardholder Name in visible page input. Name attr: '{name_attr}', Placeholder: '{placeholder}'")
                    filled_name = True
            except Exception as e:
                logger.warning(f"Error filling page cardholder input: {e}")
                
            # Fill matching inputs inside the Stripe frame
            try:
                for inp in await stripe_frame.locator(cardholder_selector).all():
                    name_attr = await inp.get_attribute("name") or ""
                    placeholder = await inp.get_attribute("placeholder") or ""
                    await inp.click()
                    await inp.fill(card_holder_name)
                    logger.info(f"Filled Cardholder Name in visible Stripe frame input. Name attr: '{name_attr}', Placeholder: '{placeholder}'")
                    filled_name = True
            except Exception as e:
                logger.warning(f"Error filling Stripe frame cardholder input: {e}")
            
            if not filled_name:
                # Last resort generic scanner (strictly matching holder or card holder)
                try:
                    for inp in await page.locator('input').all():
                        placeholder = await inp.get_attribute('placeholder') or ''
                        is_visible = await inp.is_visible()
                        if is_visible and ("holder" in placeholder.lower() or "card holder" in placeholder.lower()):
                            await inp.click()
                            await inp.fill(card_holder_name)
                            logger.info("Filled Cardholder Name via backup scanner.")
                            filled_name = True
                except Exception as e:
                    logger.warning(f"Error in backup cardholder scanner: {e}")

            if not filled_name:
                logger.warning("Could not dynamically resolve Cardholder Name field.")

            # Submit Payment - use a highly precise text-based or button selector
            logger.info("Locating and clicking pay button...")
            pay_button = (
                page.get_by_text("Secure Payment", exact=True)
                .or_(page.get_by_role("button", name="Secure Payment"))
                .or_(page.get_by_role("button", name="Pay"))
                .or_(page.locator('button:has-text("Secure Payment")'))
                .or_(page.locator('[class*="pay-btn"]'))
            ).first
            
            await pay_button.wait_for(state="visible", timeout=15000)
            logger.info("Clicking Secure Payment button...")
            await pay_button.click()
            
            # Wait for result state (Success redirect, 3DS verification, or error message)
            logger.info("Monitoring payment results...")
            for attempt in range(240):
                current_url = page.url
                
                # Check for hCaptcha or captcha presence
                has_captcha = False
                for frame in page.frames:
                    if "hcaptcha.com" in frame.url or "captcha" in frame.url:
                        has_captcha = True
                        break
                
                if has_captcha:
                    if attempt % 15 == 0:
                        logger.warning("⚠️ hCaptcha / Verification Challenge detected! Please check the browser window and complete the verification.")
                
                # Case 1: Successful payment redirect
                if "/order/success" in current_url:
                    logger.info(f"Order completed successfully! Redirect: {current_url}")
                    await asyncio.sleep(3) # Wait for page transition to finish loading and spinner to disappear
                    import os
                    os.makedirs("scratch", exist_ok=True)
                    screenshot_path = "scratch/cashier_success.png"
                    try:
                        await page.screenshot(path=screenshot_path, timeout=5000)
                        logger.info(f"Saved success screenshot to {screenshot_path}")
                    except Exception as se:
                        logger.error(f"Failed to save success screenshot: {se}")
                    parsed = urllib.parse.urlparse(current_url)
                    params = urllib.parse.parse_qs(parsed.query)
                    order_no = params.get("orderNo", [None])[0]
                    return {"status": "success", "order_id": order_no, "screenshot_path": screenshot_path}
                
                # Case 2: Failed payment redirect
                if "/order/fail" in current_url:
                    logger.warning(f"Payment failed redirect hit: {current_url}")
                    await asyncio.sleep(3) # Wait for page transition to finish loading and spinner to disappear
                    import os
                    os.makedirs("scratch", exist_ok=True)
                    screenshot_path = "scratch/cashier_fail.png"
                    try:
                        await page.screenshot(path=screenshot_path, timeout=5000)
                        logger.info(f"Saved fail screenshot to {screenshot_path}")
                    except Exception as se:
                        logger.error(f"Failed to save fail screenshot: {se}")
                    return {"status": "failed", "message": "Transaction declined by card issuer.", "screenshot_path": screenshot_path}
                
                # Case 3: Parent page redirected to 3DS validation
                if "hooks.stripe.com" in current_url or "3d_secure" in current_url:
                    logger.info(f"3DS redirect detected on parent frame: {current_url}")
                    await asyncio.sleep(2) # Wait for 3DS frame/challenge page to render
                    import os
                    os.makedirs("scratch", exist_ok=True)
                    screenshot_path = "scratch/cashier_3ds.png"
                    try:
                        await page.screenshot(path=screenshot_path, timeout=5000)
                        logger.info(f"Saved 3DS screenshot to {screenshot_path}")
                    except Exception as se:
                        logger.error(f"Failed to save 3DS screenshot: {se}")
                    return {"status": "3ds_required", "redirect_url": current_url, "screenshot_path": screenshot_path}
                
                # Case 4: Iframe with 3DS validation loaded on page
                for frame in page.frames:
                    if "hooks.stripe.com" in frame.url or "3d_secure" in frame.url:
                        logger.info(f"3DS challenge iframe detected: {frame.url}")
                        await asyncio.sleep(2) # Wait for 3DS frame/challenge page to render
                        import os
                        os.makedirs("scratch", exist_ok=True)
                        screenshot_path = "scratch/cashier_3ds.png"
                        try:
                            await page.screenshot(path=screenshot_path, timeout=5000)
                            logger.info(f"Saved 3DS screenshot to {screenshot_path}")
                        except Exception as se:
                            logger.error(f"Failed to save 3DS screenshot: {se}")
                        return {"status": "3ds_required", "redirect_url": frame.url, "screenshot_path": screenshot_path}
                
                # Case 5: Direct error message displayed
                error_locator = page.locator('.error-message, .alert-danger, .error-tip, .stripe-error-message')
                if await error_locator.count() > 0:
                    for idx in range(await error_locator.count()):
                        el = error_locator.nth(idx)
                        if await el.is_visible():
                            err_text = await el.text_content()
                            if err_text:
                                logger.warning(f"Direct page payment error: {err_text}")
                                return {"status": "failed", "message": err_text.strip()}
                
                await asyncio.sleep(0.5)
            
            logger.warning("Payment monitoring timed out without clear result.")
            import os
            os.makedirs("scratch", exist_ok=True)
            try:
                await page.screenshot(path="scratch/cashier_error.png", timeout=5000)
                logger.info("Saved cashier error screenshot on timeout to scratch/cashier_error.png")
            except Exception as se:
                logger.error(f"Failed to save cashier timeout screenshot: {se}")
            return {"status": "timeout", "message": "Payment processing timed out. Check U7BUY order history.", "screenshot_path": "scratch/cashier_error.png"}
            
        except Exception as e:
            logger.error(f"Checkout browser automation exception: {e}")
            import os
            os.makedirs("scratch", exist_ok=True)
            try:
                await page.screenshot(path="scratch/cashier_error.png", timeout=5000)
                logger.info("Saved cashier error screenshot to scratch/cashier_error.png")
            except Exception:
                pass
            return {"status": "error", "message": f"Browser checkout error: {str(e)}", "screenshot_path": "scratch/cashier_error.png"}
            
        finally:
            await context.close()
            await browser.close()
