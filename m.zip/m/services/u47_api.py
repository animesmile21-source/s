import aiohttp
import json
import logging
import asyncio
import uuid
import time

logger = logging.getLogger(__name__)

# Stripe Public Key extracted from U7BUY checkout page
STRIPE_PK = "pk_live_51QkiiYP9oVFev5vctsrZeZSKGyuDVif8KbROgGFuPmYbP38AzQy6sWjVsXCbIGfy7eg7oYdPQRNd1o9xQmUkKips00SMglMbGt"

class U7BuyApiClient:
    BASE_URL = "https://www.u7buy.com"
    
    def __init__(self, session_data_str: str):
        self.session_data_str = session_data_str
        self.cookies_dict = {}
        self.access_token = ""
        self.user_storage_str = ""
        
        self.headers = {
            "sec-ch-ua-platform": '"Android"',
            "sec-ch-ua": '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
            "sec-ch-ua-mobile": "?1",
            "clientid": "94f670c954182e9c30535fa9cad35983",
            "user-agent": "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36",
            "content-language": "en",
            "content-currency": "INR",
            "accept": "application/json",
            "origin": "https://www.u7buy.com",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
        }
        
        self._parse_session_data(session_data_str)
        
        # Add Authorization header if token is present
        if self.access_token:
            self.headers["Authorization"] = f"Bearer {self.access_token}"

    def _parse_session_data(self, data_str: str):
        """
        Parses session data which can be either the Console script JSON
        or the standard Cookie-Editor JSON array.
        """
        if not data_str:
            return
            
        # Clean up copy-paste non-breaking space characters (NBSP)
        cleaned_str = data_str.replace("\u00a0", " ").replace("\xa0", " ").strip()
            
        try:
            parsed = json.loads(cleaned_str)
            
            # 1. Check if it's the browser console script JSON format
            if isinstance(parsed, dict) and ("user" in parsed or "cookies" in parsed):
                # Parse cookies string
                cookies_str = parsed.get("cookies", "")
                if cookies_str:
                    for item in cookies_str.split(";"):
                        if "=" in item:
                            k, v = item.strip().split("=", 1)
                            self.cookies_dict[k] = v
                
                # Save user local storage JSON string
                self.user_storage_str = parsed.get("user", "")
                
                # Try to extract accessToken from u7CookieConfig cookie first (most reliable)
                if "u7CookieConfig" in self.cookies_dict:
                    try:
                        import urllib.parse
                        decoded = urllib.parse.unquote(self.cookies_dict["u7CookieConfig"])
                        config = json.loads(decoded)
                        self.access_token = config.get("state", {}).get("accessToken", "")
                    except Exception:
                        pass
                
                # Fallback: Parse user info to extract accessToken if cookie didn't yield one
                if not self.access_token:
                    user_str = self.user_storage_str
                    if user_str:
                        try:
                            user_info = json.loads(user_str)
                            self.access_token = user_info.get("state", {}).get("userInfo", {}).get("accessToken", "")
                        except Exception:
                            pass
                        
            # 2. Check if it's the standard Cookie-Editor JSON array format
            elif isinstance(parsed, list):
                for cookie in parsed:
                    name = cookie.get("name")
                    value = cookie.get("value")
                    if name and value is not None:
                        self.cookies_dict[name] = value
                        if name == "u7CookieConfig":
                            try:
                                import urllib.parse
                                decoded = urllib.parse.unquote(value)
                                config = json.loads(decoded)
                                self.access_token = config.get("state", {}).get("accessToken", "")
                            except Exception:
                                pass
        except Exception as e:
            logger.error(f"Error parsing session data: {e}")

    async def validate_session(self) -> dict | None:
        """
        Validates the current session by calling U7BUY member status API.
        Returns user profile info if successful, else None.
        """
        url = f"{self.BASE_URL}/prod-api/member/activity/v1/status"
        async with aiohttp.ClientSession(cookies=self.cookies_dict) as session:
            try:
                async with session.get(url, headers=self.headers, timeout=10) as r:
                    if r.status == 200:
                        res_json = await r.json(content_type=None)
                        if res_json.get("code") == 200 or "data" in res_json:
                            return res_json.get("data", res_json)
                    logger.warning(f"Session validation failed, status code: {r.status}")
            except Exception as e:
                logger.error(f"Session validation request failed: {e}")
        return None

    async def get_google_play_products(self) -> list:
        """
        Fetches the Google Play gift cards list from U7BUY and filters for Indian cards only.
        """
        url = f"{self.BASE_URL}/prod-api/product/urlMapping/digital/getVirtualProductSkuListByUrl"
        params = {
            "pageNum": "1",
            "pageSize": "100",
            "sortRule": "default",
            "url": "/gift-cards/google-play",
            "regionFlag": "true"
        }
        async with aiohttp.ClientSession(cookies=self.cookies_dict) as session:
            try:
                async with session.get(url, params=params, headers=self.headers, timeout=10) as r:
                    if r.status == 200:
                        res_json = await r.json(content_type=None)
                        raw_rows = res_json.get("data", {}).get("productVirtualSkuVoTableDataInfo", {}).get("rows", [])
                        
                        # Filter for India region only
                        indian_cards = []
                        for item in raw_rows:
                            region = item.get("regionInfo", "").strip().lower()
                            sku_name = item.get("skuName", "").lower()
                            if region == "india" or "india" in sku_name or "inr" in sku_name:
                                indian_cards.append({
                                    "skuId": str(item.get("id")),
                                    "skuName": item.get("skuName"),
                                    "skuPrice": item.get("fromPrice"),
                                    # skuUrl used to create buy/now requests
                                    "skuUrl": item.get("skuUrl", "")
                                })
                        return indian_cards
            except Exception as e:
                logger.error(f"Error fetching Google Play products: {e}")
        return []

    async def get_telegram_stars_products(self) -> list:
        """
        Fetches Telegram Stars and Premium packages from U7BUY.
        """
        url = f"{self.BASE_URL}/prod-api/product/urlMapping/topUpProductInfo/getFaceValueList"
        params = {
            "spuId": "2054448890293202946",
            "categoryId": "2034807242400006145",
            "deliveryId": "1888166069358653461",
            "areaId": "1888074791040151609"
        }
        async with aiohttp.ClientSession(cookies=self.cookies_dict) as session:
            try:
                async with session.get(url, params=params, headers=self.headers, timeout=10) as r:
                    if r.status == 200:
                        res_json = await r.json(content_type=None)
                        raw_list = res_json.get("data", [])
                        
                        products = []
                        for item in raw_list:
                            products.append({
                                "skuId": str(item.get("skuId")),
                                "offerId": str(item.get("offerId")),   # This is the productId for save/cashier/info
                                "skuName": item.get("faceValue"),
                                "skuPrice": item.get("price")
                            })
                        return products
            except Exception as e:
                logger.error(f"Error fetching Telegram Stars products: {e}")
        return []

    # ─────────────────────────────────────────────
    # STEP 1: Create Order → Get cashInfoKey
    # ─────────────────────────────────────────────
    async def create_order(
        self,
        cash_info_key: str,
        pay_channel: str = "STRIPE_GB",
        session: aiohttp.ClientSession = None
    ) -> dict | None:
        """
        Calls buy/now to generate an order and get orderMainId.
        cashInfoKey is received from the product's checkout page init.
        """
        url = f"{self.BASE_URL}/prod-api/api/order/buyer/buy/now"
        payload = {
            "balanceFlag": 0,
            "currency": "INR",
            "discountType": 0,
            "payChannel": pay_channel,
            "paymentMethod": "iframe",
            "cashInfoKey": cash_info_key,
            "autoSelectCoupon": False
        }
        headers = {**self.headers, "content-type": "application/json"}
        
        close_session = False
        if session is None:
            session = aiohttp.ClientSession(cookies=self.cookies_dict)
            close_session = True
            
        try:
            async with session.post(url, json=payload, headers=headers, timeout=15) as r:
                res_json = await r.json(content_type=None)
                logger.info(f"create_order response: {res_json}")
                if res_json.get("code") == 200:
                    return res_json.get("data")
                else:
                    logger.warning(f"create_order failed: {res_json.get('msg')}")
                    return {"error": res_json.get("msg", "Order creation failed")}
        except Exception as e:
            logger.error(f"create_order exception: {e}")
        finally:
            if close_session:
                for cookie in session.cookie_jar:
                    self.cookies_dict[cookie.key] = cookie.value
                await session.close()
        return None

    # ─────────────────────────────────────────────
    # STEP 2: Get cashier details (orderMainId)
    # ─────────────────────────────────────────────
    async def get_cashier_details(
        self,
        cash_info_key: str,
        session: aiohttp.ClientSession = None
    ) -> dict | None:
        """
        Fetches cashier page data including orderMainId and customerId.
        """
        url = f"{self.BASE_URL}/prod-api/api/order/buyer/cashier"
        payload = {
            "balanceFlag": 0,
            "currency": "INR",
            "discountType": 0,
            "cashInfoKey": cash_info_key
        }
        headers = {**self.headers, "content-type": "application/json"}
        
        close_session = False
        if session is None:
            session = aiohttp.ClientSession(cookies=self.cookies_dict)
            close_session = True
            
        try:
            async with session.post(url, json=payload, headers=headers, timeout=15) as r:
                res_json = await r.json(content_type=None)
                logger.info(f"get_cashier_details response: {res_json}")
                if res_json.get("code") == 200:
                    return res_json.get("data")
                else:
                    return {"error": res_json.get("msg", "Cashier fetch failed")}
        except Exception as e:
            logger.error(f"get_cashier_details exception: {e}")
        finally:
            if close_session:
                for cookie in session.cookie_jar:
                    self.cookies_dict[cookie.key] = cookie.value
                await session.close()
        return None

    # ─────────────────────────────────────────────
    # STEP 3: Tokenize card with Stripe
    # ─────────────────────────────────────────────
    async def tokenize_card_stripe(
        self,
        card_number: str,
        exp_month: str,
        exp_year: str,
        cvc: str,
        customer_id: str
    ) -> dict:
        """
        Sends card details to Stripe to get a confirmation_token (ctoken_xxx).
        Uses Stripe's public key extracted from U7BUY checkout page.
        
        Returns dict with either:
          {"token": "ctoken_xxx", "stored": "1"}  on success
          {"error": "message"}                     on failure
        """
        stripe_url = "https://api.stripe.com/v1/confirmation_tokens"
        
        # Load Stripe session identifiers from cookies to match browser fingerprint
        muid = self.cookies_dict.get("__stripe_mid", "")
        sid = self.cookies_dict.get("__stripe_sid", "") or self.cookies_dict.get("stripe_sid", "")
        
        if not muid:
            muid = str(uuid.uuid4())
        if not sid:
            sid = str(uuid.uuid4())
            
        # Generate session identifiers (required by Stripe)
        client_session_id = str(uuid.uuid4())
        elements_session_id = f"elements_session_{uuid.uuid4().hex[:12]}"
        
        # Build form data exactly as the browser sends
        data = {
            "payment_method_data[allow_redisplay]": "always",
            "payment_method_data[type]": "card",
            f"payment_method_data[card][number]": card_number.replace(" ", ""),
            f"payment_method_data[card][cvc]": cvc,
            f"payment_method_data[card][exp_year]": exp_year,
            f"payment_method_data[card][exp_month]": exp_month,
            "payment_method_data[payment_user_agent]": "stripe.js/4c502f49d8; stripe-js-v3/4c502f49d8; payment-element; deferred-intent",
            "payment_method_data[referrer]": "https://www.u7buy.com",
            f"payment_method_data[time_on_page]": str(int(time.time() * 1000) % 1000000),
            "payment_method_data[client_attribution_metadata][client_session_id]": client_session_id,
            "payment_method_data[client_attribution_metadata][merchant_integration_source]": "elements",
            "payment_method_data[client_attribution_metadata][merchant_integration_subtype]": "payment-element",
            "payment_method_data[client_attribution_metadata][merchant_integration_version]": "2021",
            "payment_method_data[client_attribution_metadata][payment_intent_creation_flow]": "deferred",
            "payment_method_data[client_attribution_metadata][payment_method_selection_flow]": "merchant_specified",
            "payment_method_data[client_attribution_metadata][elements_session_id]": elements_session_id,
            "payment_method_data[client_attribution_metadata][merchant_integration_additional_elements][0]": "payment",
            "payment_method_data[guid]": str(uuid.uuid4()),
            "payment_method_data[muid]": muid,
            "payment_method_data[sid]": sid,
            "client_context[currency]": "inr",
            "client_context[mode]": "payment",
            "client_context[payment_method_types][0]": "card",
            "client_attribution_metadata[client_session_id]": client_session_id,
            "client_attribution_metadata[merchant_integration_source]": "elements",
            "client_attribution_metadata[merchant_integration_subtype]": "payment-element",
            "client_attribution_metadata[merchant_integration_version]": "2021",
            "client_attribution_metadata[payment_intent_creation_flow]": "deferred",
            "client_attribution_metadata[payment_method_selection_flow]": "merchant_specified",
            "client_attribution_metadata[elements_session_id]": elements_session_id,
            "client_attribution_metadata[merchant_integration_additional_elements][0]": "payment",
            "set_as_default_payment_method": "false",
            "key": STRIPE_PK,
            "_stripe_version": "2025-03-31.basil"
        }
        
        if customer_id:
            data["client_context[customer]"] = customer_id
        
        stripe_headers = {
            "accept": "application/json",
            "content-type": "application/x-www-form-urlencoded",
            "origin": "https://js.stripe.com",
            "referer": "https://js.stripe.com/",
            "sec-ch-ua": '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": '"Android"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "user-agent": self.headers.get("user-agent", "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36"),
        }
        
        # Build cookies payload for Stripe to match the browser identity
        stripe_cookies = {}
        if self.cookies_dict.get("__stripe_mid"):
            stripe_cookies["__stripe_mid"] = self.cookies_dict["__stripe_mid"]
        if self.cookies_dict.get("__stripe_sid"):
            stripe_cookies["__stripe_sid"] = self.cookies_dict["__stripe_sid"]
        elif self.cookies_dict.get("stripe_sid"):
            stripe_cookies["__stripe_sid"] = self.cookies_dict["stripe_sid"]
            
        async with aiohttp.ClientSession(cookies=stripe_cookies) as session:
            try:
                async with session.post(
                    stripe_url,
                    data=data,
                    headers=stripe_headers,
                    timeout=20
                ) as r:
                    res_json = await r.json(content_type=None)
                    logger.info(f"Stripe tokenize response status: {r.status}, id: {res_json.get('id')}, error: {res_json.get('error')}")
                    
                    if r.status == 200 and res_json.get("id"):
                        token = res_json["id"]  # ctoken_xxx
                        return {"token": token, "stored": "1"}
                    else:
                        error = res_json.get("error", {})
                        error_msg = error.get("message", "Card tokenization failed")
                        decline_code = error.get("decline_code", "")
                        error_code = error.get("code", "")
                        return {
                            "error": error_msg,
                            "decline_code": decline_code,
                            "error_code": error_code
                        }
            except Exception as e:
                logger.error(f"Stripe tokenize exception: {e}")
                return {"error": str(e)}

    # ─────────────────────────────────────────────
    # STEP 4: Submit Payment to U7BUY
    # ─────────────────────────────────────────────
    async def submit_payment(
        self,
        order_main_id: str,
        payment_token: str,
        customer_id: str,
        card_holder_name: str,
        cash_info_key: str,
        stored: str = "1",
        session: aiohttp.ClientSession = None
    ) -> dict | None:
        """
        Submits the Stripe confirmation token to U7BUY to complete payment.
        """
        url = f"{self.BASE_URL}/prod-api/api/order/buyer/pay"
        payload = {
            "orderMainId": order_main_id,
            "stored": stored,
            "customerId": customer_id,
            "paymentMethodToken": payment_token,
            "cardHolderName": card_holder_name
        }
        
        # Set Referer exactly as browser cashier page to bypass basic automated system headers detection
        pay_headers = {
            **self.headers,
            "content-type": "application/json",
            "Referer": f"https://www.u7buy.com/cashier?cashInfoKey={cash_info_key}&buyMin=1"
        }
        
        close_session = False
        if session is None:
            session = aiohttp.ClientSession(cookies=self.cookies_dict)
            close_session = True
            
        try:
            async with session.post(url, json=payload, headers=pay_headers, timeout=20) as r:
                res_json = await r.json(content_type=None)
                logger.info(f"submit_payment response: {res_json}")
                return res_json
        except Exception as e:
            logger.error(f"submit_payment exception: {e}")
        finally:
            if close_session:
                for cookie in session.cookie_jar:
                    self.cookies_dict[cookie.key] = cookie.value
                await session.close()
        return None

    # ─────────────────────────────────────────────
    # STEP 5: Poll Payment Result
    # ─────────────────────────────────────────────
    async def poll_payment_result(
        self,
        order_pay_no: str,
        max_retries: int = 8,
        session: aiohttp.ClientSession = None
    ) -> dict:
        """
        Polls U7BUY for payment result.
        Returns final status dict.
        """
        url = f"{self.BASE_URL}/prod-api/api/order/buyer/pay/result"
        params = {"orderPayNo": order_pay_no}
        headers = {**self.headers}
        
        close_session = False
        if session is None:
            session = aiohttp.ClientSession(cookies=self.cookies_dict)
            close_session = True
            
        try:
            for attempt in range(max_retries):
                try:
                    async with session.get(url, params=params, headers=headers, timeout=10) as r:
                        res_json = await r.json(content_type=None)
                        data = res_json.get("data", {})
                        pay_status = data.get("payStatus") if isinstance(data, dict) else None
                        
                        logger.info(f"poll attempt {attempt+1}: payStatus={pay_status}")
                        
                        # payStatus: 1=success, 2=failed, 3=pending/processing
                        if pay_status == 1:
                            return {"status": "success", "data": data}
                        elif pay_status == 2:
                            return {"status": "failed", "data": data}
                        elif pay_status == 3 or pay_status is None:
                            # 3DS redirect required or still processing
                            redirect_url = data.get("redirectUrl") if isinstance(data, dict) else None
                            if redirect_url:
                                return {"status": "3ds_required", "redirect_url": redirect_url, "data": data}
                            # Still processing, wait and retry
                            await asyncio.sleep(2)
                        else:
                            # Unknown status, stop
                            return {"status": "unknown", "data": data}
                except Exception as e:
                    logger.error(f"poll_payment_result attempt {attempt+1} failed: {e}")
                    await asyncio.sleep(2)
        finally:
            if close_session:
                for cookie in session.cookie_jar:
                    self.cookies_dict[cookie.key] = cookie.value
                await session.close()
                
        return {"status": "timeout", "data": {}}

    # ─────────────────────────────────────────────
    # MASTER: Full Payment Flow
    # ─────────────────────────────────────────────
    async def full_checkout(
        self,
        cash_info_key: str,
        card_number: str,
        exp_month: str,
        exp_year: str,
        cvc: str,
        card_holder_name: str
    ) -> dict:
        """
        Executes the complete payment flow:
        1. Create order (buy/now)
        2. Get cashier details (orderMainId, customerId)
        3. Tokenize card via Stripe
        4. Submit payment to U7BUY
        5. Poll for result
        
        Returns a dict with keys: status, message, order_id, redirect_url
        """
        # Step 1: Create order
        order_data = await self.create_order(cash_info_key)
        if order_data is None:
            return {"status": "error", "message": "Order create karna fail ho gaya. Network error."}
        if "error" in order_data:
            return {"status": "error", "message": f"Order Error: {order_data['error']}"}
        
        order_pay_no = order_data.get("orderPayNo") or order_data.get("orderMainId")
        logger.info(f"Order created: {order_data}")
        
        # Step 2: Get cashier details to ensure U7BUY has initialized order cashier page
        cashier_data = await self.get_cashier_details(cash_info_key)
        if cashier_data is None or "error" in (cashier_data or {}):
            return {"status": "error", "message": f"Cashier Error: {(cashier_data or {}).get('error', 'Unknown')}"}
        
        # Step 3: Run checkout inside headless browser to satisfy Forter telemetry
        from services.checkout_browser import execute_browser_checkout
        user_agent = self.headers.get("user-agent", "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36")
        
        logger.info("Starting background Playwright browser to bypass Forter anti-fraud checks...")
        result = await execute_browser_checkout(
            cash_info_key=cash_info_key,
            cookies_dict=self.cookies_dict,
            card_number=card_number,
            exp_month=exp_month,
            exp_year=exp_year,
            cvc=cvc,
            card_holder_name=card_holder_name,
            user_agent=user_agent,
            user_storage_str=self.user_storage_str
        )
        
        if "order_id" not in result or not result["order_id"]:
            result["order_id"] = order_pay_no
            
        return result

    # ─────────────────────────────────────────────
    # PRE-STEP A: Validate Telegram Account
    # ─────────────────────────────────────────────
    async def check_account(self, tg_username: str) -> dict:
        """
        Validates a Telegram username/ID before placing an order.
        URL: /prod-api/order/esm/check/account
        Returns {"valid": True/False, "message": "..."}
        """
        url = f"{self.BASE_URL}/prod-api/order/esm/check/account"
        payload = {
            "gameId": "2054448890268037122",
            "deliveryParam": [
                {
                    "typeName": "user_name",
                    "name": "Telegram Username",
                    "value": tg_username,
                    "valueId": ""
                }
            ]
        }
        headers = {**self.headers, "content-type": "application/json"}
        async with aiohttp.ClientSession(cookies=self.cookies_dict) as session:
            try:
                async with session.post(url, json=payload, headers=headers, timeout=15) as r:
                    res_json = await r.json(content_type=None)
                    logger.info(f"check_account response: {res_json}")
                    if res_json.get("code") == 200:
                        return {"valid": True, "message": "Account valid"}
                    else:
                        return {"valid": False, "message": res_json.get("msg", "Invalid Telegram account")}
            except Exception as e:
                logger.error(f"check_account exception: {e}")
                return {"valid": False, "message": str(e)}

    # ─────────────────────────────────────────────
    # PRE-STEP B: Save Cashier Info → Get cashInfoKey
    # ─────────────────────────────────────────────
    async def save_cashier_info(
        self,
        offer_id: str,
        tg_username: str,
        business_id: str = "1820693954263351305",
        delivery_type_id: str = "1888166069358653461"
    ) -> dict:
        """
        Calls save/cashier/info to generate cashInfoKey for Telegram Stars orders.
        URL: /prod-api/order/order/buyer/save/cashier/info
        
        IMPORTANT: productId here is the offerId from getFaceValueList response — NOT skuId!
        e.g., offerId "2062733671447224322" for 100 Stars package.
        
        Returns {"cashInfoKey": "..."} or {"error": "..."}
        """
        url = f"{self.BASE_URL}/prod-api/order/order/buyer/save/cashier/info"
        payload = {
            "businessId": business_id,
            "productId": offer_id,
            "quantity": 1,
            "deliveryParam": [
                {
                    "name": "Telegram Username",
                    "value": tg_username,
                    "typeName": "user_name"
                }
            ],
            "deliveryTypeId": delivery_type_id,
            "deliveryTypeName": "Direct Top Up"
        }
        headers = {**self.headers, "content-type": "application/json"}
        async with aiohttp.ClientSession(cookies=self.cookies_dict) as session:
            try:
                async with session.post(url, json=payload, headers=headers, timeout=15) as r:
                    res_json = await r.json(content_type=None)
                    logger.info(f"save_cashier_info response: {res_json}")
                    if res_json.get("code") == 200:
                        data = res_json.get("data")
                        # cashInfoKey can be directly the string data or nested in dict
                        if isinstance(data, str) and len(data) > 10:
                            return {"cashInfoKey": data}
                        elif isinstance(data, dict):
                            key = data.get("cashInfoKey") or data.get("cashKey") or data.get("key")
                            if key:
                                return {"cashInfoKey": key}
                        logger.warning(f"cashInfoKey not found in save_cashier_info data: {data}")
                        return {"error": f"cashInfoKey not found. Raw: {data}"}
                    else:
                        return {"error": res_json.get("msg", "save_cashier_info failed")}
            except Exception as e:
                 logger.error(f"save_cashier_info exception: {e}")
                 return {"error": str(e)}

    async def get_stripe_customer_session(
        self,
        session: aiohttp.ClientSession = None
    ) -> dict | None:
        """
        Calls payment/channel/customer/session to load Stripe Customer ID.
        URL: /prod-api/payment/channel/customer/session
        Returns data dict on success containing customerId, else None.
        """
        url = f"{self.BASE_URL}/prod-api/payment/channel/customer/session"
        params = {"channel": "STRIPE_GB"}
        headers = {**self.headers}
        
        close_session = False
        if session is None:
            session = aiohttp.ClientSession(cookies=self.cookies_dict)
            close_session = True
            
        try:
            async with session.get(url, params=params, headers=headers, timeout=15) as r:
                res_json = await r.json(content_type=None)
                logger.info(f"get_stripe_customer_session response: {res_json}")
                if res_json.get("code") == 200:
                    return res_json.get("data")
        except Exception as e:
            logger.error(f"get_stripe_customer_session exception: {e}")
        finally:
            if close_session:
                for cookie in session.cookie_jar:
                    self.cookies_dict[cookie.key] = cookie.value
                await session.close()
        return None

    # ─────────────────────────────────────────────
    # PRE-STEP D: Initialize Stripe Elements Session
    # ─────────────────────────────────────────────
    async def initialize_stripe_session(
        self,
        customer_session_secret: str,
        amount_inr: float
    ) -> dict | None:
        """
        Initializes elements session on Stripe side before tokenization.
        This notifies Stripe Radar about the checkout context.
        """
        stripe_url = "https://api.stripe.com/v1/elements/sessions"
        
        # Calculate amount in cents/paise (INR)
        amount_cents = int(float(amount_inr) * 100)
        
        params = {
            "customer_session_client_secret": customer_session_secret,
            "deferred_intent[mode]": "payment",
            "deferred_intent[amount]": str(amount_cents),
            "deferred_intent[currency]": "inr",
            "deferred_intent[payment_method_types][0]": "card",
            "currency": "inr",
            "key": STRIPE_PK,
            "_stripe_version": "2025-03-31.basil",
            "elements_init_source": "stripe.elements",
            "referrer_host": "www.u7buy.com",
            "locale": "en",
            "type": "deferred_intent"
        }
        
        stripe_headers = {
            "accept": "application/json",
            "origin": "https://js.stripe.com",
            "referer": "https://js.stripe.com/",
            "sec-ch-ua": '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": '"Android"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "user-agent": self.headers.get("user-agent", "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36"),
        }
        
        stripe_cookies = {}
        if self.cookies_dict.get("__stripe_mid"):
            stripe_cookies["__stripe_mid"] = self.cookies_dict["__stripe_mid"]
        if self.cookies_dict.get("__stripe_sid"):
            stripe_cookies["__stripe_sid"] = self.cookies_dict["__stripe_sid"]
        elif self.cookies_dict.get("stripe_sid"):
            stripe_cookies["__stripe_sid"] = self.cookies_dict["stripe_sid"]

        async with aiohttp.ClientSession(cookies=stripe_cookies) as session:
            try:
                async with session.get(stripe_url, params=params, headers=stripe_headers, timeout=15) as r:
                    res_json = await r.json(content_type=None)
                    logger.info(f"Stripe initialize elements session status: {r.status}")
                    return res_json
            except Exception as e:
                logger.error(f"Stripe initialize elements session exception: {e}")
        return None

