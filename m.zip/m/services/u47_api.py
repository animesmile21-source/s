import requests
import json
import logging
import asyncio
import uuid
import time
from config import settings

logger = logging.getLogger(__name__)

# Stripe Public Key extracted from U7BUY checkout page
STRIPE_PK = "pk_live_51QkiiYP9oVFev5vctsrZeZSKGyuDVif8KbROgGFuPmYbP38AzQy6sWjVsXCbIGfy7eg7oYdPQRNd1o9xQmUkKips00SMglMbGt"

class U7BuyApiClient:
    BASE_URL = "https://www.u7buy.com"
    
    def __init__(self, session_data_str: str, proxy_url: str = ""):
        self.session_data_str = session_data_str
        self.proxy_url = proxy_url.strip() if proxy_url else ""
        self.cookies_dict = {}
        self.access_token = ""
        self.user_storage_str = ""
        self.currency = "INR"
        self.country_code = "IN"
        self.country_name = "India"
        self.synced = False
        
        self.headers = {
            "sec-ch-ua-platform": '"Android"',
            "sec-ch-ua": '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
            "sec-ch-ua-mobile": "?1",
            "clientid": "94f670c954182e9c30535fa9cad35983",
            "user-agent": "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36",
            "content-language": "en",
            "content-currency": self.currency,
            "accept": "application/json",
            "origin": "https://www.u7buy.com",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
        }
        
        self._parse_session_data(session_data_str)
        
        # Add Authorization header if token is present
        if self.access_token:
            self.headers["Authorization"] = f"Bearer {self.access_token}"

    def _sync_request(self, method: str, url: str, **kwargs) -> requests.Response:
        # Construct proxy dict if proxy is configured
        proxy_url = self.proxy_url if self.proxy_url else (settings.PROXY_URL.strip() if settings.PROXY_URL else "")
        proxies = None
        if proxy_url:
            proxies = {"http": proxy_url, "https": proxy_url}

            
        CF_BLOCKED_COOKIES = {
            "__cf_bm", "__cflb", "_cfuvid", "cf_clearance",
            "__cfruid", "__cfwaitingroom"
        }
        clean_cookies = {
            k: v for k, v in self.cookies_dict.items()
            if k not in CF_BLOCKED_COOKIES
        }
        
        headers = kwargs.pop("headers", self.headers.copy())
        cookies = kwargs.pop("cookies", clean_cookies)
        
        r = requests.request(
            method=method,
            url=url,
            headers=headers,
            cookies=cookies,
            proxies=proxies,
            **kwargs
        )
        
        # Save returned cookies back
        for name, value in r.cookies.items():
            self.cookies_dict[name] = value
            
        return r

    async def _request(self, method: str, url: str, **kwargs) -> requests.Response:
        """
        Runs self._sync_request in a separate thread to prevent blocking the async loop.
        """
        return await asyncio.to_thread(self._sync_request, method, url, **kwargs)

    def _parse_session_data(self, data_str: str):
        """
        Parses session data which can be either the Console script JSON
        or the standard Cookie-Editor JSON array.
        """
        if not data_str:
            return
            
        # Clean up copy-paste non-breaking space characters (NBSP)
        cleaned_str = data_str.replace("\u00a0", " ").replace("\xa0", " ").strip()
            
        try:
            parsed = json.loads(cleaned_str)
            
            # 1. Check if it's the browser console script JSON format
            if isinstance(parsed, dict) and ("user" in parsed or "cookies" in parsed):
                # Parse cookies string
                cookies_str = parsed.get("cookies", "")
                if cookies_str:
                    for item in cookies_str.split(";"):
                        if "=" in item:
                            k, v = item.strip().split("=", 1)
                            self.cookies_dict[k] = v
                
                # Save user local storage JSON string
                self.user_storage_str = parsed.get("user", "")
                
                # Try to extract accessToken from u7CookieConfig cookie first (most reliable)
                if "u7CookieConfig" in self.cookies_dict:
                    try:
                        import urllib.parse
                        decoded = urllib.parse.unquote(self.cookies_dict["u7CookieConfig"])
                        config = json.loads(decoded)
                        self.access_token = config.get("state", {}).get("accessToken", "")
                        self.currency = config.get("state", {}).get("defaultCurrency", "INR")
                        self.headers["content-currency"] = self.currency
                    except Exception:
                        pass
                
                # Fallback: Parse user info to extract accessToken if cookie didn't yield one
                if not self.access_token:
                    user_str = self.user_storage_str
                    if user_str:
                        try:
                            user_info = json.loads(user_str)
                            self.access_token = user_info.get("state", {}).get("userInfo", {}).get("accessToken", "")
                        except Exception:
                            pass
                        
            # 2. Check if it's the standard Cookie-Editor JSON array format
            elif isinstance(parsed, list):
                for cookie in parsed:
                    name = cookie.get("name")
                    value = cookie.get("value")
                    if name and value is not None:
                        self.cookies_dict[name] = value
                        if name == "u7CookieConfig":
                            try:
                                import urllib.parse
                                decoded = urllib.parse.unquote(value)
                                config = json.loads(decoded)
                                self.access_token = config.get("state", {}).get("accessToken", "")
                                self.currency = config.get("state", {}).get("defaultCurrency", "INR")
                                self.headers["content-currency"] = self.currency
                            except Exception:
                                pass
        except Exception as e:
            logger.error(f"Error parsing session data: {e}")

    async def sync_regional_configuration(self) -> str:
        """
        Hits /api/configuration?refresh=true using the proxy to let U7BUY auto-detect
        and set the country/currency correctly.
        """
        if self.synced:
            return self.currency
            
        url = f"{self.BASE_URL}/api/configuration?refresh=true"
        logger.info("Syncing regional preferences via proxy for IP alignment...")
        try:
            r = await self._request("GET", url, timeout=15)
            if r.status_code == 200:
                res_json = r.json()
                if res_json.get("code") == 200:
                    data = res_json.get("data", {})
                    new_currency = data.get("defaultCurrency", "INR")
                    self.country_code = data.get("countryCode", "IN")
                    self.country_name = data.get("countryName", "India")
                    logger.info(f"Auto-sync completed. Proxy location: {self.country_name} ({self.country_code}), currency detected: {new_currency}")
                    self.currency = new_currency
                    self.headers["content-currency"] = self.currency
                    
                    # Update u7CookieConfig cookie value
                    if "u7CookieConfig" in self.cookies_dict:
                        try:
                            import urllib.parse
                            decoded = urllib.parse.unquote(self.cookies_dict["u7CookieConfig"])
                            config = json.loads(decoded)
                            config["state"]["defaultCurrency"] = self.currency
                            self.cookies_dict["u7CookieConfig"] = urllib.parse.quote(json.dumps(config))
                            logger.info("Updated u7CookieConfig cookie with synced currency.")
                        except Exception as ce:
                            logger.warning(f"Error updating u7CookieConfig cookie: {ce}")
                    self.synced = True
                    return self.currency
            logger.warning(f"Regional sync returned status {r.status_code} | response: {r.text[:200]}")
        except Exception as e:
            logger.error(f"Regional sync request failed: {e}")
        return self.currency

    async def validate_session(self) -> dict | None:
        """
        Validates the current session by calling U7BUY member status API.
        Returns user profile info if successful, else None.
        """
        # Auto-sync regional preferences first to ensure correct headers and state
        await self.sync_regional_configuration()
        
        url = f"{self.BASE_URL}/prod-api/member/activity/v1/status"
        logger.info(f"[validate_session] access_token present: {bool(self.access_token)} | cookies count: {len(self.cookies_dict)}")
        try:
            r = await self._request("GET", url, timeout=10)
            if r.status_code == 200:
                res_json = r.json()
                if res_json.get("code") == 200 or "data" in res_json:
                    return res_json.get("data", res_json)
            logger.warning(f"Session validation failed, status code: {r.status_code} | body: {r.text[:300]}")
        except Exception as e:
            logger.error(f"Session validation request failed: {e}")
        return None

    async def get_google_play_products(self) -> list:
        """
        Fetches the Google Play gift cards list from U7BUY and filters for proxy region/currency.
        """
        await self.sync_regional_configuration()
        url = f"{self.BASE_URL}/prod-api/product/urlMapping/digital/getVirtualProductSkuListByUrl"
        params = {
            "pageNum": "1",
            "pageSize": "100",
            "sortRule": "default",
            "url": "/gift-cards/google-play",
            "regionFlag": "true"
        }
        try:
            r = await self._request("GET", url, params=params, timeout=10)
            if r.status_code == 200:
                res_json = r.json()
                raw_rows = res_json.get("data", {}).get("productVirtualSkuVoTableDataInfo", {}).get("rows", [])
                
                # Filter dynamically based on proxy country/currency
                target_country = self.country_name.strip().lower()
                target_currency = self.currency.strip().lower()
                
                logger.info(f"Filtering Google Play cards for proxy region: {self.country_name} ({self.currency})")
                filtered_cards = []
                for item in raw_rows:
                    region = item.get("regionInfo", "").strip().lower()
                    sku_name = item.get("skuName", "").lower()
                    if (region == target_country or 
                        target_country in sku_name or 
                        target_currency in sku_name):
                        filtered_cards.append({
                            "skuId": str(item.get("id")),
                            "skuName": item.get("skuName"),
                            "skuPrice": item.get("fromPrice"),
                            "skuUrl": item.get("skuUrl", "")
                        })
                return filtered_cards
            else:
                logger.error(f"Failed to fetch GP products: HTTP {r.status_code} | body: {r.text[:300]}")
        except Exception as e:
            logger.error(f"Error fetching Google Play products: {e}")
        return []

    async def get_telegram_stars_products(self) -> list:
        """
        Fetches Telegram Stars and Premium packages from U7BUY.
        """
        url = f"{self.BASE_URL}/prod-api/product/urlMapping/topUpProductInfo/getFaceValueList"
        params = {
            "spuId": "2054448890293202946",
            "categoryId": "2034807242400006145",
            "deliveryId": "1888166069358653461",
            "areaId": "1888074791040151609"
        }
        try:
            r = await self._request("GET", url, params=params, timeout=10)
            if r.status_code == 200:
                res_json = r.json()
                raw_list = res_json.get("data", [])
                
                products = []
                for item in raw_list:
                    products.append({
                        "skuId": str(item.get("skuId")),
                        "offerId": str(item.get("offerId")),   # This is the productId for save/cashier/info
                        "skuName": item.get("faceValue"),
                        "skuPrice": item.get("price")
                    })
                return products
            else:
                logger.error(f"Failed to fetch Telegram Stars: HTTP {r.status_code} | body: {r.text[:300]}")
        except Exception as e:
            logger.error(f"Error fetching Telegram Stars products: {e}")
        return []

    # ─────────────────────────────────────────────
    # STEP 1: Create Order → Get cashInfoKey
    # ─────────────────────────────────────────────
    async def create_order(
        self,
        cash_info_key: str,
        pay_channel: str = "STRIPE_GB",
        session = None
    ) -> dict | None:
        """
        Calls buy/now to generate an order and get orderMainId.
        """
        await self.sync_regional_configuration()
        url = f"{self.BASE_URL}/prod-api/api/order/buyer/buy/now"
        payload = {
            "balanceFlag": 0,
            "currency": self.currency,
            "discountType": 0,
            "payChannel": pay_channel,
            "paymentMethod": "iframe",
            "cashInfoKey": cash_info_key,
            "autoSelectCoupon": False
        }
        headers = {**self.headers, "content-type": "application/json"}
        
        try:
            r = await self._request("POST", url, json=payload, headers=headers, timeout=15)
            res_json = r.json()
            logger.info(f"create_order response: {res_json}")
            if res_json.get("code") == 200:
                return res_json.get("data")
            else:
                logger.warning(f"create_order failed: {res_json.get('msg')}")
                return {"error": res_json.get("msg", "Order creation failed")}
        except Exception as e:
            logger.error(f"create_order exception: {e}")
        return None

    # ─────────────────────────────────────────────
    # STEP 2: Get cashier details (orderMainId)
    # ─────────────────────────────────────────────
    async def get_cashier_details(
        self,
        cash_info_key: str,
        session = None
    ) -> dict | None:
        """
        Fetches cashier page data including orderMainId and customerId.
        """
        await self.sync_regional_configuration()
        url = f"{self.BASE_URL}/prod-api/api/order/buyer/cashier"
        payload = {
            "balanceFlag": 0,
            "currency": self.currency,
            "discountType": 0,
            "cashInfoKey": cash_info_key
        }
        headers = {**self.headers, "content-type": "application/json"}
        
        try:
            r = await self._request("POST", url, json=payload, headers=headers, timeout=15)
            res_json = r.json()
            logger.info(f"get_cashier_details response: {res_json}")
            if res_json.get("code") == 200:
                return res_json.get("data")
            else:
                return {"error": res_json.get("msg", "Cashier fetch failed")}
        except Exception as e:
            logger.error(f"get_cashier_details exception: {e}")
        return None

    # ─────────────────────────────────────────────
    # STEP 3: Tokenize card with Stripe
    # ─────────────────────────────────────────────
    async def tokenize_card_stripe(
        self,
        card_number: str,
        exp_month: str,
        exp_year: str,
        cvc: str,
        customer_id: str
    ) -> dict:
        """
        Sends card details to Stripe to get a confirmation_token (ctoken_xxx).
        """
        stripe_url = "https://api.stripe.com/v1/confirmation_tokens"
        
        # Load Stripe session identifiers from cookies to match browser fingerprint
        muid = self.cookies_dict.get("__stripe_mid", "")
        sid = self.cookies_dict.get("__stripe_sid", "") or self.cookies_dict.get("stripe_sid", "")
        
        if not muid:
            muid = str(uuid.uuid4())
        if not sid:
            sid = str(uuid.uuid4())
            
        client_session_id = str(uuid.uuid4())
        elements_session_id = f"elements_session_{uuid.uuid4().hex[:12]}"
        
        data = {
            "payment_method_data[allow_redisplay]": "always",
            "payment_method_data[type]": "card",
            "payment_method_data[card][number]": card_number.replace(" ", ""),
            "payment_method_data[card][cvc]": cvc,
            "payment_method_data[card][exp_year]": exp_year,
            "payment_method_data[card][exp_month]": exp_month,
            "payment_method_data[payment_user_agent]": "stripe.js/4c502f49d8; stripe-js-v3/4c502f49d8; payment-element; deferred-intent",
            "payment_method_data[referrer]": "https://www.u7buy.com",
            "payment_method_data[time_on_page]": str(int(time.time() * 1000) % 1000000),
            "payment_method_data[client_attribution_metadata][client_session_id]": client_session_id,
            "payment_method_data[client_attribution_metadata][merchant_integration_source]": "elements",
            "payment_method_data[client_attribution_metadata][merchant_integration_subtype]": "payment-element",
            "payment_method_data[client_attribution_metadata][merchant_integration_version]": "2021",
            "payment_method_data[client_attribution_metadata][payment_intent_creation_flow]": "deferred",
            "payment_method_data[client_attribution_metadata][payment_method_selection_flow]": "merchant_specified",
            "payment_method_data[client_attribution_metadata][elements_session_id]": elements_session_id,
            "payment_method_data[client_attribution_metadata][merchant_integration_additional_elements][0]": "payment",
            "payment_method_data[guid]": str(uuid.uuid4()),
            "payment_method_data[muid]": muid,
            "payment_method_data[sid]": sid,
            "client_context[currency]": self.currency.lower(),
            "client_context[mode]": "payment",
            "client_context[payment_method_types][0]": "card",
            "client_attribution_metadata[client_session_id]": client_session_id,
            "client_attribution_metadata[merchant_integration_source]": "elements",
            "client_attribution_metadata[merchant_integration_subtype]": "payment-element",
            "client_attribution_metadata[merchant_integration_version]": "2021",
            "client_attribution_metadata[payment_intent_creation_flow]": "deferred",
            "client_attribution_metadata[payment_method_selection_flow]": "merchant_specified",
            "client_attribution_metadata[elements_session_id]": elements_session_id,
            "client_attribution_metadata[merchant_integration_additional_elements][0]": "payment",
            "set_as_default_payment_method": "false",
            "key": STRIPE_PK,
            "_stripe_version": "2025-03-31.basil"
        }
        
        if customer_id:
            data["client_context[customer]"] = customer_id
        
        stripe_headers = {
            "accept": "application/json",
            "content-type": "application/x-www-form-urlencoded",
            "origin": "https://js.stripe.com",
            "referer": "https://js.stripe.com/",
            "sec-ch-ua": '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": '"Android"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "user-agent": self.headers.get("user-agent", "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36"),
        }
        
        stripe_cookies = {}
        if self.cookies_dict.get("__stripe_mid"):
            stripe_cookies["__stripe_mid"] = self.cookies_dict["__stripe_mid"]
        if self.cookies_dict.get("__stripe_sid"):
            stripe_cookies["__stripe_sid"] = self.cookies_dict["__stripe_sid"]
        elif self.cookies_dict.get("stripe_sid"):
            stripe_cookies["__stripe_sid"] = self.cookies_dict["stripe_sid"]
            
        try:
            r = await self._request("POST", stripe_url, data=data, headers=stripe_headers, cookies=stripe_cookies, timeout=20)
            res_json = r.json()
            logger.info(f"Stripe tokenize response status: {r.status_code}, id: {res_json.get('id')}, error: {res_json.get('error')}")
            
            if r.status_code == 200 and res_json.get("id"):
                token = res_json["id"]
                return {"token": token, "stored": "1"}
            else:
                error = res_json.get("error", {})
                error_msg = error.get("message", "Card tokenization failed")
                decline_code = error.get("decline_code", "")
                error_code = error.get("code", "")
                return {
                    "error": error_msg,
                    "decline_code": decline_code,
                    "error_code": error_code
                }
        except Exception as e:
            logger.error(f"Stripe tokenize exception: {e}")
            return {"error": str(e)}

    # ─────────────────────────────────────────────
    # STEP 4: Submit Payment to U7BUY
    # ─────────────────────────────────────────────
    async def submit_payment(
        self,
        order_main_id: str,
        payment_token: str,
        customer_id: str,
        card_holder_name: str,
        cash_info_key: str,
        stored: str = "1",
        session = None
    ) -> dict | None:
        """
        Submits the Stripe confirmation token to U7BUY to complete payment.
        """
        url = f"{self.BASE_URL}/prod-api/api/order/buyer/pay"
        payload = {
            "orderMainId": order_main_id,
            "stored": stored,
            "customerId": customer_id,
            "paymentMethodToken": payment_token,
            "cardHolderName": card_holder_name
        }
        
        pay_headers = {
            **self.headers,
            "content-type": "application/json",
            "Referer": f"https://www.u7buy.com/cashier?cashInfoKey={cash_info_key}&buyMin=1"
        }
        
        try:
            r = await self._request("POST", url, json=payload, headers=pay_headers, timeout=20)
            res_json = r.json()
            logger.info(f"submit_payment response: {res_json}")
            return res_json
        except Exception as e:
            logger.error(f"submit_payment exception: {e}")
        return None

    # ─────────────────────────────────────────────
    # STEP 5: Poll Payment Result
    # ─────────────────────────────────────────────
    async def poll_payment_result(
        self,
        order_pay_no: str,
        max_retries: int = 8,
        session = None
    ) -> dict:
        """
        Polls U7BUY for payment result.
        """
        url = f"{self.BASE_URL}/prod-api/api/order/buyer/pay/result"
        params = {"orderPayNo": order_pay_no}
        headers = {**self.headers}
        
        try:
            for attempt in range(max_retries):
                try:
                    r = await self._request("GET", url, params=params, headers=headers, timeout=10)
                    res_json = r.json()
                    data = res_json.get("data", {})
                    pay_status = data.get("payStatus") if isinstance(data, dict) else None
                    
                    logger.info(f"poll attempt {attempt+1}: payStatus={pay_status}")
                    
                    if pay_status == 1:
                        return {"status": "success", "data": data}
                    elif pay_status == 2:
                        return {"status": "failed", "data": data}
                    elif pay_status == 3 or pay_status is None:
                        redirect_url = data.get("redirectUrl") if isinstance(data, dict) else None
                        if redirect_url:
                            return {"status": "3ds_required", "redirect_url": redirect_url, "data": data}
                        await asyncio.sleep(2)
                    else:
                        return {"status": "unknown", "data": data}
                except Exception as e:
                    logger.error(f"poll_payment_result attempt {attempt+1} failed: {e}")
                    await asyncio.sleep(2)
        except Exception as e:
            logger.error(f"poll_payment_result exception: {e}")
            
        return {"status": "timeout", "data": {}}

    # ─────────────────────────────────────────────
    # MASTER: Full Payment Flow
    # ─────────────────────────────────────────────
    async def full_checkout(
        self,
        cash_info_key: str,
        card_number: str,
        exp_month: str,
        exp_year: str,
        cvc: str,
        card_holder_name: str,
        captcha_token: str = ""
    ) -> dict:
        """
        Executes the complete payment flow.
        """
        await self.sync_regional_configuration()
        order_data = await self.create_order(cash_info_key)
        if order_data is None:
            return {"status": "error", "message": "Order create karna fail ho gaya. Network error."}
        if "error" in order_data:
            return {"status": "error", "message": f"Order Error: {order_data['error']}"}
        
        order_pay_no = order_data.get("orderPayNo") or order_data.get("orderMainId")
        logger.info(f"Order created: {order_data}")
        
        cashier_data = await self.get_cashier_details(cash_info_key)
        if cashier_data is None or "error" in (cashier_data or {}):
            return {"status": "error", "message": f"Cashier Error: {(cashier_data or {}).get('error', 'Unknown')}"}
        
        from services.checkout_browser import execute_browser_checkout
        user_agent = self.headers.get("user-agent", "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36")
        
        logger.info("Starting background Playwright browser to bypass Forter anti-fraud checks...")
        result = await execute_browser_checkout(
            cash_info_key=cash_info_key,
            cookies_dict=self.cookies_dict,
            card_number=card_number,
            exp_month=exp_month,
            exp_year=exp_year,
            cvc=cvc,
            card_holder_name=card_holder_name,
            user_agent=user_agent,
            user_storage_str=self.user_storage_str,
            captcha_token=captcha_token,
            proxy_url=self.proxy_url
        )

        
        if "order_id" not in result or not result["order_id"]:
            result["order_id"] = order_pay_no
            
        return result


    # ─────────────────────────────────────────────
    # PRE-STEP A: Validate Telegram Account
    # ─────────────────────────────────────────────
    async def check_account(self, tg_username: str) -> dict:
        """
        Validates a Telegram username/ID before placing an order.
        """
        url = f"{self.BASE_URL}/prod-api/order/esm/check/account"
        payload = {
            "gameId": "2054448890268037122",
            "deliveryParam": [
                {
                    "typeName": "user_name",
                    "name": "Telegram Username",
                    "value": tg_username,
                    "valueId": ""
                }
            ]
        }
        headers = {**self.headers, "content-type": "application/json"}
        try:
            r = await self._request("POST", url, json=payload, headers=headers, timeout=15)
            res_json = r.json()
            logger.info(f"check_account response: {res_json}")
            if res_json.get("code") == 200:
                return {"valid": True, "message": "Account valid"}
            else:
                return {"valid": False, "message": res_json.get("msg", "Invalid Telegram account")}
        except Exception as e:
            logger.error(f"check_account exception: {e}")
            return {"valid": False, "message": str(e)}

    # ─────────────────────────────────────────────
    # PRE-STEP B: Save Cashier Info → Get cashInfoKey
    # ─────────────────────────────────────────────
    async def save_cashier_info(
        self,
        offer_id: str,
        tg_username: str,
        business_id: str = "1820693954263351305",
        delivery_type_id: str = "1888166069358653461"
    ) -> dict:
        """
        Calls save/cashier/info to generate cashInfoKey for Telegram Stars orders.
        """
        await self.sync_regional_configuration()
        url = f"{self.BASE_URL}/prod-api/order/order/buyer/save/cashier/info"
        payload = {
            "businessId": business_id,
            "productId": offer_id,
            "quantity": 1,
            "deliveryParam": [
                {
                    "name": "Telegram Username",
                    "value": tg_username,
                    "typeName": "user_name"
                }
            ],
            "deliveryTypeId": delivery_type_id,
            "deliveryTypeName": "Direct Top Up"
        }
        headers = {**self.headers, "content-type": "application/json"}
        try:
            r = await self._request("POST", url, json=payload, headers=headers, timeout=15)
            res_json = r.json()
            logger.info(f"save_cashier_info response: {res_json}")
            if res_json.get("code") == 200:
                data = res_json.get("data")
                if isinstance(data, str) and len(data) > 10:
                    return {"cashInfoKey": data}
                elif isinstance(data, dict):
                    key = data.get("cashInfoKey") or data.get("cashKey") or data.get("key")
                    if key:
                        return {"cashInfoKey": key}
                logger.warning(f"cashInfoKey not found in save_cashier_info data: {data}")
                return {"error": f"cashInfoKey not found. Raw: {data}"}
            else:
                return {"error": res_json.get("msg", "save_cashier_info failed")}
        except Exception as e:
             logger.error(f"save_cashier_info exception: {e}")
             return {"error": str(e)}

    async def get_stripe_customer_session(
        self,
        session = None
    ) -> dict | None:
        """
        Calls payment/channel/customer/session to load Stripe Customer ID.
        """
        url = f"{self.BASE_URL}/prod-api/payment/channel/customer/session"
        params = {"channel": "STRIPE_GB"}
        headers = {**self.headers}
        
        try:
            r = await self._request("GET", url, params=params, headers=headers, timeout=15)
            res_json = r.json()
            logger.info(f"get_stripe_customer_session response: {res_json}")
            if res_json.get("code") == 200:
                return res_json.get("data")
        except Exception as e:
            logger.error(f"get_stripe_customer_session exception: {e}")
        return None

    # ─────────────────────────────────────────────
    # PRE-STEP D: Initialize Stripe Elements Session
    # ─────────────────────────────────────────────
    async def initialize_stripe_session(
        self,
        customer_session_secret: str,
        amount_inr: float
    ) -> dict | None:
        """
        Initializes elements session on Stripe side before tokenization.
        """
        stripe_url = "https://api.stripe.com/v1/elements/sessions"
        amount_cents = int(float(amount_inr) * 100)
        
        params = {
            "customer_session_client_secret": customer_session_secret,
            "deferred_intent[mode]": "payment",
            "deferred_intent[amount]": str(amount_cents),
            "deferred_intent[currency]": self.currency.lower(),
            "deferred_intent[payment_method_types][0]": "card",
            "currency": self.currency.lower(),
            "key": STRIPE_PK,
            "_stripe_version": "2025-03-31.basil",
            "elements_init_source": "stripe.elements",
            "referrer_host": "www.u7buy.com",
            "locale": "en",
            "type": "deferred_intent"
        }
        
        stripe_headers = {
            "accept": "application/json",
            "origin": "https://js.stripe.com",
            "referer": "https://js.stripe.com/",
            "sec-ch-ua": '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": '"Android"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "user-agent": self.headers.get("user-agent", "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36"),
        }
        
        stripe_cookies = {}
        if self.cookies_dict.get("__stripe_mid"):
            stripe_cookies["__stripe_mid"] = self.cookies_dict["__stripe_mid"]
        if self.cookies_dict.get("__stripe_sid"):
            stripe_cookies["__stripe_sid"] = self.cookies_dict["__stripe_sid"]
        elif self.cookies_dict.get("stripe_sid"):
            stripe_cookies["__stripe_sid"] = self.cookies_dict["stripe_sid"]

        try:
            r = await self._request("GET", stripe_url, params=params, headers=stripe_headers, cookies=stripe_cookies, timeout=15)
            res_json = r.json()
            logger.info(f"Stripe initialize elements session status: {r.status_code}")
            return res_json
        except Exception as e:
            logger.error(f"Stripe initialize elements session exception: {e}")
        return None
