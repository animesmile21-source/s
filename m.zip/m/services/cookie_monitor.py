"""
Cookie Health Monitor
Checks all accounts every 6 hours. Sends expiry alerts to OWNER.
Alert includes: proxy, email, account ID, time remaining.
"""
import asyncio
import base64
import json
import time
import logging
from datetime import datetime, timezone

from aiogram import Bot
from database import db
from config import settings

logger = logging.getLogger(__name__)

OWNER_ID = settings.OWNER_ID


def decode_jwt_expiry(token: str) -> int | None:
    try:
        parts = token.split(".")
        if len(parts) < 2:
            return None
        payload_b64 = parts[1]
        payload_b64 += "=" * ((4 - len(payload_b64) % 4) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64))
        return payload.get("exp")
    except Exception:
        return None


def get_token_status(access_token: str) -> dict:
    if not access_token:
        return {"status": "no_token", "expires_in_hours": None, "expires_at_str": None}
    exp_ts = decode_jwt_expiry(access_token)
    if not exp_ts:
        return {"status": "valid", "expires_in_hours": None, "expires_at_str": None}
    now_ts = int(time.time())
    diff_secs = exp_ts - now_ts
    hours_left = diff_secs / 3600
    expires_str = datetime.fromtimestamp(exp_ts, tz=timezone.utc).strftime("%d %b %Y %H:%M UTC")
    if diff_secs <= 0:
        return {"status": "expired", "expires_in_hours": 0, "expires_at_str": expires_str}
    elif hours_left <= 48:
        return {"status": "expiring_soon", "expires_in_hours": round(hours_left, 1), "expires_at_str": expires_str}
    else:
        return {"status": "valid", "expires_in_hours": round(hours_left, 1), "expires_at_str": expires_str}


def quick_token_check(cookies_json: str) -> dict:
    """
    Local JWT check — no API call. Used before payments.
    Returns: {ok: bool, status: str, message: str}
    """
    if not cookies_json:
        return {"ok": False, "status": "no_session",
                "message": "❌ No session configured. Contact owner."}
    try:
        from services.u47_api import U7BuyApiClient
        client = U7BuyApiClient(cookies_json)
    except Exception:
        return {"ok": False, "status": "parse_error",
                "message": "❌ Session data corrupt. Contact owner."}

    ts = get_token_status(client.access_token)
    status = ts["status"]
    hours_left = ts["expires_in_hours"]

    if status == "expired":
        return {"ok": False, "status": "expired",
                "message": "❌ *Session Expired!*\n\nContact owner to refresh cookies."}
    elif status == "expiring_soon":
        return {"ok": True, "status": "expiring_soon",
                "message": f"⚠️ *Warning:* Session expires in *{hours_left}h*. Owner will be notified."}
    else:
        return {"ok": True, "status": "valid", "message": ""}


async def check_all_accounts(bot: Bot):
    """Check all owner-managed accounts and alert owner on expiry."""
    accounts = await db.list_all_accounts()
    logger.info(f"[CookieMonitor] Checking {len(accounts)} accounts...")

    for account in accounts:
        acc_id = account.get("id")
        email = account.get("email", "Unknown")
        proxy_id = account.get("proxy_id", "N/A")
        cookies_json = account.get("cookies_json", "")

        if not cookies_json:
            continue

        try:
            from services.u47_api import U7BuyApiClient
            proxy_url = ""
            if proxy_id and proxy_id != "N/A":
                p = await db.get_proxy(proxy_id)
                if p:
                    proxy_url = p.get("url", "")
            client = U7BuyApiClient(cookies_json, proxy_url=proxy_url)

            
            # 1. Local JWT expiry check
            ts = get_token_status(client.access_token)
            status = ts["status"]
            hours_left = ts["expires_in_hours"]
            expires_str = ts["expires_at_str"]

            # 2. Server-side API validation
            session_data = await client.validate_session()
            if not session_data:
                # Token is either invalid, logged out, or frozen on the server
                status = "expired"
                expires_str = "Frozen / Invalidated by U7BUY"
                hours_left = 0
                logger.warning(f"[CookieMonitor] Account {acc_id} ({email}) failed server-side validation (frozen/invalid).")
        except Exception as e:
            logger.warning(f"[CookieMonitor] Cannot parse/validate account {acc_id}: {e}")
            continue

        logger.info(f"[CookieMonitor] Account {acc_id} ({email}): {status}, {hours_left}h left")

        if status == "expired":
            msg = (
                f"🔴 *Cookie EXPIRED / FROZEN — Action Required!*\n\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"🆔 Account: `{acc_id}`\n"
                f"📧 Email: `{email}`\n"
                f"🖥️ Proxy: `{proxy_id}`\n"
                f"⚠️ Status: `Frozen / Invalid (401)`\n"
                f"━━━━━━━━━━━━━━━━━━\n\n"
                f"👉 Refresh cookies via:\n"
                f"`/admin` → Account Pool → 🔄 Refresh Cookies → `{acc_id}`"
            )
            try:
                await bot.send_message(chat_id=OWNER_ID, text=msg, parse_mode="Markdown")
            except Exception as e:
                logger.error(f"Failed to send expired alert: {e}")

        elif status == "expiring_soon":
            msg = (
                f"🟡 *Cookie Expiry Warning!*\n\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"🆔 Account: `{acc_id}`\n"
                f"📧 Email: `{email}`\n"
                f"🖥️ Proxy: `{proxy_id}`\n"
                f"⏳ Expires in: *{hours_left}h*\n"
                f"📅 Expiry: `{expires_str}`\n"
                f"━━━━━━━━━━━━━━━━━━\n\n"
                f"Refresh before it expires:\n"
                f"`/admin` → Account Pool → 🔄 Refresh → `{acc_id}`"
            )
            try:
                await bot.send_message(chat_id=OWNER_ID, text=msg, parse_mode="Markdown")
            except Exception as e:
                logger.error(f"Failed to send expiry warning: {e}")

        await asyncio.sleep(0.3)


async def run_cookie_monitor(bot: Bot, check_interval_hours: float = 6.0):
    """Background loop: check cookies every N hours."""
    logger.info(f"[CookieMonitor] Started — interval: {check_interval_hours}h")
    interval_secs = check_interval_hours * 3600

    while True:
        try:
            await check_all_accounts(bot)
            logger.info(f"[CookieMonitor] Done. Next check in {check_interval_hours}h")
        except Exception as e:
            logger.error(f"[CookieMonitor] Error: {e}")
        await asyncio.sleep(interval_secs)


def serialize_cookies(client, original_str: str) -> str:
    if not original_str:
        return ""
    cleaned_str = original_str.replace("\u00a0", " ").replace("\xa0", " ").strip()
    try:
        parsed = json.loads(cleaned_str)
        if isinstance(parsed, dict) and ("user" in parsed or "cookies" in parsed):
            cookies_str = "; ".join([f"{k}={v}" for k, v in client.cookies_dict.items()])
            # Update user storage accessToken if changed
            user_str = parsed.get("user", "")
            if user_str:
                try:
                    user_info = json.loads(user_str)
                    if "state" in user_info and "userInfo" in user_info["state"]:
                        user_info["state"]["userInfo"]["accessToken"] = client.access_token
                    user_str = json.dumps(user_info, ensure_ascii=False)
                except Exception:
                    pass
            return json.dumps({
                "user": user_str,
                "cookies": cookies_str
            }, ensure_ascii=False)
        elif isinstance(parsed, list):
            updated_list = []
            for name, value in client.cookies_dict.items():
                updated_list.append({
                    "name": name,
                    "value": value,
                    "domain": "www.u7buy.com" if "stripe" not in name else ".stripe.com",
                    "path": "/"
                })
            return json.dumps(updated_list, ensure_ascii=False)
    except Exception as e:
        logger.error(f"Error serializing cookies: {e}")
    return original_str


async def keep_alive_all_sessions(bot: Bot):
    logger.info("[SessionKeeper] Starting periodic keep-alive check for all active sessions...")
    
    # 1. Owner Accounts Keep-Alive
    accounts = await db.list_all_accounts()
    for account in accounts:
        acc_id = account.get("id")
        email = account.get("email", "Unknown")
        proxy_id = account.get("proxy_id", "N/A")
        cookies_json = account.get("cookies_json", "")

        if not cookies_json:
            continue

        try:
            from services.u47_api import U7BuyApiClient
            proxy_url = ""
            if proxy_id and proxy_id != "N/A":
                p = await db.get_proxy(proxy_id)
                if p:
                    proxy_url = p.get("url", "")
            client = U7BuyApiClient(cookies_json, proxy_url=proxy_url)
            
            # Send keep-alive ping
            session_data = await client.validate_session()
            if session_data:
                # Session is active, serialize and update cookies if they changed
                new_cookies_json = serialize_cookies(client, cookies_json)
                if new_cookies_json and new_cookies_json != cookies_json:
                    await db.refresh_account_cookies(
                        account_id=acc_id,
                        cookies_json=new_cookies_json,
                        access_token_exp=decode_jwt_expiry(client.access_token) or 0,
                        email=email
                    )
                    logger.info(f"[SessionKeeper] Updated cookies in DB for owner account {acc_id} ({email})")
            else:
                logger.warning(f"[SessionKeeper] Owner account {acc_id} ({email}) session is inactive/failed validate_session.")
        except Exception as e:
            logger.error(f"[SessionKeeper] Error processing owner account {acc_id} keep-alive: {e}")
            
        await asyncio.sleep(0.5)

    # 2. Users Custom Cookies Keep-Alive
    users = await db.list_users()
    for user in users:
        if not user.get("active"):
            continue
            
        tg_id = user.get("tg_id")
        custom_cookies = user.get("custom_cookies", {})
        custom_emails = user.get("custom_emails", {})
        proxy_id = user.get("proxy_id", "")
        
        for slot in ["slot1", "slot2"]:
            slot_num = 1 if slot == "slot1" else 2
            cookies_json = custom_cookies.get(slot)
            if not cookies_json:
                continue
                
            email = custom_emails.get(slot, "Custom Account")
            
            try:
                from services.u47_api import U7BuyApiClient
                proxy_url = ""
                if proxy_id:
                    p = await db.get_proxy(proxy_id)
                    if p:
                        proxy_url = p.get("url", "")
                client = U7BuyApiClient(cookies_json, proxy_url=proxy_url)
                
                # Send keep-alive ping
                session_data = await client.validate_session()
                if session_data:
                    # Session active, serialize and update if changed
                    new_cookies_json = serialize_cookies(client, cookies_json)
                    if new_cookies_json and new_cookies_json != cookies_json:
                        await db.update_user_custom_cookies(
                            tg_id=tg_id,
                            slot=slot_num,
                            cookies_json=new_cookies_json,
                            email=email
                        )
                        logger.info(f"[SessionKeeper] Updated custom cookies in DB for user {tg_id} slot {slot_num} ({email})")
                else:
                    logger.warning(f"[SessionKeeper] User {tg_id} slot {slot_num} ({email}) session is inactive/failed validate_session.")
            except Exception as e:
                logger.error(f"[SessionKeeper] Error processing user {tg_id} custom slot {slot_num} keep-alive: {e}")
                
            await asyncio.sleep(0.5)


async def run_session_keeper(bot: Bot, interval_minutes: float = 10.0):
    logger.info(f"[SessionKeeper] Started — interval: {interval_minutes}m")
    interval_secs = interval_minutes * 60
    while True:
        try:
            await keep_alive_all_sessions(bot)
        except Exception as e:
            logger.error(f"[SessionKeeper] Critical error in loop: {e}")
        await asyncio.sleep(interval_secs)

