"""
Cookie Health Monitor — Session Keep-Alive System
──────────────────────────────────────────────────
CONFIRMED (via live testing):
  - U7Buy has NO refresh token endpoint (all return 404)
  - The refreshToken in JWT/cookies is client-side only
  - Session stays alive as long as we keep calling validate_session
  - Server kills session after ~5h of INACTIVITY (not hard expiry)

REAL FIX:
  Keep calling validate_session() every 4 minutes to prove the session
  is still in use. Track when session was last confirmed ALIVE.
  If validate_session() returns None → session is truly dead → alert owner.

NOTIFICATIONS (real, not fake):
  - validate_session() returns data  → session ALIVE (logged only, no spam)
  - validate_session() returns None  → session DEAD → alert owner immediately
  - Session dead for > 30 min       → escalation alert
"""
import asyncio
import base64
import json
import time
import logging
from datetime import datetime, timezone

from aiogram import Bot
from database import db
from config import settings

logger = logging.getLogger(__name__)

OWNER_ID = settings.OWNER_ID

# Track last "alive confirmed" timestamp per account to avoid repeated alerts
_last_alive: dict[str, float] = {}     # acc_id → timestamp
_dead_alerted: dict[str, float] = {}   # acc_id → timestamp of first dead alert


# ─────────────────────────────────────────────────────────────────
# JWT helpers (kept for accounts that DO have exp field)
# ─────────────────────────────────────────────────────────────────
def decode_jwt_expiry(token: str) -> int | None:
    try:
        parts = token.split(".")
        if len(parts) < 2:
            return None
        payload_b64 = parts[1]
        payload_b64 += "=" * ((4 - len(payload_b64) % 4) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64))
        return payload.get("exp")
    except Exception:
        return None


def get_cookie_age_hours(account: dict) -> float:
    """Returns hours since cookies were last saved/refreshed."""
    added_at = account.get("cookie_added_at")
    if added_at:
        return (time.time() - float(added_at)) / 3600
    last_refreshed = account.get("last_refreshed", "")
    if last_refreshed:
        try:
            dt = datetime.fromisoformat(last_refreshed)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return (datetime.now(timezone.utc) - dt).total_seconds() / 3600
        except Exception:
            pass
    return 6.0


def quick_token_check(cookies_json: str) -> dict:
    """Pre-payment local check. U7Buy has no JWT exp so just verify token exists."""
    if not cookies_json:
        return {"ok": False, "status": "no_session", "message": "No session configured. Contact owner."}
    try:
        from services.u47_api import U7BuyApiClient
        client = U7BuyApiClient(cookies_json)
    except Exception:
        return {"ok": False, "status": "parse_error", "message": "Session data corrupt. Contact owner."}
    if not client.access_token:
        return {"ok": False, "status": "no_token", "message": "No access token found. Contact owner."}
    return {"ok": True, "status": "valid", "message": ""}


# ─────────────────────────────────────────────────────────────────
# Serializer — saves updated cookies (if server set new ones) to DB
# ─────────────────────────────────────────────────────────────────
def serialize_cookies(client, original_str: str) -> str:
    if not original_str:
        return ""
    cleaned_str = original_str.replace("\u00a0", " ").replace("\xa0", " ").strip()
    try:
        parsed = json.loads(cleaned_str)
        if isinstance(parsed, dict) and ("user" in parsed or "cookies" in parsed):
            cookies_str = "; ".join([f"{k}={v}" for k, v in client.cookies_dict.items()])
            user_str = parsed.get("user", "")
            if user_str:
                try:
                    user_info = json.loads(user_str)
                    if "state" in user_info and "userInfo" in user_info["state"]:
                        user_info["state"]["userInfo"]["accessToken"] = client.access_token
                    user_str = json.dumps(user_info, ensure_ascii=False)
                except Exception:
                    pass
            return json.dumps({"user": user_str, "cookies": cookies_str}, ensure_ascii=False)
        elif isinstance(parsed, list):
            return json.dumps([
                {"name": name, "value": value,
                 "domain": "www.u7buy.com" if "stripe" not in name else ".stripe.com",
                 "path": "/"}
                for name, value in client.cookies_dict.items()
            ], ensure_ascii=False)
    except Exception as e:
        logger.error(f"serialize_cookies error: {e}")
    return original_str


# ─────────────────────────────────────────────────────────────────
# Cookie Health Monitor (every 6h — full report)
# ─────────────────────────────────────────────────────────────────
async def check_all_accounts(bot: Bot):
    """Full health check with Telegram alerts."""
    accounts = await db.list_all_accounts()
    logger.info(f"[CookieMonitor] Checking {len(accounts)} accounts...")

    for account in accounts:
        acc_id = account.get("id")
        email = account.get("email", "Unknown")
        proxy_id = account.get("proxy_id", "N/A")
        cookies_json = account.get("cookies_json", "")

        if not cookies_json:
            continue

        age_hours = get_cookie_age_hours(account)

        try:
            from services.u47_api import U7BuyApiClient
            proxy_url = ""
            if proxy_id and proxy_id != "N/A":
                p = await db.get_proxy(proxy_id)
                if p:
                    proxy_url = p.get("url", "")
            client = U7BuyApiClient(cookies_json, proxy_url=proxy_url)
            session_data = await client.validate_session()
            is_alive = bool(session_data)
        except Exception as e:
            logger.warning(f"[CookieMonitor] Cannot validate {acc_id}: {e}")
            is_alive = False

        logger.info(f"[CookieMonitor] {acc_id} ({email}): age={age_hours:.1f}h, alive={is_alive}")

        if not is_alive:
            try:
                await bot.send_message(
                    chat_id=OWNER_ID,
                    text=(
                        f"*Session DEAD — Refresh Required*\n\n"
                        f"ID: `{acc_id}`\n"
                        f"Email: `{email}`\n"
                        f"Proxy: `{proxy_id}`\n"
                        f"Cookie age: `{age_hours:.1f}h`\n\n"
                        f"Session is no longer valid. Please paste fresh cookies:\n"
                        f"`/admin` → Account Pool → Refresh Cookies"
                    ),
                    parse_mode="Markdown"
                )
            except Exception:
                pass

        await asyncio.sleep(0.3)


async def run_cookie_monitor(bot: Bot, check_interval_hours: float = 6.0):
    logger.info(f"[CookieMonitor] Started — interval: {check_interval_hours}h")
    while True:
        try:
            await check_all_accounts(bot)
        except Exception as e:
            logger.error(f"[CookieMonitor] Error: {e}")
        await asyncio.sleep(check_interval_hours * 3600)


# ─────────────────────────────────────────────────────────────────
# Session Keeper (every 4 minutes)
# Keeps session alive via validate_session() ping.
# Sends REAL alerts based on actual server response.
# ─────────────────────────────────────────────────────────────────
async def keep_alive_all_sessions(bot: Bot):
    logger.info("[SessionKeeper] Running keep-alive cycle...")

    # ── 1. Owner Accounts ──
    accounts = await db.list_all_accounts()
    for account in accounts:
        acc_id = account.get("id")
        email = account.get("email", "Unknown")
        proxy_id = account.get("proxy_id", "N/A")
        cookies_json = account.get("cookies_json", "")

        if not cookies_json:
            continue

        try:
            from services.u47_api import U7BuyApiClient
            proxy_url = ""
            if proxy_id and proxy_id != "N/A":
                p = await db.get_proxy(proxy_id)
                if p:
                    proxy_url = p.get("url", "")

            client = U7BuyApiClient(cookies_json, proxy_url=proxy_url)

            # The REAL keep-alive: call validate_session — this proves to U7Buy server
            # that the session is in use and resets its inactivity timer
            session_data = await client.validate_session()

            if session_data:
                # ✅ Session is ALIVE — update cookies if server returned new ones
                _last_alive[acc_id] = time.time()

                # If this account was previously dead-alerted, send recovery notice
                if acc_id in _dead_alerted:
                    del _dead_alerted[acc_id]
                    try:
                        await bot.send_message(
                            chat_id=OWNER_ID,
                            text=(
                                f"*Session RECOVERED*\n\n"
                                f"ID: `{acc_id}`\n"
                                f"Email: `{email}`\n\n"
                                f"Session is alive again after being unreachable."
                            ),
                            parse_mode="Markdown"
                        )
                    except Exception:
                        pass

                # Save updated cookies if they changed (server may rotate cookie values)
                new_cookies = serialize_cookies(client, cookies_json)
                if new_cookies and new_cookies != cookies_json:
                    await db.refresh_account_cookies(
                        account_id=acc_id,
                        cookies_json=new_cookies,
                        access_token_exp=0,
                        email=email
                    )
                    logger.info(f"[SessionKeeper] Cookies auto-updated for {acc_id} ({email})")

                logger.info(f"[SessionKeeper] ALIVE: {acc_id} ({email})")

            else:
                # ❌ Session is DEAD — validate_session returned None
                logger.warning(f"[SessionKeeper] DEAD: {acc_id} ({email})")

                now = time.time()
                already_alerted_at = _dead_alerted.get(acc_id, 0)
                # Alert once, then again every 30 min if still dead
                if now - already_alerted_at > 1800:
                    _dead_alerted[acc_id] = now
                    age_hours = get_cookie_age_hours(account)
                    try:
                        await bot.send_message(
                            chat_id=OWNER_ID,
                            text=(
                                f"*Session DEAD — Action Required!*\n\n"
                                f"ID: `{acc_id}`\n"
                                f"Email: `{email}`\n"
                                f"Proxy: `{proxy_id}`\n"
                                f"Cookie age: `{age_hours:.1f}h`\n\n"
                                f"The session is no longer valid (server rejected).\n"
                                f"Please paste fresh cookies:\n\n"
                                f"`/admin` → Account Pool → Refresh Cookies"
                            ),
                            parse_mode="Markdown"
                        )
                    except Exception as alert_err:
                        logger.error(f"[SessionKeeper] Alert failed: {alert_err}")

        except Exception as e:
            logger.error(f"[SessionKeeper] Error on account {acc_id}: {e}")

        await asyncio.sleep(0.5)

    # ── 2. User Custom Cookies ──
    users = await db.list_users()
    for user in users:
        if not user.get("active"):
            continue

        tg_id = user.get("tg_id")
        custom_cookies = user.get("custom_cookies", {})
        custom_emails = user.get("custom_emails", {})
        proxy_id = user.get("proxy_id", "")

        for slot in ["slot1", "slot2"]:
            slot_num = 1 if slot == "slot1" else 2
            cookies_json = custom_cookies.get(slot)
            if not cookies_json:
                continue

            email = custom_emails.get(slot, "Custom Account")
            key = f"user_{tg_id}_{slot}"

            try:
                from services.u47_api import U7BuyApiClient
                proxy_url = ""
                if proxy_id:
                    p = await db.get_proxy(proxy_id)
                    if p:
                        proxy_url = p.get("url", "")
                client = U7BuyApiClient(cookies_json, proxy_url=proxy_url)

                session_data = await client.validate_session()

                if session_data:
                    _last_alive[key] = time.time()
                    if key in _dead_alerted:
                        del _dead_alerted[key]

                    new_cookies = serialize_cookies(client, cookies_json)
                    if new_cookies and new_cookies != cookies_json:
                        await db.update_user_custom_cookies(
                            tg_id=tg_id, slot=slot_num,
                            cookies_json=new_cookies, email=email
                        )
                    logger.info(f"[SessionKeeper] ALIVE: user {tg_id} {slot}")
                else:
                    logger.warning(f"[SessionKeeper] DEAD: user {tg_id} {slot}")
                    now = time.time()
                    if now - _dead_alerted.get(key, 0) > 1800:
                        _dead_alerted[key] = now
                        try:
                            await bot.send_message(
                                chat_id=OWNER_ID,
                                text=(
                                    f"*User Session DEAD*\n\n"
                                    f"TG ID: `{tg_id}` | Slot: `{slot}`\n"
                                    f"Email: `{email}`\n\n"
                                    f"Session is dead. User needs to update their cookies."
                                ),
                                parse_mode="Markdown"
                            )
                        except Exception:
                            pass

            except Exception as e:
                logger.error(f"[SessionKeeper] Error on user {tg_id} {slot}: {e}")

            await asyncio.sleep(0.5)


async def run_session_keeper(bot: Bot, interval_minutes: float = 4.0):
    """
    Runs every 4 minutes.
    Calls validate_session() on all accounts — this IS the keep-alive.
    U7Buy server extends session TTL on every successful call.
    Alerts owner ONLY when session actually dies (validate returns None).
    """
    logger.info(f"[SessionKeeper] Started — interval: {interval_minutes}m")
    logger.info("[SessionKeeper] Strategy: validate_session() every 4min to keep server session alive")
    logger.info("[SessionKeeper] Alert: only when session actually dies (server rejects)")
    while True:
        try:
            await keep_alive_all_sessions(bot)
        except Exception as e:
            logger.error(f"[SessionKeeper] Critical error: {e}")
        await asyncio.sleep(interval_minutes * 60)
