"""
Cookie Health Monitor
Checks all accounts every 6 hours. Sends expiry alerts to OWNER.
Alert includes: proxy, email, account ID, time remaining.
"""
import asyncio
import base64
import json
import time
import logging
from datetime import datetime, timezone

from aiogram import Bot
from database import db
from config import settings

logger = logging.getLogger(__name__)

OWNER_ID = settings.OWNER_ID


def decode_jwt_expiry(token: str) -> int | None:
    try:
        parts = token.split(".")
        if len(parts) < 2:
            return None
        payload_b64 = parts[1]
        payload_b64 += "=" * ((4 - len(payload_b64) % 4) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64))
        return payload.get("exp")
    except Exception:
        return None


def get_token_status(access_token: str) -> dict:
    if not access_token:
        return {"status": "no_token", "expires_in_hours": None, "expires_at_str": None}
    exp_ts = decode_jwt_expiry(access_token)
    if not exp_ts:
        return {"status": "valid", "expires_in_hours": None, "expires_at_str": None}
    now_ts = int(time.time())
    diff_secs = exp_ts - now_ts
    hours_left = diff_secs / 3600
    expires_str = datetime.fromtimestamp(exp_ts, tz=timezone.utc).strftime("%d %b %Y %H:%M UTC")
    if diff_secs <= 0:
        return {"status": "expired", "expires_in_hours": 0, "expires_at_str": expires_str}
    elif hours_left <= 48:
        return {"status": "expiring_soon", "expires_in_hours": round(hours_left, 1), "expires_at_str": expires_str}
    else:
        return {"status": "valid", "expires_in_hours": round(hours_left, 1), "expires_at_str": expires_str}


def quick_token_check(cookies_json: str) -> dict:
    """
    Local JWT check — no API call. Used before payments.
    Returns: {ok: bool, status: str, message: str}
    """
    if not cookies_json:
        return {"ok": False, "status": "no_session",
                "message": "❌ No session configured. Contact owner."}
    try:
        from services.u47_api import U7BuyApiClient
        client = U7BuyApiClient(cookies_json)
    except Exception:
        return {"ok": False, "status": "parse_error",
                "message": "❌ Session data corrupt. Contact owner."}

    ts = get_token_status(client.access_token)
    status = ts["status"]
    hours_left = ts["expires_in_hours"]

    if status == "expired":
        return {"ok": False, "status": "expired",
                "message": "❌ *Session Expired!*\n\nContact owner to refresh cookies."}
    elif status == "expiring_soon":
        return {"ok": True, "status": "expiring_soon",
                "message": f"⚠️ *Warning:* Session expires in *{hours_left}h*. Owner will be notified."}
    else:
        return {"ok": True, "status": "valid", "message": ""}


async def check_all_accounts(bot: Bot):
    """Check all owner-managed accounts and alert owner on expiry."""
    accounts = await db.list_all_accounts()
    logger.info(f"[CookieMonitor] Checking {len(accounts)} accounts...")

    for account in accounts:
        acc_id = account.get("id")
        email = account.get("email", "Unknown")
        proxy_id = account.get("proxy_id", "N/A")
        cookies_json = account.get("cookies_json", "")

        if not cookies_json:
            continue

        try:
            from services.u47_api import U7BuyApiClient
            client = U7BuyApiClient(cookies_json)
            ts = get_token_status(client.access_token)
        except Exception as e:
            logger.warning(f"[CookieMonitor] Cannot parse account {acc_id}: {e}")
            continue

        status = ts["status"]
        hours_left = ts["expires_in_hours"]
        expires_str = ts["expires_at_str"]

        logger.info(f"[CookieMonitor] Account {acc_id} ({email}): {status}, {hours_left}h left")

        if status == "expired":
            msg = (
                f"🔴 *Cookie EXPIRED — Action Required!*\n\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"🆔 Account: `{acc_id}`\n"
                f"📧 Email: `{email}`\n"
                f"🖥️ Proxy: `{proxy_id}`\n"
                f"📅 Expired: `{expires_str}`\n"
                f"━━━━━━━━━━━━━━━━━━\n\n"
                f"👉 Refresh via:\n"
                f"`/admin` → Account Pool → 🔄 Refresh Cookies → `{acc_id}`"
            )
            try:
                await bot.send_message(chat_id=OWNER_ID, text=msg, parse_mode="Markdown")
            except Exception as e:
                logger.error(f"Failed to send expired alert: {e}")

        elif status == "expiring_soon":
            msg = (
                f"🟡 *Cookie Expiry Warning!*\n\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"🆔 Account: `{acc_id}`\n"
                f"📧 Email: `{email}`\n"
                f"🖥️ Proxy: `{proxy_id}`\n"
                f"⏳ Expires in: *{hours_left}h*\n"
                f"📅 Expiry: `{expires_str}`\n"
                f"━━━━━━━━━━━━━━━━━━\n\n"
                f"Refresh before it expires:\n"
                f"`/admin` → Account Pool → 🔄 Refresh → `{acc_id}`"
            )
            try:
                await bot.send_message(chat_id=OWNER_ID, text=msg, parse_mode="Markdown")
            except Exception as e:
                logger.error(f"Failed to send expiry warning: {e}")

        await asyncio.sleep(0.3)


async def run_cookie_monitor(bot: Bot, check_interval_hours: float = 6.0):
    """Background loop: check cookies every N hours."""
    logger.info(f"[CookieMonitor] Started — interval: {check_interval_hours}h")
    interval_secs = check_interval_hours * 3600

    while True:
        try:
            await check_all_accounts(bot)
            logger.info(f"[CookieMonitor] Done. Next check in {check_interval_hours}h")
        except Exception as e:
            logger.error(f"[CookieMonitor] Error: {e}")
        await asyncio.sleep(interval_secs)
