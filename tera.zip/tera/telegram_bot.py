"""
telegram_bot.py - Main Telegram Bot Controller for Terabox Refer Bot
Commands: /start /run /setdaily /status /accounts /addlink /links /proxies /stop
Run: python -X utf8 telegram_bot.py
"""

import asyncio
import json
import os
import sys
import random
import re
import time
from datetime import datetime
from pathlib import Path

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, filters
)

# Load config
def load_env(path="config.env"):
    env = {}
    try:
        for line in open(path, encoding="utf-8"):
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()
    except: pass
    return env

CFG = load_env()

TELEGRAM_TOKEN   = CFG.get("TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = CFG.get("TELEGRAM_CHAT_ID", "")
HEADLESS         = CFG.get("HEADLESS", "true").lower() == "true"

if not TELEGRAM_TOKEN:
    print("❌ TELEGRAM_TOKEN missing in config.env!")
    sys.exit(1)

# Global state
_running = False
_stop_flag = False
_current_task = None


# ── Helpers ──

async def send_msg(app, text: str, parse_mode="HTML"):
    """Send message to user"""
    try:
        await app.bot.send_message(
            chat_id=TELEGRAM_CHAT_ID,
            text=text,
            parse_mode=parse_mode
        )
    except Exception as e:
        print(f"[TG] Send error: {e}")


async def send_photo(app, photo_path: str, caption: str = ""):
    """Send screenshot to user"""
    try:
        if os.path.exists(photo_path):
            with open(photo_path, "rb") as f:
                await app.bot.send_photo(
                    chat_id=TELEGRAM_CHAT_ID,
                    photo=f,
                    caption=caption,
                    parse_mode="HTML"
                )
    except Exception as e:
        print(f"[TG] Photo error: {e}")


def is_authorized(update: Update) -> bool:
    """Only allow configured chat ID"""
    if not TELEGRAM_CHAT_ID:
        return True
    return str(update.effective_chat.id) == str(TELEGRAM_CHAT_ID)


# ── Account Creation Runner ──

async def create_accounts(n: int, app, update: Update = None):
    global _running, _stop_flag

    _running = True
    _stop_flag = False

    from database import init_db, save_account, get_proxy_stats
    from bot.tempmail import create_email, get_inbox
    from bot.terabox import register_terabox
    from bot.proxy_manager import get_n_working_proxies, proxy_to_playwright

    init_db()

    async def notify(msg):
        await send_msg(app, msg)

    await notify(f"🚀 <b>Starting {n} account creation...</b>\n⏳ Fetching & testing proxies first...")

    # Force fresh proxy pool refresh for this run
    from bot.proxy_manager import refresh_proxy_pool
    await refresh_proxy_pool(notify_cb=notify)

    # Get proxies
    proxies = await get_n_working_proxies(n, notify_cb=notify)
    if not proxies:
        await notify("⚠️ Running accounts creation with direct connection.")
        proxies = [None] * n

    # Pad with None if not enough proxies
    while len(proxies) < n:
        proxies.append(None)

    stats = {"success": 0, "failed": 0, "plan_joined": 0}

    for i in range(1, n + 1):
        if _stop_flag:
            await notify(f"⛔ Stopped at account {i}/{n}")
            break

        proxy_data = proxies[i - 1]
        proxy_playwright = proxy_to_playwright(proxy_data) if proxy_data else None
        proxy_host = proxy_data.get("host", "none") if proxy_data else "none"

        await notify(f"⏳ <b>Account {i}/{n}</b>\n🌐 Proxy: {proxy_host}")

        # Create email (multi-provider auto-rotate)
        try:
            mail_data = create_email()
            email = mail_data["address"]
            token = mail_data["token"]
            provider = mail_data.get("provider", "mail.tm")
            print(f"  [MAIL] Using provider: {provider} | {email}")
        except Exception as e:
            await notify(f"❌ Account {i}: Email failed: {e}")
            stats["failed"] += 1
            continue

        # OTP callback - uses correct provider
        async def get_otp(tok=token, prov=provider):
            start = time.time()
            from bot.tempmail import get_inbox
            import re as _re
            seen = set()
            while time.time() - start < 120:
                emails = get_inbox(tok, prov)
                for em in emails:
                    eid = em.get("@id", "")
                    if eid in seen:
                        continue
                    seen.add(eid)
                    subj = em.get("subject", "")
                    text = em.get("text", "") + em.get("intro", "") + em.get("html", "")
                    m = _re.search(r'\b(\d{4,6})\b', subj + " " + text)
                    if m:
                        return m.group(1)
                await asyncio.sleep(4)
            return None

        # Register with proxy retry logic (max 3 attempts, attempt 3 = direct fallback)
        result = {"success": False, "error": "Init"}
        attempts = 0
        current_proxy_data = proxy_data
        current_proxy_pw = proxy_playwright
        current_proxy_host = proxy_host

        while attempts < 3 and not result.get("success") and not _stop_flag:
            attempts += 1
            try:
                result = await register_terabox(
                    email=email,
                    otp_callback=get_otp,
                    headless=HEADLESS,
                    screenshot_prefix=f"debug_tg_{i}_",
                    proxy=current_proxy_pw
                )
            except Exception as e:
                result = {"success": False, "error": str(e), "email": email, "password": ""}

            err_msg = str(result.get("error", ""))
            if not result.get("success") and attempts < 3:
                if attempts == 2:
                    # Attempt 3: Direct connection fallback (100% guarantee)
                    current_proxy_data = None
                    current_proxy_pw = None
                    current_proxy_host = "direct (fallback)"
                    await notify(f"⚠️ Proxy failed twice. Account {i}/{n} Retry {attempts}: Using direct connection...")
                else:
                    next_proxies = await get_n_working_proxies(1)
                    if next_proxies:
                        current_proxy_data = next_proxies[0]
                        current_proxy_pw = proxy_to_playwright(current_proxy_data)
                        current_proxy_host = current_proxy_data.get("host", "none")
                    else:
                        current_proxy_data = None
                        current_proxy_pw = None
                        current_proxy_host = "direct (fallback)"
                    await notify(f"🔄 Account {i}/{n} Retry {attempts}: Using proxy {current_proxy_host}")

        proxy_host = current_proxy_host
        proxy_data = current_proxy_data




        # Save to DB & log
        log_entry = {
            **result,
            "account_num": i,
            "proxy_used": proxy_host,
            "timestamp": datetime.now().isoformat()
        }
        Path("logs").mkdir(exist_ok=True)
        with open("logs/accounts.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")

        if result.get("success"):
            stats["success"] += 1
            if result.get("plan_joined"):
                stats["plan_joined"] += 1
            save_account(
                email=result["email"],
                password=result["password"],
                proxy_host=proxy_host,
                plan_joined=result.get("plan_joined", False)
            )

            # Assign proxy to account in DB
            if proxy_data:
                from database import get_conn
                conn = get_conn()
                acc = conn.execute("SELECT id FROM accounts WHERE email=?", (email,)).fetchone()
                if acc:
                    conn.execute("UPDATE proxies SET used_by_account=? WHERE id=?",
                                (acc[0], proxy_data["id"]))
                    conn.commit()
                conn.close()

            # Get proxy country flag & info
            from bot.proxy_manager import get_proxy_country_info
            country_info = await get_proxy_country_info(proxy_host)

            msg = (
                f"✅ <b>Account {i}/{n} Created!</b>\n"
                f"📧 Email: <code>{result['email']}</code>\n"
                f"🔑 Pass: <code>{result['password']}</code>\n"
                f"💰 Plan: {'Joined ✓' if result.get('plan_joined') else '⚠️ Not joined'}\n"
                f"🌐 Proxy: <code>{proxy_host}</code> ({country_info})"
            )
            await notify(msg)


            # Send screenshot
            ss = f"debug_tg_{i}_step11_plan_joined.png"
            if os.path.exists(ss):
                await send_photo(app, ss, f"Account {i} - Plan joined")

        else:
            stats["failed"] += 1
            await notify(
                f"❌ <b>Account {i}/{n} Failed</b>\n"
                f"📧 {email}\n"
                f"⚠️ Reason: {result.get('error','?')[:100]}"
            )

        # Small delay between accounts
        if i < n and not _stop_flag:
            delay = random.randint(15, 25)
            await asyncio.sleep(delay)

    _running = False

    final = (
        f"🏁 <b>Run Complete!</b>\n\n"
        f"✅ Success: <b>{stats['success']}</b>\n"
        f"❌ Failed: <b>{stats['failed']}</b>\n"
        f"💰 Plan joined: <b>{stats['plan_joined']}</b>\n\n"
        f"📁 Logs: logs/accounts.jsonl"
    )
    await notify(final)
    return stats


# ── Auto Link Detection ──

async def handle_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Auto-detect Terabox share links pasted/forwarded in chat and save them."""
    if not is_authorized(update):
        return
    text = update.message.text or update.message.caption or ""
    if not text:
        return

    # Extract all Terabox share links from message
    found = re.findall(
        r'https?://(?:www\.)?(?:1024terabox|terabox|1024tera)\.com/s/[\w\-]+',
        text
    )
    if not found:
        return

    from database import add_link, get_share_links
    added = []
    skipped = []
    for url in found:
        url = url.strip().rstrip(')')
        if add_link(url):
            added.append(url)
        else:
            skipped.append(url)

    total_links = len(get_share_links())
    if added:
        msg = (
            f"🔗 <b>Auto-detected {len(added)} link(s) saved!</b>\n\n"
            + "\n".join(f"✅ <code>{u}</code>" for u in added)
        )
        if skipped:
            msg += f"\n\n⚠️ {len(skipped)} already in DB"
        msg += f"\n\n📋 Total links: <b>{total_links}</b>"
        await update.message.reply_text(msg, parse_mode="HTML")


# ── Commands ──

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_authorized(update):
        return
    from database import init_db, get_account_stats, get_proxy_stats
    init_db()
    acc = get_account_stats()
    prx = get_proxy_stats()

    text = (
        "🤖 <b>Terabox Refer Bot Commands</b>\n\n"
        "▶️ /run [n] — Create N accounts\n"
        "⚙️ /setdaily [n] — Set daily account count\n"
        "🎬 /views [n] — Generate N views on share links\n"
        "📈 /status — Current bot status\n"
        "👥 /accounts — Show recent accounts\n\n"
        "🔗 <b>Link Management:</b>\n"
        "🔗 /addlink [url] — Add share link\n"
        "🔗 /links — Show all links\n"
        "🗑 /clearlinks — Delete ALL share links\n"
        "❌ /removelink [url] — Remove specific link\n\n"
        "🔄 /setwebmaster [url] — Update webmaster referral link\n"
        "🌐 /proxies — Proxy pool status\n"
        "🔄 /activity — Trigger activity cycle\n"
        "⛔ /stop — Stop current run\n"
    )
    await update.message.reply_text(text, parse_mode="HTML")


async def cmd_run(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    global _running, _current_task
    if not is_authorized(update):
        return
    if _running:
        await update.message.reply_text("⚠️ Already running! Use /stop first.")
        return

    from database import get_setting
    try:
        n = int(ctx.args[0]) if ctx.args else int(get_setting("daily_accounts", "10"))
        n = max(1, min(n, 50))  # limit 1-50
    except:
        n = 10

    await update.message.reply_text(f"🚀 Starting <b>{n}</b> accounts...", parse_mode="HTML")

    # Run in background
    _current_task = asyncio.create_task(
        create_accounts(n, ctx.application, update)
    )


async def cmd_setdaily(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_authorized(update):
        return
    from database import set_setting
    try:
        n = int(ctx.args[0])
        n = max(1, min(n, 50))
        set_setting("daily_accounts", str(n))
        await update.message.reply_text(f"✅ Daily accounts set to <b>{n}</b>", parse_mode="HTML")
    except:
        await update.message.reply_text("Usage: /setdaily 10")


async def cmd_status(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_authorized(update):
        return
    from database import get_account_stats, get_proxy_stats, get_setting
    acc = get_account_stats()
    prx = get_proxy_stats()
    daily = get_setting("daily_accounts", "10")

    text = (
        f"📊 <b>Bot Status</b>\n\n"
        f"🤖 Running: {'🟢 YES' if _running else '🔴 NO'}\n"
        f"📅 Daily target: {daily} accounts\n\n"
        f"👥 <b>Accounts:</b>\n"
        f"  Total: {acc['total']}\n"
        f"  Active (48h): {acc['active']}\n"
        f"  Plan joined: {acc['plan_joined']}\n"
        f"  Expired: {acc['expired']}\n\n"
        f"🌐 <b>Proxies:</b>\n"
        f"  Working: {prx['working']}\n"
        f"  Available: {prx['free']}\n"
        f"  In use: {prx['working'] - prx['free']}\n"
    )
    await update.message.reply_text(text, parse_mode="HTML")


async def cmd_accounts(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_authorized(update):
        return
    from database import get_all_accounts
    from bot.proxy_manager import get_proxy_country_info

    accounts = get_all_accounts(10)
    if not accounts:
        await update.message.reply_text("No accounts yet.")
        return

    lines = ["👥 <b>Recent Accounts (last 10):</b>\n"]
    for a in accounts:
        status = "✅" if a["status"] == "active" else "❌"
        plan = "💰" if a["plan_joined"] else "⚠️"
        ts = a["created_at"][:16].replace("T", " ")
        phost = a.get("proxy_host", "none")
        c_info = await get_proxy_country_info(phost)
        lines.append(
            f"{status}{plan} <code>{a['email']}</code>\n"
            f"   🔑 {a['password']} | 🌐 {phost} ({c_info}) | {ts}"
        )
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")



async def cmd_addlink(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_authorized(update):
        return
    from database import add_link, get_share_links
    urls = ctx.args
    if not urls:
        # Show current links
        links = get_share_links()
        if not links:
            await update.message.reply_text(
                "🔗 <b>No share links added yet!</b>\n\n"
                "📝 Add your links:\n"
                "<code>/addlink https://1024terabox.com/s/xxxx</code>\n\n"
                "Multiple links add karne ke liye:\n"
                "<code>/addlink link1 link2 link3</code>",
                parse_mode="HTML"
            )
            return
        lines = [f"🔗 <b>Your Share Links ({len(links)}):</b>\n"]
        for i, l in enumerate(links, 1):
            lines.append(f"{i}. 👁 {l['visit_count']} | <code>{l['url']}</code>")
        lines.append("\n🗑 /clearlinks — Sab delete karo")
        lines.append("❌ /removelink [url] — Ek delete karo")
        await update.message.reply_text("\n".join(lines), parse_mode="HTML")
        return
    added = 0
    skipped = 0
    for url in urls:
        url = url.strip()
        if "terabox" in url.lower() or "1024tera" in url.lower():
            if add_link(url):
                added += 1
            else:
                skipped += 1
        else:
            skipped += 1
    links = get_share_links()
    await update.message.reply_text(
        f"✅ <b>{added} link(s) added!</b>\n"
        f"⚠️ {skipped} skipped (duplicate or invalid)\n\n"
        f"📋 Total links now: <b>{len(links)}</b>\n"
        f"📝 /links — See all | /views — Generate views",
        parse_mode="HTML"
    )


async def cmd_links(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_authorized(update):
        return
    from database import get_share_links, get_webmaster_link
    links = get_share_links()
    webmaster = get_webmaster_link()
    if not links:
        await update.message.reply_text(
            "🔗 <b>No share links added yet!</b>\n\n"
            "📝 Add karo: <code>/addlink https://1024terabox.com/s/xxxx</code>\n\n"
            f"🌐 <b>Webmaster:</b>\n<code>{webmaster[:60]}</code>",
            parse_mode="HTML"
        )
        return
    lines = [f"🔗 <b>Share Links ({len(links)}):</b>\n"]
    for i, l in enumerate(links, 1):
        lines.append(f"{i}. 👁 {l['visit_count']} views | <code>{l['url']}</code>")
    lines.append(f"\n🌐 <b>Webmaster:</b>\n<code>{webmaster[:60]}</code>")
    lines.append("\n🗑 /clearlinks — Sab delete karo")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


async def cmd_clearlinks(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_authorized(update):
        return
    from database import clear_all_share_links
    count = clear_all_share_links()
    await update.message.reply_text(
        f"🗑 <b>{count} share link(s) deleted!</b>\n\n"
        f"Ab apni nayi links add karo:\n"
        f"<code>/addlink https://1024terabox.com/s/xxxx</code>\n\n"
        f"Multiple: <code>/addlink link1 link2 link3</code>",
        parse_mode="HTML"
    )


async def cmd_removelink(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_authorized(update):
        return
    from database import delete_link, get_share_links
    if not ctx.args:
        await update.message.reply_text(
            "Usage: <code>/removelink https://1024terabox.com/s/xxxx</code>",
            parse_mode="HTML"
        )
        return
    url = ctx.args[0].strip()
    from database import delete_link
    if delete_link(url):
        links = get_share_links()
        await update.message.reply_text(
            f"✅ Link deleted!\n📋 Remaining: {len(links)} links",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text("❌ Link not found in DB.")


async def cmd_setwebmaster(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_authorized(update):
        return
    from database import update_webmaster_link, get_webmaster_link
    if not ctx.args:
        current = get_webmaster_link()
        await update.message.reply_text(
            f"🌐 <b>Current webmaster link:</b>\n<code>{current}</code>\n\n"
            f"📝 Usage: /setwebmaster https://www.1024terabox.com/referral/XXXXXXXX",
            parse_mode="HTML"
        )
        return
    new_link = ctx.args[0].strip()
    if "referral" not in new_link and "referer_uk" not in new_link:
        await update.message.reply_text(
            "❌ Invalid link. Should contain 'referral' or 'referer_uk'\n"
            "Example: https://www.1024terabox.com/referral/81364624626373"
        )
        return
    if update_webmaster_link(new_link):
        await update.message.reply_text(
            f"✅ <b>Webmaster link updated!</b>\n"
            f"New: <code>{new_link}</code>\n\n"
            f"Old link deleted. Next /run will use new link.",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text("❌ Failed to update. Check link format.")


async def cmd_views(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_authorized(update):
        return
    from database import get_share_links
    from bot.viewer import fetch_github_proxies_for_views, run_views_batch, DEFAULT_SHARE_LINKS

    try:
        n = int(ctx.args[0]) if ctx.args else 100
        n = max(10, min(n, 500))
    except:
        n = 100

    links_db = get_share_links()
    links = [l["url"] for l in links_db] if links_db else DEFAULT_SHARE_LINKS

    await update.message.reply_text(
        f"🎬 <b>Starting {n} views...</b>\n"
        f"📋 Links: {len(links)}\n"
        f"⏳ Fetching fresh proxies from GitHub...",
        parse_mode="HTML"
    )

    async def notify(msg):
        await update.message.reply_text(msg, parse_mode="HTML")

    proxies = await fetch_github_proxies_for_views(n)
    if not proxies:
        await update.message.reply_text("❌ No working proxies found from GitHub.")
        return

    stats = await run_views_batch(
        proxies=proxies,
        links=links,
        use_browser=False,
        use_api=True,
        concurrency=20,
        notify_cb=notify
    )

    await update.message.reply_text(
        f"🎬 <b>Views Done!</b>\n"
        f"✅ Success: {stats['success']}\n"
        f"❌ Failed: {stats['failed']}\n"
        f"📊 Total: {stats['total']}",
        parse_mode="HTML"
    )


async def cmd_proxies(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_authorized(update):
        return
    from database import get_proxy_stats
    stats = get_proxy_stats()
    await update.message.reply_text(
        f"🌐 <b>Proxy Pool</b>\n\n"
        f"Total in DB: {stats['total']}\n"
        f"Working: {stats['working']}\n"
        f"Available: {stats['free']}\n"
        f"In use: {stats['working'] - stats['free']}\n\n"
        f"Use /run to auto-refresh from GitHub",
        parse_mode="HTML"
    )


async def cmd_activity(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_authorized(update):
        return
    await update.message.reply_text("🔄 Triggering activity cycle...")
    from bot.activity import run_activity_cycle

    async def notify(msg):
        await update.message.reply_text(msg, parse_mode="HTML")

    result = await run_activity_cycle(notify_cb=notify)

    # Send one screenshot
    import glob
    shots = sorted(glob.glob("screenshots/activity_*.png"), reverse=True)
    if shots:
        await send_photo(
            ctx.application, shots[0],
            f"🔄 Activity screenshot - {datetime.now().strftime('%H:%M')}"
        )


async def cmd_stop(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    global _stop_flag, _running
    if not is_authorized(update):
        return
    if not _running:
        await update.message.reply_text("Bot is not running.")
        return
    _stop_flag = True
    await update.message.reply_text("⛔ Stopping after current account completes...")


# ── Scheduler Jobs ──

async def daily_job(app):
    """Daily account creation job (runs at configured time)"""
    from database import get_setting, init_db
    init_db()
    n = int(get_setting("daily_accounts", "10"))
    print(f"[SCHEDULER] Daily job: creating {n} accounts")
    await send_msg(app, f"📅 <b>Daily run starting: {n} accounts</b>")
    await create_accounts(n, app)


async def activity_job(app):
    """Periodic activity simulation (every 5h)"""
    from bot.activity import run_activity_cycle

    async def notify(msg):
        await send_msg(app, msg)

    result = await run_activity_cycle(notify_cb=notify)

    # Send one screenshot if available
    if result.get("best_screenshot"):
        await send_photo(
            app, result["best_screenshot"],
            f"🔄 Activity - {datetime.now().strftime('%d/%m %H:%M')}"
        )


# ── Main ──

async def _post_init(app):
    """Start scheduler inside running event loop (called by PTB after startup)"""
    from apscheduler.schedulers.asyncio import AsyncIOScheduler

    scheduler = AsyncIOScheduler()

    # Activity every 5 hours
    scheduler.add_job(
        lambda: asyncio.create_task(activity_job(app)),
        "interval", hours=5, id="activity_cycle"
    )

    # Daily account creation at midnight IST (18:30 UTC)
    scheduler.add_job(
        lambda: asyncio.create_task(daily_job(app)),
        "cron", hour=18, minute=30, id="daily_accounts"
    )

    # Daily views at 10:00 IST (04:30 UTC)
    async def daily_views_job():
        from database import get_share_links
        from bot.viewer import fetch_github_proxies_for_views, run_views_batch, DEFAULT_SHARE_LINKS
        links_db = get_share_links()
        links = [l["url"] for l in links_db] if links_db else DEFAULT_SHARE_LINKS
        await send_msg(app, f"🎬 <b>Daily views: 200 views on {len(links)} links</b>")
        proxies = await fetch_github_proxies_for_views(200)
        if proxies:
            stats = await run_views_batch(proxies, links, use_browser=False, use_api=True, concurrency=20)
            await send_msg(app, f"🎬 Daily views done! ✅{stats['success']} ❌{stats['failed']}")
        else:
            await send_msg(app, "❌ Daily views: No working proxies found")

    scheduler.add_job(
        lambda: asyncio.create_task(daily_views_job()),
        "cron", hour=4, minute=30, id="daily_views"
    )

    scheduler.start()
    print("[BOT] Scheduler started ✅ (activity/5h | accounts/midnight | views/10AM IST)")
    await send_msg(app, "🤖 <b>Terabox Bot started!</b>\nScheduler: ✅\nSend /start for menu.")


def main():
    from database import init_db
    init_db()

    print(f"[BOT] Starting Telegram bot...")
    print(f"[BOT] Token: {TELEGRAM_TOKEN[:10]}...")
    print(f"[BOT] Chat ID: {TELEGRAM_CHAT_ID}")

    app = (
        Application.builder()
        .token(TELEGRAM_TOKEN)
        .post_init(_post_init)
        .build()
    )

    # Register handlers
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("run", cmd_run))
    app.add_handler(CommandHandler("setdaily", cmd_setdaily))
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("accounts", cmd_accounts))
    app.add_handler(CommandHandler("addlink", cmd_addlink))
    app.add_handler(CommandHandler("links", cmd_links))
    app.add_handler(CommandHandler("clearlinks", cmd_clearlinks))
    app.add_handler(CommandHandler("removelink", cmd_removelink))
    app.add_handler(CommandHandler("proxies", cmd_proxies))
    app.add_handler(CommandHandler("activity", cmd_activity))
    app.add_handler(CommandHandler("stop", cmd_stop))
    app.add_handler(CommandHandler("views", cmd_views))
    app.add_handler(CommandHandler("setwebmaster", cmd_setwebmaster))

    # Auto-detect Terabox links in any message
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        handle_message
    ))

    print("[BOT] ✅ Bot is running! Send /start in Telegram")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
