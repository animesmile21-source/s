"""
bot/proxy_manager.py - Proxy Fetcher, Tester & Manager
Loads local working proxy files + fetches from GitHub proxifly list.
Tests proxies concurrently and stores working proxies in DB.
"""

import asyncio
import aiohttp
import os
import re
import time
from pathlib import Path
from database import bulk_save_proxies, save_working_proxy, clear_proxies, get_proxy_stats

GITHUB_PROXY_URLS = [
    "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/all/data.txt",
    "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
    "https://raw.githubusercontent.com/stormsia/proxy-list/main/working_proxies.txt",
]

TEST_URLS = [
    "https://www.1024terabox.com/",
    "https://www.google.com/",
]
TEST_TIMEOUT = 8

CONCURRENCY = 100  # concurrent test connections


async def get_proxy_country_info(ip: str) -> str:
    """Fetch country flag emoji + country name for an IP address"""
    if not ip or ip in ("none", "direct (fallback)"):
        return "🌐 Direct"
    try:
        # Extract IP if IP:PORT or host string
        clean_ip = ip.split(":")[0].strip()
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"http://ip-api.com/json/{clean_ip}?fields=status,country,countryCode",
                timeout=aiohttp.ClientTimeout(total=4)
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    if data.get("status") == "success":
                        cc = data.get("countryCode", "")
                        country = data.get("country", "")
                        flag = "".join(chr(127397 + ord(c.upper())) for c in cc) if len(cc) == 2 else "🌐"
                        return f"{flag} {country}"
    except:
        pass
    return "🌐 Unknown"



def parse_proxy_line(line: str) -> dict | None:
    """Parse proxy string into dict"""
    line = line.split("#")[0].strip()
    if not line:
        return None
    try:
        if "://" in line:
            proto, rest = line.split("://", 1)
            if "@" in rest:
                creds, host_port = rest.rsplit("@", 1)
                user, pw = creds.split(":", 1)
                host, port = host_port.split(":", 1)
                return {
                    "protocol": proto, "host": host.strip(), "port": port.strip(),
                    "username": user.strip(), "password": pw.strip()
                }
            else:
                host, port = rest.split(":", 1)
                return {
                    "protocol": proto, "host": host.strip(), "port": port.strip(),
                    "username": "", "password": ""
                }
        parts = line.split(":")
        if len(parts) == 4:
            # host:port:user:pass
            host, port, user, pw = parts
            return {
                "protocol": "http", "host": host.strip(), "port": port.strip(),
                "username": user.strip(), "password": pw.strip()
            }
        elif len(parts) == 2:
            host, port = parts
            return {
                "protocol": "http", "host": host.strip(), "port": port.strip(),
                "username": "", "password": ""
            }
    except Exception:
        pass
    return None


def load_local_proxies() -> list[dict]:
    """Load proxies from local files in current folder"""
    local_files = [
        "good_proxies.txt",
        "working_proxies.txt",
        "best_proxy.txt",
        "Proxy Residental (2) (2).txt",
        "Proxy SOCKS5 very fast (3).txt",
    ]
    proxies = []
    seen = set()
    for fname in local_files:
        if os.path.exists(fname):
            try:
                with open(fname, encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        p = parse_proxy_line(line)
                        if p:
                            key = f"{p['host']}:{p['port']}"
                            if key not in seen:
                                seen.add(key)
                                proxies.append(p)
            except Exception as e:
                print(f"[PROXY] Error reading {fname}: {e}")
    print(f"[PROXY] Loaded {len(proxies)} unique proxies from local files")
    return proxies


async def fetch_proxy_list() -> list[dict]:
    """Download proxy lists from GitHub sources + combine with local files"""
    all_proxies = load_local_proxies()
    seen = {f"{p['host']}:{p['port']}" for p in all_proxies}

    print(f"[PROXY] Fetching additional proxies from {len(GITHUB_PROXY_URLS)} GitHub sources...")
    async with aiohttp.ClientSession() as session:
        for url in GITHUB_PROXY_URLS:
            try:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                    if resp.status == 200:
                        text = await resp.text()
                        count = 0
                        for line in text.splitlines():
                            p = parse_proxy_line(line)
                            if p:
                                key = f"{p['host']}:{p['port']}"
                                if key not in seen:
                                    seen.add(key)
                                    all_proxies.append(p)
                                    count += 1
                        print(f"[PROXY] Added {count} proxies from {url.split('/')[-1]}")
            except Exception as e:
                print(f"[PROXY] GitHub fetch notice ({url.split('/')[-1]}): {e}")

    return all_proxies



async def test_one_proxy(session: aiohttp.ClientSession, proxy: dict, semaphore) -> tuple[dict, bool, int]:
    """Test a single HTTP proxy. Returns (proxy, working, speed_ms)"""
    async with semaphore:
        # aiohttp only supports http/https proxy URLs natively
        proto = "http" if proxy["protocol"] in ("http", "https") else proxy["protocol"]
        proxy_url = f"{proto}://"
        if proxy["username"]:
            proxy_url += f"{proxy['username']}:{proxy['password']}@"
        proxy_url += f"{proxy['host']}:{proxy['port']}"

        start = time.time()
        for test_url in TEST_URLS:
            try:
                async with session.get(
                    test_url,
                    proxy=proxy_url if proto in ("http", "https") else None,
                    timeout=aiohttp.ClientTimeout(total=TEST_TIMEOUT),
                    ssl=False,
                    allow_redirects=True
                ) as resp:
                    if resp.status in (200, 301, 302):
                        speed = int((time.time() - start) * 1000)
                        return proxy, True, speed
            except Exception:
                continue
        return proxy, False, 0


async def test_proxies(proxies: list[dict], max_test: int = 500) -> list[tuple]:
    """Test proxies concurrently. Returns list of (proxy, working, speed_ms)"""
    proxies = proxies[:max_test]
    print(f"[PROXY] Testing {len(proxies)} proxies (max {CONCURRENCY} concurrent)...")

    semaphore = asyncio.Semaphore(CONCURRENCY)
    connector = aiohttp.TCPConnector(limit=CONCURRENCY, ssl=False)

    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = [test_one_proxy(session, p, semaphore) for p in proxies]

        results = []
        done = 0
        working = 0

        for coro in asyncio.as_completed(tasks):
            proxy, ok, speed = await coro
            done += 1
            if ok:
                working += 1
                results.append((proxy, True, speed))
                save_working_proxy(proxy, speed)
            if done % 50 == 0 or done == len(tasks):
                print(f"[PROXY] Tested {done}/{len(tasks)} | Working: {working}")

    return results


async def refresh_proxy_pool(notify_cb=None) -> int:
    """
    Full refresh cycle:
    1. Clear unused proxies from DB
    2. Load local files + GitHub
    3. Test them concurrently
    Returns count of working proxies.
    """
    if notify_cb:
        await notify_cb("🔄 Loading & testing proxies (Local + GitHub)...")

    clear_proxies()

    proxies = await fetch_proxy_list()
    if not proxies:
        return 0

    bulk_save_proxies(proxies)

    results = await test_proxies(proxies, max_test=600)
    working = [r for r in results if r[1]]
    working.sort(key=lambda x: x[2])  # sort by speed

    stats = get_proxy_stats()
    print(f"[PROXY] Pool ready: {stats['working']} working, {stats['free']} available")

    if notify_cb:
        await notify_cb(
            f"✅ Proxy pool ready: {stats['working']} working proxies available!"
        )

    return stats["working"]


async def get_n_working_proxies(n: int, notify_cb=None) -> list[dict]:
    """
    Get exactly n working proxies.
    Refreshes pool if not enough available.
    """
    from database import get_available_proxies, get_proxy_stats

    stats = get_proxy_stats()
    print(f"[PROXY] Need {n}, available: {stats['free']}")

    if stats["free"] < n:
        print(f"[PROXY] Not enough proxies in DB, refreshing pool...")
        await refresh_proxy_pool(notify_cb)

    proxies = get_available_proxies(n)
    if len(proxies) < n:
        print(f"[PROXY] WARNING: Only {len(proxies)} proxies available, needed {n}")

    return proxies


def proxy_to_playwright(p: dict) -> dict:
    """Convert DB proxy dict to Playwright proxy format"""
    server = f"{p.get('protocol','http')}://{p['host']}:{p['port']}"
    result = {"server": server}
    if p.get("username"):
        result["username"] = p["username"]
        result["password"] = p.get("password", "")
    return result


if __name__ == "__main__":
    async def test():
        count = await refresh_proxy_pool()
        print(f"Working proxies total: {count}")
    asyncio.run(test())
