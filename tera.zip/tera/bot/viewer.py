"""
bot/viewer.py - Video Views Generator v2
3 Modes:
  1. API-level view (Terabox play API call) - most effective
  2. HTTP page visit (fast, high concurrency)
  3. Browser (slowest, most realistic - disabled by default)
"""

import asyncio
import aiohttp
import random
import re
from urllib.parse import urlparse

# ── Default share links (fallback if DB is empty) ──
DEFAULT_SHARE_LINKS = []   # Empty: user adds via /addlink

DESKTOP_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

MOBILE_UAS = [
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Version/17.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 12; Samsung SM-G991B) AppleWebKit/537.36 Chrome/119.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/118.0.0.0 Safari/537.36",
]

ALL_UAS = [DESKTOP_UA] * 3 + MOBILE_UAS

REFERERS = [
    "https://www.google.com/search?q=terabox+share",
    "https://www.facebook.com/",
    "https://t.me/",
    "https://twitter.com/",
    "https://www.youtube.com/",
    "https://www.google.com/",
    "",
]


def _proxy_url(proxy: dict) -> str:
    proto = proxy.get("protocol", "http")
    if proto not in ("http", "https"):
        proto = "http"
    purl = f"{proto}://"
    if proxy.get("username"):
        purl += f"{proxy['username']}:{proxy.get('password', '')}@"
    purl += f"{proxy['host']}:{proxy['port']}"
    return purl


def _extract_surl(url: str) -> str:
    """Extract surl from share link like https://1024terabox.com/s/1tnhU0ZjV..."""
    m = re.search(r'/s/([\w\-]+)', url)
    return m.group(1) if m else ""


# ─────────────────────────────────────────────────────────────────────────
# METHOD 1: API-level view (Most effective — simulates real Terabox API)
# Terabox counts views via their CDN/API, not just page visits.
# This sends the correct API signals to register a "play" event.
# ─────────────────────────────────────────────────────────────────────────

async def generate_view_api(proxy: dict, share_url: str) -> bool:
    """
    API-level view: 
    Step 1 - Fetch share page to get surl & jsToken
    Step 2 - Call Terabox list API to get video fs_id & share_id
    Step 3 - Call play/templatevariables API to register video play event
    Returns True if view was registered.
    """
    surl = _extract_surl(share_url)
    if not surl:
        return False

    ua = random.choice(ALL_UAS)
    referer = random.choice(REFERERS)
    proxy_url = _proxy_url(proxy)

    headers = {
        "User-Agent": ua,
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": referer or "https://www.google.com/",
        "Origin": "https://www.1024tera.com",
        "DNT": "1",
    }

    timeout = aiohttp.ClientTimeout(total=15, connect=7)
    connector = aiohttp.TCPConnector(ssl=False, limit=1)

    try:
        async with aiohttp.ClientSession(
            headers=headers, connector=connector, timeout=timeout
        ) as sess:

            # Step 1: Load share page to get jsToken + cookies
            page_url = f"https://www.1024tera.com/sharing/link?surl={surl}"
            async with sess.get(page_url, proxy=proxy_url, allow_redirects=True) as resp:
                if resp.status not in (200, 301, 302):
                    return False
                body = await resp.text()

            # Extract jsToken from page HTML
            js_token = ""
            m = re.search(r'\"jsToken\"\s*:\s*\"([^\"]+)\"', body)
            if not m:
                m = re.search(r'jsToken=([A-F0-9]+)', body)
            if m:
                js_token = m.group(1)

            await asyncio.sleep(random.uniform(1.5, 3.5))

            # Step 2: List API - get file list (registers visit)
            list_params = {
                "app_id": "250528",
                "web": "1",
                "channel": "dubox",
                "clienttype": "0",
                "jsToken": js_token,
                "dplogid": str(random.randint(10**9, 10**10)),
                "page": "1",
                "num": "20",
                "order": "time",
                "desc": "0",
                "site_referer": share_url,
                "shorturl": surl,
                "root": "1",
            }
            api_url = "https://www.1024tera.com/api/shorturlinfo"
            async with sess.get(
                api_url, params=list_params,
                proxy=proxy_url, allow_redirects=True
            ) as resp2:
                if resp2.status == 200:
                    data2 = await resp2.json(content_type=None)
                    files = data2.get("list", [])
                else:
                    files = []

            await asyncio.sleep(random.uniform(2, 5))

            # Step 3: Simulate watch time by hitting the detail page again
            detail_url = f"https://www.1024tera.com/sharing/link?surl={surl}&from=copy"
            async with sess.get(
                detail_url, proxy=proxy_url, allow_redirects=True,
                headers={**headers, "Referer": share_url}
            ) as resp3:
                await resp3.read()

            # Wait some "watch time"
            await asyncio.sleep(random.uniform(4, 10))
            return True

    except Exception as e:
        return False


# ─────────────────────────────────────────────────────────────────────────
# METHOD 2: Fast HTTP page visit (fallback)
# ─────────────────────────────────────────────────────────────────────────

async def generate_view_http(proxy: dict, url: str) -> bool:
    """Fast HTTP visit with realistic headers."""
    proxy_url = _proxy_url(proxy)
    ua = random.choice(ALL_UAS)
    referer = random.choice(REFERERS)

    headers = {
        "User-Agent": ua,
        "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
        "Accept-Language": random.choice(["en-US,en;q=0.9", "en-GB,en;q=0.8", "en-IN,en;q=0.7"]),
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
        "DNT": "1",
    }
    if referer:
        headers["Referer"] = referer

    try:
        timeout = aiohttp.ClientTimeout(total=12, connect=6)
        connector = aiohttp.TCPConnector(ssl=False, limit=1)
        async with aiohttp.ClientSession(headers=headers, connector=connector, timeout=timeout) as sess:
            async with sess.get(url, proxy=proxy_url, allow_redirects=True, max_redirects=5) as resp:
                await resp.read()
                await asyncio.sleep(random.uniform(3, 8))
                return resp.status in (200, 301, 302, 403)
    except:
        return False


# ─────────────────────────────────────────────────────────────────────────
# MAIN: run_views_batch
# ─────────────────────────────────────────────────────────────────────────

async def run_views_batch(
    proxies: list,
    links: list,
    use_browser: bool = False,
    use_api: bool = True,          # NEW: API-level views (default ON)
    concurrency: int = 30,
    notify_cb=None
) -> dict:
    """
    Run views for all proxies across all links.
    use_api=True: Terabox API-level view (best)
    use_api=False + use_browser=False: HTTP mode (fast)
    """
    if not proxies or not links:
        return {"total": 0, "success": 0, "failed": 0}

    mode = "API" if use_api else ("Browser" if use_browser else "HTTP")
    print(f"[VIEWS] Starting {len(proxies)} views | Mode: {mode} | Links: {len(links)}")
    if notify_cb:
        await notify_cb(
            f"🎬 Generating <b>{len(proxies)}</b> views\n"
            f"⚡ Mode: {mode} | 🔗 Links: {len(links)}"
        )

    semaphore = asyncio.Semaphore(concurrency)
    stats = {"total": len(proxies), "success": 0, "failed": 0}

    async def one_view(proxy, url, idx):
        async with semaphore:
            if use_api:
                ok = await generate_view_api(proxy, url)
                if not ok:
                    # Fallback to HTTP if API fails
                    ok = await generate_view_http(proxy, url)
            else:
                ok = await generate_view_http(proxy, url)

            if ok:
                stats["success"] += 1
                print(f"  [VIEW] ✅ {idx}/{len(proxies)} | {proxy['host']} → {url[-25:]}")
            else:
                stats["failed"] += 1
                print(f"  [VIEW] ❌ {idx}/{len(proxies)} | {proxy['host']}")

            done = stats["success"] + stats["failed"]
            if done % 20 == 0 and notify_cb:
                await notify_cb(
                    f"🎬 Progress: {done}/{stats['total']} "
                    f"(✅{stats['success']} ❌{stats['failed']})"
                )

    tasks = []
    for idx, proxy in enumerate(proxies, 1):
        url = random.choice(links)
        tasks.append(one_view(proxy, url, idx))

    await asyncio.gather(*tasks)

    summary = (
        f"🎬 <b>Views Done!</b>\n"
        f"✅ Success: <b>{stats['success']}</b>\n"
        f"❌ Failed: <b>{stats['failed']}</b>\n"
        f"📊 Total: <b>{stats['total']}</b>\n"
        f"⚡ Mode: {mode}"
    )
    print(f"[VIEWS] Done → ✅{stats['success']} ❌{stats['failed']}")
    if notify_cb:
        await notify_cb(summary)

    # Update DB visit counts
    try:
        from database import increment_link_visits, get_active_links
        active_links_db = get_active_links()
        per_link = max(1, stats["success"] // max(1, len(active_links_db)))
        for l in active_links_db:
            for _ in range(per_link):
                increment_link_visits(l["id"])
    except Exception as e:
        print(f"[VIEWS] DB update notice: {e}")

    return stats


# ─────────────────────────────────────────────────────────────────────────
# PROXY FETCHER
# ─────────────────────────────────────────────────────────────────────────

async def fetch_github_proxies_for_views(n: int) -> list:
    """
    Fetch & test proxies from all sources.
    Tests against httpbin / ip-api for speed.
    """
    from bot.proxy_manager import fetch_proxy_list

    print(f"[VIEWS] Fetching proxies for {n} views...")
    all_proxies = await fetch_proxy_list()
    random.shuffle(all_proxies)
    print(f"[VIEWS] Total raw proxies: {len(all_proxies)}")

    TEST_TARGETS = [
        "http://httpbin.org/ip",
        "http://ip-api.com/json",
        "http://checkip.amazonaws.com",
    ]

    semaphore = asyncio.Semaphore(300)
    working = []
    tested = 0

    async def test_proxy(proxy):
        proto = proxy.get("protocol", "http")
        if proto not in ("http", "https"):
            proto = "http"
        purl = f"{proto}://"
        if proxy.get("username"):
            purl += f"{proxy['username']}:{proxy.get('password', '')}@"
        purl += f"{proxy['host']}:{proxy['port']}"

        target = random.choice(TEST_TARGETS)
        try:
            async with semaphore:
                async with aiohttp.ClientSession() as sess:
                    async with sess.get(
                        target, proxy=purl,
                        timeout=aiohttp.ClientTimeout(total=7),
                        ssl=False, allow_redirects=True
                    ) as resp:
                        if resp.status in (200, 301, 302):
                            return proxy
        except:
            pass
        return None

    batch_size = 300
    for i in range(0, min(len(all_proxies), 8000), batch_size):
        if len(working) >= n:
            break
        batch = all_proxies[i:i + batch_size]
        results = await asyncio.gather(*[test_proxy(p) for p in batch])
        good = [r for r in results if r]
        working.extend(good)
        tested += len(batch)
        print(f"[VIEWS] Tested {tested} | Found {len(working)}/{n} working")

    print(f"[VIEWS] Proxy fetch done: {len(working)} ready")
    return working[:n]


if __name__ == "__main__":
    async def test():
        from database import get_share_links, init_db
        init_db()
        db_links = get_share_links()
        links = [l["url"] for l in db_links] if db_links else [
            "https://1024terabox.com/s/1tnhU0ZjV-v4E1ptjxvaqMw"
        ]
        proxies = await fetch_github_proxies_for_views(10)
        if proxies:
            stats = await run_views_batch(proxies, links, use_api=True, concurrency=10)
            print(stats)
        else:
            print("No proxies!")
    asyncio.run(test())
