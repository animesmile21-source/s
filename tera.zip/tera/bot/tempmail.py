"""
bot/tempmail.py - Multi-Provider Temp Mail with Auto-Fallback
Providers: mail.tm → guerrillamail → maildrop → dispostable → tempmail.lol
Auto-rotates if one provider fails.
"""

import requests
import random
import string
import time
import re

# ─────────────────────────────────────────────────────────────
# PROVIDER 1: mail.tm  (free, reliable, no key needed)
# ─────────────────────────────────────────────────────────────
MAILTM_BASE = "https://api.mail.tm"

def _rand_str(n=10):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=n))


def _mailtm_create() -> dict:
    r = requests.get(f"{MAILTM_BASE}/domains", timeout=12)
    domains = r.json().get("hydra:member", [])
    if not domains:
        raise Exception("mail.tm: no domains")
    domain = random.choice(domains)["domain"]
    username = _rand_str(10)
    email_addr = f"{username}@{domain}"
    password = _rand_str(12)
    r = requests.post(f"{MAILTM_BASE}/accounts",
                      json={"address": email_addr, "password": password}, timeout=12)
    if r.status_code not in (200, 201):
        raise Exception(f"mail.tm account: {r.status_code}")
    r = requests.post(f"{MAILTM_BASE}/token",
                      json={"address": email_addr, "password": password}, timeout=12)
    if r.status_code != 200:
        raise Exception(f"mail.tm token: {r.status_code}")
    return {"address": email_addr, "password": password,
            "token": r.json()["token"], "provider": "mail.tm"}


def _mailtm_inbox(token: str) -> list:
    r = requests.get(f"{MAILTM_BASE}/messages",
                     headers={"Authorization": f"Bearer {token}"}, timeout=12)
    if r.status_code != 200:
        return []
    msgs = r.json().get("hydra:member", [])
    result = []
    for msg in msgs:
        try:
            detail = requests.get(f"{MAILTM_BASE}/messages/{msg['id']}",
                                  headers={"Authorization": f"Bearer {token}"}, timeout=10)
            if detail.status_code == 200:
                d = detail.json()
                result.append({
                    "@id": msg["id"],
                    "subject": d.get("subject", ""),
                    "text": d.get("text", ""),
                    "html": str(d.get("html", "")),
                    "intro": d.get("intro", ""),
                })
        except:
            result.append(msg)
    return result


# ─────────────────────────────────────────────────────────────
# PROVIDER 2: guerrillamail (no key, classic)
# ─────────────────────────────────────────────────────────────
GUERRILLA_BASE = "https://api.guerrillamail.com/ajax.php"

def _guerrilla_create() -> dict:
    r = requests.get(GUERRILLA_BASE, params={"f": "get_email_address"}, timeout=12)
    data = r.json()
    sid = data.get("sid_token", "")
    email_addr = data.get("email_addr", "")
    if not email_addr:
        raise Exception("guerrilla: no email")
    return {"address": email_addr, "password": "", "token": sid, "provider": "guerrillamail"}


def _guerrilla_inbox(token: str) -> list:
    r = requests.get(GUERRILLA_BASE,
                     params={"f": "get_email_list", "offset": 0, "sid_token": token},
                     timeout=12)
    data = r.json()
    emails = data.get("list", [])
    result = []
    for em in emails:
        result.append({
            "@id": str(em.get("mail_id", "")),
            "subject": em.get("mail_subject", ""),
            "text": em.get("mail_excerpt", ""),
            "html": "",
            "intro": em.get("mail_excerpt", ""),
        })
    return result


# ─────────────────────────────────────────────────────────────
# PROVIDER 3: maildrop (simple, free)
# ─────────────────────────────────────────────────────────────
def _maildrop_create() -> dict:
    username = _rand_str(12)
    email_addr = f"{username}@maildrop.cc"
    return {"address": email_addr, "password": "", "token": username, "provider": "maildrop"}


def _maildrop_inbox(token: str) -> list:
    """token = username part of maildrop email"""
    try:
        r = requests.get(f"https://maildrop.cc/api/mailbox/{token}", timeout=12)
        if r.status_code != 200:
            return []
        emails = r.json()
        result = []
        for em in emails:
            msg_id = em.get("id", "")
            try:
                detail = requests.get(f"https://maildrop.cc/api/mailbox/{token}/{msg_id}", timeout=10)
                if detail.status_code == 200:
                    d = detail.json()
                    result.append({
                        "@id": str(msg_id),
                        "subject": d.get("subject", ""),
                        "text": d.get("body", ""),
                        "html": d.get("body", ""),
                        "intro": d.get("body", "")[:100],
                    })
            except:
                continue
        return result
    except:
        return []


# ─────────────────────────────────────────────────────────────
# PROVIDER 4: dispostable
# ─────────────────────────────────────────────────────────────
def _dispostable_create() -> dict:
    username = _rand_str(12)
    domain = random.choice(["dispostable.com", "discardmail.com", "discardmail.de"])
    email_addr = f"{username}@{domain}"
    return {"address": email_addr, "password": "", "token": f"{username}|{domain}", "provider": "dispostable"}


def _dispostable_inbox(token: str) -> list:
    try:
        username, domain = token.split("|")
        r = requests.get(
            f"https://www.dispostable.com/api/mailbox/",
            params={"mailbox": username, "domain": domain},
            timeout=12
        )
        if r.status_code != 200:
            return []
        data = r.json()
        result = []
        for em in data.get("messages", []):
            result.append({
                "@id": str(em.get("id", "")),
                "subject": em.get("subject", ""),
                "text": em.get("body_text", "") or em.get("subject", ""),
                "html": em.get("body_html", ""),
                "intro": em.get("body_text", "")[:100],
            })
        return result
    except:
        return []


# ─────────────────────────────────────────────────────────────
# MAIN PUBLIC API — Auto-rotating multi-provider
# ─────────────────────────────────────────────────────────────

PROVIDERS = [
    ("mail.tm",       _mailtm_create,       _mailtm_inbox),
    ("guerrillamail", _guerrilla_create,     _guerrilla_inbox),
    ("maildrop",      _maildrop_create,      _maildrop_inbox),
    ("dispostable",   _dispostable_create,   _dispostable_inbox),
]

# Track which provider failed recently (reset after 30min)
_failed_providers = {}


def create_email() -> dict:
    """
    Creates temp email. Tries all providers in order.
    Returns: {"address": str, "token": str, "password": str, "provider": str}
    """
    now = time.time()
    # Remove providers that failed > 30min ago (give them another chance)
    expired = [k for k, v in _failed_providers.items() if now - v > 1800]
    for k in expired:
        del _failed_providers[k]

    for name, create_fn, _ in PROVIDERS:
        if name in _failed_providers:
            print(f"  [MAIL] Skipping {name} (recently failed)")
            continue
        try:
            data = create_fn()
            print(f"  [MAIL] ✅ Created email via {name}: {data['address']}")
            return data
        except Exception as e:
            print(f"  [MAIL] ❌ {name} failed: {e}")
            _failed_providers[name] = now

    raise Exception("All temp mail providers failed!")


def get_inbox(token: str, provider: str = "mail.tm") -> list:
    """
    Get inbox for given provider token.
    Auto-detects provider from token format if possible.
    """
    for name, _, inbox_fn in PROVIDERS:
        if name == provider:
            try:
                return inbox_fn(token)
            except Exception as e:
                print(f"  [MAIL] Inbox error ({name}): {e}")
                return []
    # Fallback: try mail.tm
    return _mailtm_inbox(token)


def wait_for_otp(token: str, provider: str = "mail.tm", timeout: int = 120) -> str | None:
    """Blocking OTP wait"""
    start = time.time()
    seen = set()
    while time.time() - start < timeout:
        try:
            emails = get_inbox(token, provider)
            for em in emails:
                eid = em.get("@id", "")
                if eid in seen:
                    continue
                seen.add(eid)
                text = (em.get("subject", "") + " " +
                        em.get("text", "") + " " +
                        em.get("intro", "") + " " +
                        em.get("html", ""))
                m = re.search(r'\b(\d{4,6})\b', text)
                if m:
                    return m.group(1)
        except:
            pass
        time.sleep(5)
    return None


if __name__ == "__main__":
    print("=== Testing all providers ===\n")
    for name, create_fn, inbox_fn in PROVIDERS:
        try:
            data = create_fn()
            msgs = inbox_fn(data["token"])
            print(f"✅ {name}: {data['address']} | inbox: {len(msgs)} msgs")
        except Exception as e:
            print(f"❌ {name}: {e}")
