import asyncio
import database
from bot.tempmail import create_email, get_inbox
from bot.terabox import register_terabox

async def test_run():
    database.init_db()
    
    print("[TEST] Getting random share link...")
    target_url = database.get_random_target_link()
    print(f"[TEST] Target URL: {target_url}")
    
    print("[TEST] Creating temp email...")
    mail_data = create_email()
    email = mail_data["address"]
    token = mail_data["token"]
    print(f"[TEST] Email created: {email}")
    
    async def get_otp(tok=token):
        import time, re
        start = time.time()
        print("[TEST] Polling inbox for OTP...")
        while time.time() - start < 120:
            emails = get_inbox(tok)
            for em in emails:
                subj = em.get("subject", "")
                text = em.get("text", "") + em.get("intro", "")
                m = re.search(r'\b(\d{4,6})\b', subj + " " + text)
                if m:
                    print(f"[TEST] OTP received: {m.group(1)}")
                    return m.group(1)
            await asyncio.sleep(4)
        return None

    print("[TEST] Starting register_terabox on Share Link...")
    result = await register_terabox(
        email=email,
        otp_callback=get_otp,
        headless=True,
        screenshot_prefix="test_run_",
        proxy=None,  # test direct first
        target_url=target_url
    )
    
    print("\n" + "="*50)
    print(f"RESULT: {result}")
    print("="*50)

if __name__ == "__main__":
    asyncio.run(test_run())
